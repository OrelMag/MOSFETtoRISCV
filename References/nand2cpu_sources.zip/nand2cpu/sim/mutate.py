# Mutation testing of the co-simulation: inject one realistic bug at a time and count
# how many random programs expose it.
import subprocess, os, shutil, json, cosim, asm
MUTANTS = {
 'forwarding priority reversed (W before M)': ('rv_pipe.sv',
    "      if      (rs1E == rdM && regwriteM) fwdAE = 2'b10;\n      else if (rs1E == rdW && regwriteW) fwdAE = 2'b01;",
    "      if      (rs1E == rdW && regwriteW) fwdAE = 2'b01;\n      else if (rs1E == rdM && regwriteM) fwdAE = 2'b10;", 'pipe'),
 'load-use stall removed': ('rv_pipe.sv',
    "assign lwstall = resultsrcE0 & ((rs1D == rdE) | (rs2D == rdE));", "assign lwstall = 1'b0;", 'pipe'),
 'predictor target not checked': ('rv_pipe_bp.sv',
    "((pcsrcE != predTakenE) || (pcsrcE && (predTargetE != pctargetE)))", "(pcsrcE != predTakenE)", 'bp'),
 'misprediction recovery always jumps to the target': ('rv_pipe_bp.sv',
    "assign correctPC = pcsrcE ? pctargetE : pcplus4E;", "assign correctPC = pctargetE;", 'bp'),
 'SLT overflow correction removed': ('rv_blocks.sv',
    "assign lt  = sum[W-1] ^ v;", "assign lt  = sum[W-1];", 'single'),
 'microcode: ExecuteI uses register, not immediate': ('../fig/microasm.py',
    "('ExecuteI', dict(ALUSrcA=0b10, ALUSrcB=0b01, ALUOp=0b10),", "('ExecuteI', dict(ALUSrcA=0b10, ALUSrcB=0b00, ALUOp=0b10),", 'multi_mc'),
}
def run(n=200, seed0=5000):
    res={}
    for name,(fn,old,new,cpu) in MUTANTS.items():
        shutil.rmtree('mut',ignore_errors=True); shutil.copytree('../hdl','mut/hdl'); os.makedirs('mut/run')
        if fn.endswith('.py'):
            src=open(fn).read(); assert old in src
            open('mut/microasm.py','w').write(src.replace(old,new))
            subprocess.run('cd mut/run && python3 ../microasm.py . > /dev/null',shell=True,check=True)
        else:
            p=f'mut/hdl/{fn}'; src=open(p).read(); assert old in src, name
            open(p,'w').write(src.replace(old,new))
            for f in ('microcode.hex','dispatch1.hex','dispatch2.hex'): shutil.copy(f,'mut/run/')
        srcs=' '.join(f'mut/hdl/{f}' for f in ['rv_blocks.sv','rv_single.sv','rv_pipe.sv','rv_pipe_bp.sv','microcode.sv','rv_multi.sv'])
        subprocess.run(f'iverilog -g2012 {cosim.CPUS[cpu]} -o mut/m.vvp tb_cosim.sv {srcs}',shell=True,check=True,capture_output=True)
        caught=0
        for s in range(seed0,seed0+n):
            words=[w for w,_ in asm.assemble(cosim.gen(s))]; words+= [0x13]*(64-len(words))
            open('mut/run/prog.hex','w').write(''.join(f'{w:08x}\n' for w in words))
            R,M,steps=cosim.iss_log(words)
            subprocess.run(f'cd mut/run && vvp -n ../m.vvp +CYC={6*steps+40} > /dev/null',shell=True,check=True)
            if cosim.parse('mut/run/cosim.log')!=(R,M): caught+=1
        res[name]=(cpu,caught,n); print(name,cpu,caught,'/',n,flush=True)
    return res
if __name__=='__main__':
    json.dump(run(),open('mutation_stats.json','w'),indent=1)
