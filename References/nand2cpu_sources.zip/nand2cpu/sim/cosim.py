# Random-program co-simulation: generate RV32I-subset programs, run them on the reference
# ISS and on each processor, and compare the ordered streams of register and memory writes.
import random, subprocess, os, sys, json, shutil, time
import asm
POOL=[f'x{i}' for i in range(1,9)]
def rnd_imm(r): return r.choice([r.randrange(-2048,2048), r.randrange(-16,16), 0, -1, 2047, -2048])
def op_line(r):
    k=r.random()
    if k<0.40:
        m=r.choice(['add','sub','and','or','slt'])
        return f'{m} {r.choice(POOL)}, {r.choice(POOL+["x0"])}, {r.choice(POOL+["x0"])}'
    if k<0.75:
        m=r.choice(['addi','andi','ori','slti'])
        return f'{m} {r.choice(POOL)}, {r.choice(POOL+["x0"])}, {rnd_imm(r)}'
    if k<0.88:
        return f'sw {r.choice(POOL+["x0"])}, {r.randrange(-64,64,4)}(x30)'
    return f'lw {r.choice(POOL)}, {r.randrange(-64,64,4)}(x30)'
def gen(seed, max_words=60):
    r=random.Random(seed); L=['addi x30, x0, 64']; lab=0
    while True:
        blk=[]; t=r.random()
        if t<0.35:
            blk=[op_line(r) for _ in range(r.randint(2,6))]
        elif t<0.55:                                   # counted loop, x31 reserved
            n=r.randint(1,4); lab+=1
            body=[op_line(r) for _ in range(r.randint(1,5))]
            blk=[f'addi x31, x0, {n}', f'L{lab}: '+body[0]]+body[1:]+[
                 'addi x31, x31, -1', f'beq x31, x0, E{lab}', f'jal x0, L{lab}', f'E{lab}: addi x0, x0, 0']
        elif t<0.72:                                   # forward conditional branch
            lab+=1; skip=[op_line(r) for _ in range(r.randint(1,3))]
            blk=[f'beq {r.choice(POOL+["x0"])}, {r.choice(POOL+["x0"])}, S{lab}']+skip+[f'S{lab}: '+op_line(r)]
        elif t<0.85:                                   # forward jump-and-link
            lab+=1; skip=[op_line(r) for _ in range(r.randint(1,2))]
            blk=[f'jal {r.choice(POOL+["x0"])}, J{lab}']+skip+[f'J{lab}: '+op_line(r)]
        elif t<0.90:                                   # write-write-read chain on one register (forwarding priority)
            r0=r.choice(POOL); u=r.choice(POOL)
            blk=[f'addi {r0}, {r.choice(POOL+["x0"])}, {rnd_imm(r)}',
                 f'{r.choice(["addi","ori","andi"])} {r0}, {r0}, {rnd_imm(r)}',
                 f'{r.choice(["add","sub","slt","and","or"])} {u}, {r0}, {r.choice([r0]+POOL)}']
        elif t<0.94:                                   # grow two values toward +/-2^31 (signed-overflow corners)
            r0,r1=r.sample(POOL,2); k=r.randint(19,31); lab+=1
            blk=[f'addi {r0}, x0, {r.randint(1,2047)}', f'addi {r1}, x0, {r.randint(-2048,-1)}',
                 f'addi x31, x0, {k}', f'D{lab}: add {r0}, {r0}, {r0}', f'add {r1}, {r1}, {r1}',
                 'addi x31, x31, -1', f'beq x31, x0, F{lab}', f'jal x0, D{lab}',
                 f'F{lab}: slt {r.choice(POOL)}, {r0}, {r1}', f'slt {r.choice(POOL)}, {r1}, {r0}',
                 f'sub {r.choice(POOL)}, {r0}, {r1}']
        elif t<0.97:                                   # loop with a parity-dependent inner branch (T,N,T,N...)
            rt=r.choice(POOL); n=r.randint(3,6); lab+=1
            blk=[f'addi x31, x0, {n}', f'P{lab}: andi {rt}, x31, 1', f'beq {rt}, x0, Q{lab}',
                 op_line(r), f'Q{lab}: '+op_line(r), 'addi x31, x31, -1',
                 f'beq x31, x0, R{lab}', f'jal x0, P{lab}', f'R{lab}: addi x0, x0, 0']
        else:                                          # store / load / immediate use (load-use)
            off=r.randrange(-64,64,4); d=r.choice(POOL); u=r.choice(POOL)
            blk=[f'sw {r.choice(POOL)}, {off}(x30)', f'lw {d}, {off}(x30)',
                 f'{r.choice(["add","sub","and","or","slt"])} {u}, {d}, {r.choice([d]+POOL)}']
        if len(L)+len(blk)+1>max_words: break
        L+=blk
    L.append('H: beq x0, x0, H')
    return '\n'.join(L)
def iss_log(words, maxsteps=5000):
    x=[0]*32; mem={}; pc=0; R=[]; M=[]; M32=0xffffffff; steps=0
    for steps in range(1,maxsteps):
        w=words[pc//4]; op=w&0x7f; rd=(w>>7)&31; f3=(w>>12)&7; rs1=(w>>15)&31; rs2=(w>>20)&31
        a=x[rs1]; b=x[rs2]; npc=pc+4; wr=None
        if op==0x33: wr={0:(a-b if w>>25 else a+b),7:a&b,6:a|b,2:int(asm.sx(a,32)<asm.sx(b,32))}[f3]&M32
        elif op==0x13:
            i=asm.sx(w>>20,12)&M32; wr={0:a+i,7:a&i,6:a|i,2:int(asm.sx(a,32)<asm.sx(i,32))}[f3]&M32
        elif op==0x03: wr=mem.get((a+asm.sx(w>>20,12))&M32,0)
        elif op==0x23:
            ad=(a+asm.sx(((w>>25)<<5)|rd,12))&M32; mem[ad]=b; M.append((ad,b))
        elif op==0x63:
            if a==b:
                imm=asm.sx(((w>>31)<<12)|(((w>>7)&1)<<11)|(((w>>25)&0x3f)<<5)|(((w>>8)&0xf)<<1),13)
                if imm==0: return R,M,steps
                npc=pc+imm
        elif op==0x6f:
            wr=npc; npc=pc+asm.sx(((w>>31)<<20)|(((w>>12)&0xff)<<12)|(((w>>20)&1)<<11)|(((w>>21)&0x3ff)<<1),21)
        if wr is not None and rd!=0: x[rd]=wr; R.append((rd,wr))
        x[0]=0; pc=npc
    raise RuntimeError('no halt')
CPUS={'single':'-DSINGLE','pipe':'-DPIPE -DPIPE_ANY','bp':'-DBP -DPIPE_ANY','multi_mc':'-DMULTI -DMICRO=1','multi_hw':'-DMULTI -DMICRO=0'}
SRC='../hdl/rv_blocks.sv ../hdl/rv_single.sv ../hdl/rv_pipe.sv ../hdl/rv_pipe_bp.sv ../hdl/microcode.sv ../hdl/rv_multi.sv'
def build():
    for k,d in CPUS.items():
        subprocess.run(f'iverilog -g2012 {d} -o cs_{k}.vvp tb_cosim.sv {SRC}',shell=True,check=True,capture_output=True)
def parse(path):
    R=[];M=[]; parse.S=None
    for l in open(path):
        if l.startswith('S '): parse.S=list(map(int,l.split()[1:])); continue
        t=l.split()
        def h(v):
            try: return int(v,16)
            except ValueError: return v            # X/Z values: kept as text, never equal to the ISS
        if t[0]=='R': R.append((int(t[1]),h(t[2])))
        elif t[0]=='M': M.append((h(t[1]),h(t[2])))
    return R,M
def main(n, seed0=1000):
    build(); os.makedirs('cosim_run',exist_ok=True)
    for f in ('microcode.hex','dispatch1.hex','dispatch2.hex'): shutil.copy(f,'cosim_run/')
    stats=dict(programs=0,instructions=0,reg_writes=0,mem_writes=0,mismatch={k:0 for k in CPUS},
               events={'pipe':[0,0,0,0],'bp':[0,0,0,0]}, mix={})
    t0=time.time(); first_fail=None
    for s in range(seed0,seed0+n):
        src=gen(s); prog=asm.assemble(src)
        words=[w for w,_ in prog]+[0x13]*(64-len(prog))
        with open('cosim_run/prog.hex','w') as f:
            for w in words: f.write(f'{w:08x}\n')
        R,M,steps=iss_log(words)
        for mn in [l.split(':')[-1].split()[0] for l in src.splitlines()]:
            stats['mix'][mn]=stats['mix'].get(mn,0)+1
        stats['programs']+=1; stats['instructions']+=steps; stats['reg_writes']+=len(R); stats['mem_writes']+=len(M)
        for k in CPUS:
            subprocess.run(f'cd cosim_run && vvp -n ../cs_{k}.vvp +CYC={6*steps+40} +HALT={4*(len(prog)-1)} > /dev/null',shell=True,check=True)
            r,m=parse('cosim_run/cosim.log')
            if k in stats['events'] and parse.S: stats['events'][k]=[a+b for a,b in zip(stats['events'][k],parse.S)]
            if (r,m)!=(R,M):
                stats['mismatch'][k]+=1
                if first_fail is None: first_fail=(s,k); open(f'cosim_fail_{s}.asm','w').write(src)
    stats['seconds']=round(time.time()-t0,1); stats['first_fail']=first_fail
    return stats
if __name__=='__main__':
    n=int(sys.argv[1]) if len(sys.argv)>1 else 20
    st=main(n); print(json.dumps(st)); json.dump(st,open('cosim_stats.json','w'))
