# Reference vectors for the FPU: NumPy float32 (IEEE 754 binary32, round-to-nearest-even).
import numpy as np, random, sys, struct
rng = random.Random(2026)
def f32(u): return np.frombuffer(struct.pack('<I', u), dtype=np.float32)[0]
def u32(f): return struct.unpack('<I', struct.pack('<f', f))[0] if False else int(np.array([f], dtype=np.float32).view(np.uint32)[0])
QNAN = 0x7FC00000
def pack(s, e, f): return (s << 31) | (e << 23) | f
def rand_class():
    k = rng.random()
    s = rng.getrandbits(1)
    if k < 0.30: return rng.getrandbits(32)                                   # anything
    if k < 0.45: return pack(s, rng.randrange(100, 155), rng.getrandbits(23))  # ordinary magnitudes
    if k < 0.58: return pack(s, 0, rng.getrandbits(23) >> rng.randrange(0, 23))  # subnormal
    if k < 0.66: return pack(s, rng.randrange(1, 8), rng.getrandbits(23))      # tiny normal
    if k < 0.74: return pack(s, rng.randrange(240, 255), rng.getrandbits(23))  # huge
    if k < 0.80: return pack(s, rng.randrange(1, 255), rng.choice([0, 0x7FFFFF, 1, 0x400000]))  # edge fractions
    if k < 0.85: return pack(s, 0, 0)                                          # zeros
    if k < 0.90: return pack(s, 255, 0)                                        # infinities
    if k < 0.93: return pack(s, 255, rng.randrange(1, 1 << 23))                # NaNs
    return pack(s, rng.randrange(1, 255), rng.getrandbits(23))
def pair():
    a = rand_class(); k = rng.random()
    if k < 0.15: b = a ^ (1 << 31)                                             # exact cancellation
    elif k < 0.30: b = (a & ~0x7FFFFF) | ((a + rng.randrange(-3, 4)) & 0x7FFFFF)  # same exponent, close
    elif k < 0.40: b = pack(rng.getrandbits(1), max(0, min(254, ((a >> 23) & 0xFF) + rng.randrange(-2, 3))), rng.getrandbits(23))
    elif k < 0.50:                                                            # product near overflow/underflow
        ea = (a >> 23) & 0xFF; eb = max(0, min(254, rng.choice([127 + 128, 127 - 150, 254 - ea + 127, 127 - ea - 20]) ))
        b = pack(rng.getrandbits(1), eb, rng.getrandbits(23))
    else: b = rand_class()
    return a & 0xFFFFFFFF, b & 0xFFFFFFFF
def ref(op, a, b):
    x, y = f32(a), f32(b)
    with np.errstate(all='ignore'):
        r = x + y if op == 0 else x - y if op == 1 else x * y
    r = np.float32(r)
    ru = QNAN if np.isnan(r) else int(np.array([r], dtype=np.float32).view(np.uint32)[0])
    cmp = (int(x <= y) << 2) | (int(x < y) << 1) | int(x == y)
    return ru, cmp
if __name__ == '__main__':
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 300000
    with open(sys.argv[2] if len(sys.argv) > 2 else 'fp_vectors.txt', 'w') as f:
        # hand-picked cases first
        special = [(0x3FC00000, 0x40000000), (0x3F800000, 0x3F800000), (0x80000000, 0x00000000),
                   (0x80000000, 0x80000000), (0x7F800000, 0xFF800000), (0x7F800000, 0x00000000),
                   (0x00000001, 0x00000001), (0x00800000, 0x80000001), (0x7F7FFFFF, 0x7F7FFFFF),
                   (0x7F7FFFFF, 0x3FC00000), (0x3E4CCCCD, 0x3E99999A), (0x00000001, 0x3F000000),
                   (0x00000003, 0x3F000000), (0x7FC00001, 0x3F800000), (0x3F800001, 0xBF800000)]
        cases = special + [pair() for _ in range(n)]
        for op in (0, 1, 2):
            for a, b in cases:
                y, c = ref(op, a, b)
                f.write(f'{op} {a:08x} {b:08x} {y:08x} {c:x}\n')
    print('vectors', 3 * len(cases))
