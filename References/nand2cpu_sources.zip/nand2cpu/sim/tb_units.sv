`timescale 1ns/1ps
module tb_units;
  integer errs = 0, n = 0, i, j, k;
  // ---------- gate library (exhaustive)
  logic a, b, c, s;
  logic y_not, y_and, y_or, y_xor, y_mux, ha_s, ha_c, fa_s, fa_c;
  not_n  u1 (.a(a), .y(y_not));
  and_n  u2 (.a(a), .b(b), .y(y_and));
  or_n   u3 (.a(a), .b(b), .y(y_or));
  xor_n  u4 (.a(a), .b(b), .y(y_xor));
  mux2_n u5 (.a(a), .b(b), .s(s), .y(y_mux));
  half_adder u6 (.a(a), .b(b), .s(ha_s), .c(ha_c));
  full_adder u7 (.a(a), .b(b), .cin(c), .s(fa_s), .cout(fa_c));
  // ---------- adders (exhaustive 4-bit)
  logic [3:0] x4, y4, rs, cs; logic ci, rco, cco; logic [7:0] p4;
  rca4 u8 (.a(x4), .b(y4), .cin(ci), .s(rs), .cout(rco));
  cla4 u9 (.a(x4), .b(y4), .cin(ci), .s(cs), .cout(cco));
  mul_array4 u10 (.a(x4), .b(y4), .p(p4));
  // ---------- ALU (exhaustive 4-bit)
  logic [2:0] ac; logic [3:0] ay; logic az;
  alu #(4) u11 (.a(x4), .b(y4), .ctrl(ac), .y(ay), .zero(az));
  // ---------- latch / flip-flop
  logic d, en, clk = 0, lq, lqn, fq;
  d_latch u12 (.d(d), .en(en), .q(lq), .q_n(lqn));
  dff_ms  u13 (.d(d), .clk(clk), .q(fq));
  // ---------- sequential arithmetic
  logic sclk = 0, rst = 1, start = 0;
  always #5 sclk = ~sclk;
  logic [7:0] ma, mb, dq1, dr1, dq2, dr2; logic [15:0] mp; logic signed [15:0] bp;
  logic md, bd, d1d, d2d;
  mul_seq #(8) m1 (.clk(sclk), .rst, .start, .a(ma), .b(mb), .p(mp), .done(md));
  mul_booth #(8) m2 (.clk(sclk), .rst, .start, .a(ma), .b(mb), .p(bp), .done(bd));
  div_restoring #(8) d1 (.clk(sclk), .rst, .start, .a(ma), .d(mb), .q(dq1), .r(dr1), .done(d1d));
  div_nonrestoring #(8) d2 (.clk(sclk), .rst, .start, .a(ma), .d(mb), .q(dq2), .r(dr2), .done(d2d));

  task chk(input bit ok, input string what);
    n++; if (!ok) begin errs++; if (errs < 10) $display("FAIL %s", what); end
  endtask
  initial begin
    for (i = 0; i < 16; i++) begin
      {a, b, c, s} = i; #20;
      chk(y_not == ~a && y_and == (a&b) && y_or == (a|b) && y_xor == (a^b), "gates");
      chk(y_mux == (s ? b : a), "mux");
      chk({ha_c, ha_s} == a + b && {fa_c, fa_s} == a + b + c, "adders1");
    end
    for (i = 0; i < 512; i++) begin
      {ci, x4, y4} = i; #30;
      chk({rco, rs} == x4 + y4 + ci, "rca4");
      chk({cco, cs} == x4 + y4 + ci, "cla4");
      chk(p4 == x4 * y4, "array mul");
    end
    for (k = 0; k < 8; k++) for (i = 0; i < 256; i++) begin
      ac = k; {x4, y4} = i; #1;
      case (k)
        0: chk(ay == 4'(x4 + y4), "alu add");
        1: chk(ay == 4'(x4 - y4), "alu sub");
        2: chk(ay == (x4 & y4), "alu and");
        3: chk(ay == (x4 | y4), "alu or");
        5: chk(ay == ($signed(x4) < $signed(y4)), "alu slt");
        default: chk(ay == 0, "alu default");
      endcase
      chk(az == (ay == 0), "alu zero");
    end
    // latch: transparent when en, holds when !en
    en = 1; d = 0; #20; chk(lq == 0 && lqn == 1, "latch0");
    d = 1; #20; chk(lq == 1 && lqn == 0, "latch1");
    en = 0; #20; d = 0; #20; chk(lq == 1, "latch hold");
    // flip-flop: samples only on rising edge
    clk = 0; d = 0; #20; clk = 1; #20; chk(fq == 0, "dff0");
    clk = 0; #20; d = 1; #20; chk(fq == 0, "dff no-edge");
    clk = 1; #20; chk(fq == 1, "dff edge");
    d = 0; #20; chk(fq == 1, "dff hold high clk");
    clk = 0; #20; chk(fq == 1, "dff hold falling");
    // sequential arithmetic: exhaustive 8-bit
    @(negedge sclk) rst = 0;
    for (i = 0; i < 256; i++) for (j = 0; j < 256; j++) begin
      @(negedge sclk) begin ma = i; mb = j; start = 1; end
      @(negedge sclk) start = 0;
      repeat (9) @(negedge sclk);
      chk(mp == i * j, "mul_seq");
      chk(bp == $signed(8'(i)) * $signed(8'(j)), "booth");
      if (j == 0) chk(dq1 == 8'hff && dr1 == i && dq2 == 8'hff && dr2 == i, "div by 0");
      else begin
        chk(dq1 == i / j && dr1 == i % j, "restoring");
        chk(dq2 == i / j && dr2 == i % j && d2d, "nonrestoring");
      end
    end
    $display("unit checks: %0d, failures: %0d", n, errs);
    $finish;
  end
endmodule
