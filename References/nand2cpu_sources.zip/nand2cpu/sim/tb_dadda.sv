module tb_dadda; logic [7:0] a,b; logic [15:0] p; integer i,j,bad=0;
dadda8 u(.a,.b,.p);
initial begin for(i=0;i<256;i++) for(j=0;j<256;j++) begin a=i;b=j;#100; if(p!==i*j) bad++; end
$display("dadda8 exhaustive: 65536 pairs, failures %0d",bad); $finish; end
endmodule
