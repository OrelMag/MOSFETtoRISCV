# Minimal RV32I-subset assembler + instruction-set simulator (reference model)
import sys, json
def reg(s): return int(s.strip().lstrip('x'))
def R(f7,rs2,rs1,f3,rd): return (f7<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|0x33
def I(imm,rs1,f3,rd,op): return ((imm&0xfff)<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|op
def S(imm,rs2,rs1,f3):  imm&=0xfff; return (imm>>5<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|((imm&0x1f)<<7)|0x23
def B(imm,rs2,rs1,f3):
    imm&=0x1fff
    return ((imm>>12)&1)<<31|((imm>>5)&0x3f)<<25|(rs2<<20)|(rs1<<15)|(f3<<12)|((imm>>1)&0xf)<<8|((imm>>11)&1)<<7|0x63
def J(imm,rd):
    imm&=0x1fffff
    return ((imm>>20)&1)<<31|((imm>>1)&0x3ff)<<21|((imm>>11)&1)<<20|((imm>>12)&0xff)<<12|(rd<<7)|0x6f
RF={'add':(0,0),'sub':(32,0),'and':(0,7),'or':(0,6),'slt':(0,2)}
IF={'addi':0,'andi':7,'ori':6,'slti':2}
PROG = """
        addi x1, x0, 0        # sum = 0
        addi x2, x0, 1        # i = 1
        addi x3, x0, 11       # limit
loop:   add  x1, x1, x2       # sum += i         (E<-M forwarding)
        addi x2, x2, 1        # i++
        beq  x2, x3, done     # taken once       (flush 2)
        jal  x0, loop         # back edge        (flush 2)
done:   sw   x1, 100(x0)      # mem[100] = 55
        lw   x4, 100(x0)      # x4 = 55
        add  x5, x4, x4       # load-use -> stall 1 cycle; x5 = 110
        sub  x6, x5, x1       # 55
        slt  x7, x6, x5       # 1
        and  x8, x5, x6       # 38
        or   x9, x5, x6       # 127
        addi x10, x0, -7      # -7
        slt  x12, x10, x0     # 1  (signed compare)
        slti x13, x6, -1      # 0
        andi x14, x9, 0x0f    # 15
        ori  x15, x8, 0x100   # 294
        sw   x5, 104(x0)
        jal  x11, skip        # x11 = return address
        addi x5, x0, 0        # must be squashed
skip:   sw   x7, 108(x0)
        sub  x16, x0, x3      # -11
        sw   x16, 112(x0)
halt:   beq  x0, x0, halt
"""
def assemble(src):
    lines=[]; labels={}
    for ln in src.splitlines():
        ln=ln.split('#')[0].strip()
        if not ln: continue
        if ':' in ln:
            lab,ln=ln.split(':',1); labels[lab.strip()]=len(lines)*4; ln=ln.strip()
        if ln: lines.append(ln)
    out=[]
    for pc,ln in enumerate(lines):
        pc*=4; m,args=ln.split(None,1); a=[x.strip() for x in args.split(',')]
        if m in RF: f7,f3=RF[m]; w=R(f7,reg(a[2]),reg(a[1]),f3,reg(a[0]))
        elif m in IF: w=I(int(a[2],0),reg(a[1]),IF[m],reg(a[0]),0x13)
        elif m in('lw','sw'):
            off,base=a[1].rstrip(')').split('(')
            w=I(int(off),reg(base),2,reg(a[0]),0x03) if m=='lw' else S(int(off),reg(a[0]),reg(base),2)
        elif m=='beq': w=B(labels[a[2]]-pc,reg(a[1]),reg(a[0]),0)
        elif m=='jal': w=J(labels[a[1]]-pc,reg(a[0]))
        out.append((w,ln))
    return out
def sx(v,b): return v-(1<<b) if v>>(b-1)&1 else v
def iss(words, maxsteps=1000):
    x=[0]*32; mem={}; pc=0; halt=None
    for _ in range(maxsteps):
        w=words[pc//4]; op=w&0x7f; rd=(w>>7)&31; f3=(w>>12)&7; rs1=(w>>15)&31; rs2=(w>>20)&31
        a=x[rs1]; b=x[rs2]; npc=pc+4; m32=0xffffffff
        if op==0x33:
            f7=w>>25
            r={0:(a-b if f7 else a+b),7:a&b,6:a|b,2:int(sx(a,32)<sx(b,32))}[f3]
            x[rd]=r&m32
        elif op==0x13:
            imm=sx(w>>20,12)&m32
            x[rd]={0:a+imm,7:a&imm,6:a|imm,2:int(sx(a,32)<sx(imm,32))}[f3]&m32
        elif op==0x03: x[rd]=mem.get((a+sx(w>>20,12))&m32,0)
        elif op==0x23: mem[(a+sx(((w>>25)<<5)|rd,12))&m32]=b
        elif op==0x63:
            imm=sx(((w>>31)<<12)|(((w>>7)&1)<<11)|(((w>>25)&0x3f)<<5)|(((w>>8)&0xf)<<1),13)
            if a==b:
                if imm==0: halt=pc; break
                npc=pc+imm
        elif op==0x6f:
            imm=sx(((w>>31)<<20)|(((w>>12)&0xff)<<12)|(((w>>20)&1)<<11)|(((w>>21)&0x3ff)<<1),21)
            x[rd]=npc; npc=pc+imm
        x[0]=0; pc=npc
    return x,mem,halt
if __name__=='__main__':
    prog=assemble(PROG)
    with open('prog.hex','w') as f:
        for w,_ in prog: f.write(f'{w:08x}\n')
        for _ in range(64-len(prog)): f.write('00000013\n')
    x,mem,halt=iss([w for w,_ in prog]+[0x13]*64)
    json.dump({'x':x,'mem':{str(k):v for k,v in mem.items()},'halt':halt},open('expected.json','w'))
    with open('listing.txt','w') as f:
        for i,(w,ln) in enumerate(prog): f.write(f'{i*4:04x}  {w:08x}  {ln}\n')
    print(open('listing.txt').read()); print('x=',x[:17]); print('mem',mem,'halt',hex(halt))
