# Number-system demonstration program: assemble, run on the reference ISS, write prog.hex
import asm, json, sys, os
SRC = """
        addi x1, x0, 1          # x1 = 1
        addi x31, x0, 31        # loop counter
dbl:    add  x1, x1, x1         # 31 doublings: x1 = 2^31 = 0x80000000
        addi x31, x31, -1
        beq  x31, x0, done
        jal  x0, dbl
done:   addi x2, x1, -1         # 0x7FFFFFFF: largest positive number
        addi x3, x2, 1          # +1 wraps to 0x80000000: most negative number
        slt  x4, x3, x2         # 1: most negative < largest positive
        slt  x5, x2, x3         # 0
        sub  x6, x0, x3         # -(most negative) overflows back to itself
        addi x7, x0, -1         # 12-bit immediate -1 sign-extends to 0xFFFFFFFF
        slt  x8, x7, x0         # 1: -1 < 0 as signed numbers
        addi x9, x0, -2048      # most negative 12-bit immediate: 0xFFFFF800
        add  x10, x7, x7        # -1 + -1 = -2 (the carry out of bit 31 is discarded)
        sub  x11, x0, x7        # -(-1) = 1
        add  x12, x2, x2        # positive + positive overflows to -2
        slti x13, x2, 0         # overflow test (RISC-V spec idiom): is the addend negative?
        slt  x14, x12, x2       # ... is the sum less than the other operand?
        beq  x13, x14, nov      # equal answers: no overflow
        addi x15, x0, 1         # x15 = 1 flags the signed overflow
nov:    sw   x12, 0(x0)         # store the wrapped sum in memory word 0
halt:   beq  x0, x0, halt
"""
if __name__ == '__main__':
    os.makedirs('numdemo', exist_ok=True)
    prog = asm.assemble(SRC)
    words = [w for w, _ in prog] + [0x13] * (64 - len(prog))
    with open('numdemo/prog.hex', 'w') as f:
        for w in words: f.write(f'{w:08x}\n')
    x, mem, halt = asm.iss(words)
    json.dump({'x': x, 'mem': {str(k): v for k, v in mem.items()}, 'src': SRC}, open('numdemo/expected.json', 'w'))
    for i in range(1, 16): print(f'x{i:<2} = 0x{x[i]:08X}  unsigned {x[i]:>10}  signed {x[i]-(1<<32) if x[i]>>31 else x[i]:>11}')
    print('mem[0] = 0x%08X' % mem[0], 'instructions', len(prog))
