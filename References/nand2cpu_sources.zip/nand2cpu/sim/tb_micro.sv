module tb_micro;
  logic clk = 0, rst = 1; logic [6:0] op = 0;
  always #5 clk = ~clk;
  logic [3:0] s1, s2; logic [13:0] c1, c2;
  ctl_hardwired  hw (.clk, .rst, .op, .state(s1), .ctrl(c1));
  ctl_microcoded mc (.clk, .rst, .op, .upc(s2),   .ctrl(c2));
  integer i, k, n = 0, errs = 0;
  initial begin
    // (1) every one of the 128 opcodes, held constant for a full instruction cycle
    for (k = 0; k < 128; k++) begin
      @(negedge clk) begin rst = 1; op = k; end
      @(negedge clk) rst = 0;
      repeat (12) begin @(negedge clk); n++; if (s1 !== s2 || c1 !== c2) errs++; end
    end
    // (2) 200 000 cycles with a random opcode applied every cycle
    for (i = 0; i < 200000; i++) begin
      @(negedge clk) op = $urandom;
      #1 n++; if (s1 !== s2 || c1 !== c2) errs++;
    end
    $display("microcode vs hardwired: %0d cycle comparisons, mismatches %0d", n, errs);
    $finish;
  end
endmodule

module tb_micro_comb;
  logic [3:0] st, n1, n2; logic [6:0] op; logic [13:0] c1, c2; integer i, j, errs = 0;
  ctl_hw_core h (.state(st), .op, .nxt(n1), .ctrl(c1));
  ctl_mc_core m (.upc(st),   .op, .unext(n2), .ctrl(c2));
  initial begin
    for (i = 0; i < 11; i++) for (j = 0; j < 128; j++) begin
      st = i; op = j; #1; if (n1 !== n2 || c1 !== c2) errs++;
    end
    $display("combinational cores, all 11 states x 128 opcodes: mismatches %0d", errs);
  end
endmodule
