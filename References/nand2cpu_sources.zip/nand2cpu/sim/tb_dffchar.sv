`timescale 1ns/1ps
// Characterize the NAND master–slave flip-flop (unit NAND delay = 1 ns under SIM):
// clock-to-Q delay, and the minimum setup time for a correct capture.
module tb_dffchar;
  logic d, clk; wire q;
  dff_ms dut (.d, .clk, .q);
  integer h, bad, minhold, lead, ok, t_edge, t_q, minsetup = -1, tpcq = -1, v;
  initial begin
    // clock-to-Q: D stable long before the edge
    for (v = 0; v < 2; v++) begin
      clk = 0; d = v; #20; d = ~v[0]; #20;       // settle to ~v
      clk = 1; #20; clk = 0; #20;                 // capture ~v
      d = v; #20;                                 // new value, well before edge
      t_edge = $time; clk = 1;
      @(q); t_q = $time;
      if (t_q - t_edge > tpcq) tpcq = t_q - t_edge;
      #20; clk = 0; #20;
    end
    // setup: change D 'lead' ns before the rising edge, largest lead that fails + 1
    for (lead = 10; lead >= 0; lead--) begin
      for (v = 0; v < 2; v++) begin
        clk = 0; d = ~v[0]; #30; clk = 1; #30; clk = 0; #30;   // q = ~v
        #(40 - lead) d = v; #(lead) clk = 1; #30;
        ok = (q === v[0]);
        if (!ok && minsetup < 0) minsetup = lead + 1;
        clk = 0; #30;
      end
    end
    // hold: change D 'h' ns AFTER the rising edge; smallest h that never corrupts the capture
    minhold = -1;
    for (h = 0; h <= 10; h++) begin
      bad = 0;
      for (v = 0; v < 2; v++) begin
        clk = 0; d = ~v[0]; #30; clk = 1; #30; clk = 0; #30;   // q = ~v
        d = v; #30;                                             // v set up long before the edge
        clk = 1; #(h) d = ~v[0]; #30;
        if (q !== v[0]) bad = 1;
        clk = 0; #30;
      end
      if (!bad && minhold < 0) minhold = h;
    end
    $display("dff_ms: minimum hold = %0d NAND delays", minhold);
    $display("dff_ms: clock-to-Q = %0d NAND delays; minimum setup = %0d NAND delays", tpcq, minsetup);
    $finish;
  end
endmodule
