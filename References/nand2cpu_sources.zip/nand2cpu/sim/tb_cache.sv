`timescale 1ns/1ps
module tb_cache;
  logic clk=0, rst=1, re=0, we=0; logic [3:0] ra=0, wa=0; logic [7:0] wd=0, rdata; logic hit;
  logic [15:0] hits, misses;
  always #5 clk = ~clk;
  dm_cache dut (.clk, .rst, .re, .ra, .rdata, .hit, .we, .wa, .wd, .hits, .misses);
  logic [7:0] model [16];
  integer fd, code, op, a, d, n=0, errs=0, k, cur=-1, done=0;
  initial begin
    @(negedge clk) rst = 0;
    for (k=0;k<16;k++) begin @(negedge clk) begin we=1; wa=k; wd=8'h10+k; end model[k]=8'h10+k; end
    @(negedge clk) we=0;
    fd = $fopen("cache_traces.txt","r");
    while (!done) begin
      code = $fscanf(fd, "%d %h %h\n", op, a, d);
      if (op >= 2) begin
        @(negedge clk) begin re=0; we=0; end
        if (cur >= 0) $display("trace %0d|%0d|%0d", cur, hits, misses);
        if (op == 3) done = 1;
        else begin
          cur = a;
          @(negedge clk) rst=1;              // empty cache and zero counters (memory keeps data)
          @(negedge clk) rst=0;
        end
      end else if (op == 0) begin
        @(negedge clk) begin we=0; re=1; ra=a; end
        #1 n++; if (rdata !== model[a]) errs++;
      end else begin
        @(negedge clk) begin re=0; we=1; wa=a; wd=d; end
        model[a] = d;
      end
    end
    $display("cache data checks: %0d, failures: %0d", n, errs);
    $finish;
  end
endmodule
