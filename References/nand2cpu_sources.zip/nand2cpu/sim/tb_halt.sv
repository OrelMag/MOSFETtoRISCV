module tb_halt; logic clk=0,rst=1; always #5 clk=~clk; top_single dut(.clk,.rst);
integer c=0; initial #17 rst=0;
always @(posedge clk) if(!rst) begin if(dut.pc==32'h64) begin $display("single-cycle: halt executes in cycle %0d (0-based) -> instruction #%0d",c,c+1); $finish; end c<=c+1; end
endmodule
