import json
exp=json.load(open('expected.json'))
import sys
for name in (sys.argv[1:] or ['single','pipe']):
    x={};mem={}
    for ln in open(name+'.log'):
        t=ln.split()
        if t[0]=='X': x[int(t[1])]=int(t[2]) if t[2]!='x' else None
        if t[0]=='MEM' and t[2] not in('x',): mem[int(t[1])]=int(t[2])
    okx = all((x[i] or 0)==exp['x'][i] for i in range(1,32))
    okm = all(mem.get(int(k))==v for k,v in exp['mem'].items())
    print(name,'regs match:',okx,'mem match:',okm, {k:mem.get(int(k)) for k in exp['mem']})
