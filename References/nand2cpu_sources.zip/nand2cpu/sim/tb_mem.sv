`timescale 1ns/1ps
module tb_mem;
  logic clk = 0, we = 0; logic [3:0] wa = 0, ra = 0; logic [7:0] wd = 0, rd;
  always #5 clk = ~clk;
  mem16x8 dut (.clk, .we, .wa, .ra, .wd, .rd);
  logic [7:0] model [16];
  integer i, j, k, n = 0, errs = 0, f;
  task automatic write(input [3:0] a, input [7:0] d, input bit en);
    @(negedge clk) begin wa = a; wd = d; we = en; end
    @(posedge clk) #1 if (en) model[a] = d;
    @(negedge clk) we = 0;
  endtask
  task automatic check_all(input string tag);
    for (k = 0; k < 16; k++) begin
      ra = k; #1; n++;
      if (rd !== model[k]) begin errs++; if (errs < 8) $display("FAIL %s addr %0d got %h exp %h", tag, k, rd, model[k]); end
    end
  endtask
  initial begin
    f = $fopen("mem_wave.log", "w");
    // 1. initialize every word with a unique value, then read all back
    for (i = 0; i < 16; i++) write(i, 8'hA0 + i, 1);
    check_all("init");
    // 2. walking ones: each write must change exactly one word (no aliasing)
    for (i = 0; i < 16; i++) for (j = 0; j < 8; j++) begin
      write(i, 8'(1 << j), 1); check_all("walk");
    end
    // 3. writes with we = 0 must change nothing
    for (i = 0; i < 16; i++) begin write(i, 8'h5A, 0); check_all("no-we"); end
    // 4. random mixed traffic against the reference model
    for (i = 0; i < 20000; i++) begin
      if ($urandom % 2) write($urandom, $urandom, $urandom % 4 != 0);
      ra = $urandom; #1; n++;
      if (rd !== model[ra]) errs++;
    end
    $display("memory checks: %0d, failures: %0d", n, errs);
    // 5. short, logged sequence for the waveform figure
    for (i = 0; i < 4; i++) begin write(i, 8'h00, 1); end
    fork
      begin
        repeat (130) begin #1 $fdisplay(f, "%0d %b %b %h %h %h %h", $time, clk, we, wa, wd, ra, rd); end
      end
      begin
        @(negedge clk) begin ra = 4'h3; end
        write(4'h3, 8'h3C, 1);
        write(4'h9, 8'h96, 1);
        @(negedge clk) ra = 4'h9;
        write(4'h9, 8'h69, 0);
        @(negedge clk) ra = 4'h3;
      end
    join
    $fclose(f);
    $finish;
  end
endmodule
