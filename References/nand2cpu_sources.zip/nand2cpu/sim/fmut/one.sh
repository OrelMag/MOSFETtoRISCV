cd /home/claude/p/sim
i=$1
m=$(sed -n "${i}p" fmut/mutants.txt)
sed "$m" ../hdl/fpu.sv > fmut/fpu_$i.sv
if cmp -s fmut/fpu_$i.sv ../hdl/fpu.sv; then echo "$i NOT APPLIED: $m"; exit; fi
iverilog -g2012 -o fmut/m$i.vvp fmut/tb_fpu_small.sv fmut/fpu_$i.sv 2>/dev/null
echo "$i | $m | $(vvp -n fmut/m$i.vvp | grep 'fpu:')" | tee -a fmut/results.txt
