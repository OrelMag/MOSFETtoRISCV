module tb_fpu;
  logic [31:0] a, b, y, ey; logic [1:0] op; logic [2:0] cmp; integer ec, fd, code, n = 0, bad = 0, badc = 0, nop, i;
  integer nbad [3];
  fpu_core dut (.a, .b, .op, .y, .cmp);
  initial begin
    nbad[0] = 0; nbad[1] = 0; nbad[2] = 0;
    fd = $fopen("fp_vectors.txt", "r");
    while (!$feof(fd)) begin
      code = $fscanf(fd, "%d %h %h %h %h\n", nop, a, b, ey, ec);
      if (code == 5) begin
        op = nop; #1; n++;
        if (y !== ey) begin
          bad++; nbad[nop]++;
          if (bad <= 6) $display("MISMATCH op %0d a %h b %h got %h exp %h", nop, a, b, y, ey);
        end
        if (cmp !== ec[2:0]) begin badc++; if (badc <= 4) $display("CMP MISMATCH a %h b %h got %b exp %b", a, b, cmp, ec[2:0]); end
      end
    end
    $display("fpu: %0d vectors; result mismatches %0d (add %0d, sub %0d, mul %0d); compare mismatches %0d",
             n, bad, nbad[0], nbad[1], nbad[2], badc);
    $finish;
  end
endmodule
