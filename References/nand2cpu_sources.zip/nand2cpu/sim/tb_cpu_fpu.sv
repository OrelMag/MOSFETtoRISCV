`timescale 1ns/1ps
module tb_cpu_fpu;
  logic clk = 0, rst = 1;
  always #5 clk = ~clk;
  top_fpu #(`CPU) dut (.clk, .rst);
  integer f, i, cyc = 0;
  initial begin
    #1 $readmemh("fpdata.hex", dut.bus.dm.ram);        // operands, loaded after the RAM's own init
    #16 rst = 0;
  end
  always @(posedge clk) if (!rst) begin
    cyc <= cyc + 1;
    if (cyc == 1500) begin
      f = $fopen(`OUTFILE, "w");
      for (i = 0; i < 64; i++) $fdisplay(f, "%h", dut.bus.dm.ram[i]);
      $fclose(f); $finish;
    end
  end
endmodule
