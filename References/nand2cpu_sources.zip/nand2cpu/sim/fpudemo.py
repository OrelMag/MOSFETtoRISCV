# FPU demonstration: a program that uses the memory-mapped FPU, with NumPy reference results.
import asm, fpvec, struct, json, os, numpy as np
def fb(x): return int(np.array([x], dtype=np.float32).view(np.uint32)[0])
PAIRS = [  # (description, a, b) — a and b as float32 bit patterns
 ('1.5 and 2.0',                 fb(1.5), fb(2.0)),
 ('0.1 and 0.2 (inexact)',       fb(0.1), fb(0.2)),
 ('16 777 216 and 1 (tie)',      fb(16777216.0), fb(1.0)),
 ('3.0 and −0.5',                fb(3.0), fb(-0.5)),
 ('largest finite, twice',       0x7F7FFFFF, 0x7F7FFFFF),
 ('subnormal and 0.5',           0x00000003, fb(0.5)),
 ('−0 and −0',                   0x80000000, 0x80000000),
 ('+∞ and −∞',                   0x7F800000, 0xFF800000),
 ('NaN and 1.0',                 0x7FC00000, fb(1.0)),
 ('1e30 and −1e30',              fb(1e30), fb(-1e30)),
]
N = len(PAIRS)
SRC = f"""
        addi x10, x0, 1024      # FPU base address 0x400
        addi x9,  x0, 0         # record pointer into data memory
        addi x8,  x0, {N}        # records left
next:   lw   x1, 0(x9)          # a
        lw   x2, 4(x9)          # b
        sw   x1, 0(x10)         # FPU.A <- a
        sw   x2, 4(x10)         # FPU.B <- b
        sw   x0, 8(x10)         # FPU.OP <- 0 (add)
        lw   x3, 12(x10)        # x3 <- a + b
        sw   x3, 8(x9)
        addi x4, x0, 2
        sw   x4, 8(x10)         # FPU.OP <- 2 (multiply)
        lw   x3, 12(x10)        # x3 <- a * b
        sw   x3, 12(x9)
        lw   x5, 16(x10)        # x5 <- {{a<=b, a<b, a==b}}
        sw   x5, 16(x9)
        addi x9, x9, 20         # next record
        addi x8, x8, -1
        beq  x8, x0, halt
        jal  x0, next
halt:   beq  x0, x0, halt
"""
if __name__ == '__main__':
    os.makedirs('fpudemo', exist_ok=True)
    prog = asm.assemble(SRC)
    with open('fpudemo/prog.hex', 'w') as f:
        for w in [w for w, _ in prog] + [0x13] * (64 - len(prog)): f.write(f'{w:08x}\n')
    data = []; exp = []
    for d, a, b in PAIRS:
        s, _ = fpvec.ref(0, a, b); p, _ = fpvec.ref(2, a, b); _, c = fpvec.ref(0, a, b)
        data += [a, b, 0, 0, 0]; exp.append(dict(desc=d, a=a, b=b, sum=s, prod=p, cmp=c))
    with open('fpudemo/fpdata.hex', 'w') as f:
        for w in data + [0] * (64 - len(data)): f.write(f'{w:08x}\n')
    json.dump(dict(pairs=exp, n_instr=len(prog)), open('fpudemo/expected.json', 'w'), ensure_ascii=False, indent=1)
    for e in exp: print(f"{e['desc']:28s} a={e['a']:08X} b={e['b']:08X} sum={e['sum']:08X} prod={e['prod']:08X} cmp={e['cmp']:03b}")
