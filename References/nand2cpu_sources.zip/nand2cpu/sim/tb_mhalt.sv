module tb_mhalt; logic clk=0,rst=1; always #5 clk=~clk; top_multi #(1) dut(.clk,.rst);
integer c=0; integer nstate[0:15]; integer k; initial begin for(k=0;k<16;k++) nstate[k]=0; #22 rst=0; end
always @(posedge clk) if(!rst) begin
  if (dut.cpu.state==4'd0 && dut.cpu.pc==32'h64) begin
    $display("multicycle: halt fetched in cycle %0d (0-based)", c);
    for(k=0;k<11;k++) $display("state %0d visits %0d", k, nstate[k]); $finish; end
  nstate[dut.cpu.state] = nstate[dut.cpu.state]+1; c<=c+1; end
endmodule
