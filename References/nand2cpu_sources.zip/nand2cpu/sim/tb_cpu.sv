`timescale 1ns/1ps
`ifndef CYCLES
`define CYCLES 200
`endif
module tb_cpu;
  logic clk = 0, rst = 1;
  always #5 clk = ~clk;
`ifdef MULTI
  top_multi #(`MICRO) dut (.clk, .rst);
  wire [31:0] pc = dut.cpu.pc;
`elsif BP
  top_pipe_bp dut (.clk, .rst);
  wire [31:0] pc = dut.pc;
`elsif PIPE
  top_pipe dut (.clk, .rst);
  wire [31:0] pc = dut.pc;
`else
  top_single dut (.clk, .rst);
  wire [31:0] pc = dut.pc;
`endif
  integer cyc = 0, f, i;
  initial begin
    f = $fopen(`OUTFILE, "w");
    #17 rst = 0;                       // between a rising and a falling edge
  end
  always @(posedge clk) if (!rst) begin
    cyc <= cyc + 1;
`ifdef PIPE
    $fdisplay(f, "T %0d F %h D %h E %h M %h W %h stall %b flushD %b flushE %b fwdA %b fwdB %b",
      cyc, dut.cpu.pcF, dut.cpu.pcplus4D, dut.cpu.pcplus4E, dut.cpu.pcplus4M, dut.cpu.pcplus4W,
      dut.cpu.stallD, dut.cpu.flushD, dut.cpu.flushE, dut.cpu.fwdAE, dut.cpu.fwdBE);
`endif
    if (cyc == `CYCLES) begin
      for (i = 0; i < 32; i++) $fdisplay(f, "X %0d %0d", i, dut.cpu.rf.rf[i]);
      for (i = 0; i < 64; i++) $fdisplay(f, "MEM %0d %0d", i*4, dut.dm.ram[i]);
      $fclose(f); $finish;
    end
  end
  // record cycle at which PC first reaches the halt loop's successor state
endmodule
