module tb_ops;
  logic [7:0] a, b, s; logic nb, e, lu, ls; integer i, bad = 0;
  sub_n #(8) u1 (.a, .b, .y(s), .nborrow(nb));
  eq_n  #(8) u2 (.a, .b, .y(e));
  ltu_n #(8) u3 (.a, .b, .y(lu));
  lts_n #(8) u4 (.a, .b, .y(ls));
  initial begin
    for (i = 0; i < 65536; i++) begin
      {a, b} = i; #1;
      if (s !== 8'(a - b) || nb !== (a >= b) || e !== (a == b) || lu !== (a < b)
          || ls !== ($signed(a) < $signed(b))) bad++;
    end
    $display("operator cells, 8-bit exhaustive (65536 pairs): failures %0d", bad);
  end
endmodule
