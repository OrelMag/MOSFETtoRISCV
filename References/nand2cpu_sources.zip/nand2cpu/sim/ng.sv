module mul_booth_ng #(parameter int W = 8) (
  input  logic                  clk, rst, start,
  input  logic signed [W-1:0]   a, b,
  output logic signed [2*W-1:0] p,
  output logic                  done);
  logic signed [W-1:0] acc, m, nxt;   // one guard bit avoids overflow at M = -2^(W-1)
  logic [W-1:0]      q;
  logic              q_1;
  logic [$clog2(W+1)-1:0] cnt;
  always_comb
    case ({q[0], q_1})
      2'b01:   nxt = acc + m;       // end of a run of 1s
      2'b10:   nxt = acc - m;       // start of a run of 1s
      default: nxt = acc;           // inside a run: no operation
    endcase
  always_ff @(posedge clk)
    if (rst) begin cnt <= '0; done <= 1'b0; end
    else if (start) begin acc <= '0; m <= a; q <= b; q_1 <= 1'b0;
                          cnt <= W; done <= 1'b0; end
    else if (cnt != 0) begin
      {acc, q, q_1} <= $signed({nxt, q, q_1}) >>> 1;  // arithmetic shift right
      cnt  <= cnt - 1'b1;
      done <= (cnt == 1);
    end
  assign p = {acc[W-1:0], q};
endmodule
module tb_ng; logic clk=0,rst=1,start=0; always #5 clk=~clk;
logic signed [7:0] a,b; logic signed [15:0] p; logic d; integer i,j,bad=0,firsta=999,firstb;
mul_booth_ng #(8) u(.clk,.rst,.start,.a,.b,.p,.done(d));
initial begin @(negedge clk) rst=0;
 for(i=-128;i<128;i++) for(j=-128;j<128;j++) begin
  @(negedge clk) begin a=i;b=j;start=1; end @(negedge clk) start=0; repeat(9) @(negedge clk);
  if (p!==i*j) begin if(i!=-128) firsta=i; bad++; end end
 $display("no-guard failures %0d nonminus128 a=%0d",bad,firsta); $finish; end
endmodule