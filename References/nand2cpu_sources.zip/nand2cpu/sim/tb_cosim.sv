`timescale 1ns/1ps
// Co-simulation harness: runs one CPU for +CYC cycles and logs every architectural write.
module tb_cosim;
  logic clk = 0, rst = 1;
  always #5 clk = ~clk;
`ifdef SINGLE
  top_single dut (.clk, .rst);
`elsif PIPE
  top_pipe dut (.clk, .rst);
`elsif BP
  top_pipe_bp dut (.clk, .rst);
`else
  top_multi #(`MICRO) dut (.clk, .rst);
`endif
  integer f, cyc = 0, ncyc;
  initial begin
    if (!$value$plusargs("CYC=%d", ncyc)) ncyc = 400;
    f = $fopen("cosim.log", "w");
    #17 rst = 0;                       // between a rising and a falling edge
  end
  always @(negedge clk) if (!rst && dut.cpu.rf.we && dut.cpu.rf.a3 != 0)
    $fdisplay(f, "R %0d %h", dut.cpu.rf.a3, dut.cpu.rf.wd);
`ifdef PIPE_ANY
  integer nstall = 0, nflush = 0, nfwdM = 0, nfwdW = 0, haltpc;
  initial if (!$value$plusargs("HALT=%d", haltpc)) haltpc = -1;
  always @(posedge clk) if (!rst) begin
    nstall = nstall + dut.cpu.stallD;
    nflush = nflush + (dut.cpu.flushD && dut.cpu.pcE != haltpc);   // ignore the final self-loop
    // count forwarding only when the operand is actually used (rs2 is unused by I-type/lw/jal)
    nfwdM = nfwdM + (dut.cpu.fwdAE == 2'b10) + ((dut.cpu.fwdBE == 2'b10) && !dut.cpu.ctrlE[0]);
    nfwdW = nfwdW + (dut.cpu.fwdAE == 2'b01) + ((dut.cpu.fwdBE == 2'b01) && !dut.cpu.ctrlE[0]);
  end
`endif
  always @(posedge clk) if (!rst) begin
    if (dut.dm.we) $fdisplay(f, "M %h %h", dut.dm.a, dut.dm.wd);
    cyc <= cyc + 1;
    if (cyc == ncyc) begin
`ifdef PIPE_ANY
      $fdisplay(f, "S %0d %0d %0d %0d", nstall, nflush, nfwdM, nfwdW);
`endif
      $fclose(f); $finish;
    end
  end
endmodule
