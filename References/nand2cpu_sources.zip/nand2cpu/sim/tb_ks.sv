module tb_ks;
  logic [7:0] a8, b8, s8; logic c8i, c8o;
  logic [31:0] a32, b32, s32; logic c32i, c32o;
  ks_adder #(8)  u8  (.a(a8),  .b(b8),  .cin(c8i),  .s(s8),  .cout(c8o));
  ks_adder #(32) u32 (.a(a32), .b(b32), .cin(c32i), .s(s32), .cout(c32o));
  integer i, bad8 = 0, bad32 = 0;
  initial begin
    for (i = 0; i < 131072; i++) begin {c8i, a8, b8} = i; #1; if ({c8o, s8} !== a8 + b8 + c8i) bad8++; end
    for (i = 0; i < 200000; i++) begin a32 = $urandom; b32 = $urandom; c32i = $urandom; #1;
      if ({c32o, s32} !== {1'b0,a32} + b32 + c32i) bad32++; end
    $display("ks_adder: 8-bit exhaustive 131072 failures %0d; 32-bit random 200000 failures %0d", bad8, bad32);
  end
endmodule
