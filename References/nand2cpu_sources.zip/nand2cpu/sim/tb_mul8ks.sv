module tb_mul8; logic [7:0] a,b; logic [15:0] p1,p2; integer i,j,bad=0;
dadda8_ks u1(.a,.b,.p(p1)); mul_array8 u2(.a,.b,.p(p2));
initial begin for(i=0;i<256;i++) for(j=0;j<256;j++) begin a=i;b=j;#1; if(p1!==i*j || p2!==i*j) bad++; end
$display("dadda8_ks + mul_array8 exhaustive: failures %0d",bad); $finish; end
endmodule
