// cache.sv — a 4-line direct-mapped cache in front of the 16 × 8-bit memory.
// Address a[3:0] = { tag a[3:2], index a[1:0] }. Reads are served from the cache on a
// hit; on a miss the word is read from the backing memory and loaded into its line.
// Writes go to the backing memory and are copied into the cache ("write-through").

module dm_cache (
  input  logic       clk, rst,
  input  logic       re,               // read request (one per clock cycle)
  input  logic [3:0] ra,
  output logic [7:0] rdata,
  output logic       hit,
  input  logic       we,
  input  logic [3:0] wa,
  input  logic [7:0] wd,
  output logic [15:0] hits, misses);
  logic [3:0]  valid;
  logic [1:0]  tag  [4];
  logic [7:0]  data [4];
  logic [7:0]  mem_rd;
  logic [1:0]  ri, wi;
  assign ri = ra[1:0];
  assign wi = wa[1:0];
  mem16x8 backing (.clk, .we, .wa, .ra, .wd, .rd(mem_rd));
  assign hit   = valid[ri] && (tag[ri] == ra[3:2]);
  assign rdata = hit ? data[ri] : mem_rd;
  always_ff @(posedge clk) begin
    if (rst) begin
      valid <= '0; hits <= '0; misses <= '0;
    end else begin
      if (re) begin
        if (hit) hits <= hits + 1'b1;
        else begin
          misses    <= misses + 1'b1;
          valid[ri] <= 1'b1;  tag[ri] <= ra[3:2];  data[ri] <= mem_rd;   // load on miss
        end
      end
      if (we) begin                                                      // write-through
        valid[wi] <= 1'b1;  tag[wi] <= wa[3:2];  data[wi] <= wd;
      end
    end
  end
endmodule
