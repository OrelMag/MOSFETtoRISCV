// microcode.sv — the same multicycle control unit built two ways.
// Control word (14 bits), most-significant first:
//   AdrSrc | IRWrite | ALUSrcA[1:0] | ALUSrcB[1:0] | ALUOp[1:0] | ResultSrc[1:0]
//   | PCUpdate | RegWrite | MemWrite | Branch
// States follow the Harris & Harris RISC-V multicycle controller:
//   0 Fetch  1 Decode  2 MemAdr  3 MemRead  4 MemWB  5 MemWrite
//   6 ExecuteR  7 ALUWB  8 ExecuteI  9 JAL  10 BEQ

// ---------------- (a) hardwired: next-state and output logic as gates
module ctl_hw_core (
  input  logic [3:0]  state,
  input  logic [6:0]  op,
  output logic [3:0]  nxt,
  output logic [13:0] ctrl);
  always_comb begin
    case (state)
      4'd0: nxt = 4'd1;
      4'd1: case (op)
              7'b0000011, 7'b0100011: nxt = 4'd2;   // lw, sw
              7'b0110011:             nxt = 4'd6;   // R-type
              7'b0010011:             nxt = 4'd8;   // I-type ALU
              7'b1101111:             nxt = 4'd9;   // jal
              7'b1100011:             nxt = 4'd10;  // beq
              default:                nxt = 4'd0;   // unimplemented: refetch
            endcase
      4'd2: nxt = (op == 7'b0000011) ? 4'd3 : (op == 7'b0100011) ? 4'd5 : 4'd0;
      4'd3: nxt = 4'd4;
      4'd6, 4'd8, 4'd9: nxt = 4'd7;
      default: nxt = 4'd0;                           // 4, 5, 7, 10 and unused codes
    endcase
    //                   Adr IR  SrcA  SrcB  ALUOp Res   PCU RW MW Br
    case (state)
      4'd0:  ctrl = {1'b0,1'b1,2'b00,2'b10,2'b00,2'b10,1'b1,1'b0,1'b0,1'b0};
      4'd1:  ctrl = {1'b0,1'b0,2'b01,2'b01,2'b00,2'b00,1'b0,1'b0,1'b0,1'b0};
      4'd2:  ctrl = {1'b0,1'b0,2'b10,2'b01,2'b00,2'b00,1'b0,1'b0,1'b0,1'b0};
      4'd3:  ctrl = {1'b1,1'b0,2'b00,2'b00,2'b00,2'b00,1'b0,1'b0,1'b0,1'b0};
      4'd4:  ctrl = {1'b0,1'b0,2'b00,2'b00,2'b00,2'b01,1'b0,1'b1,1'b0,1'b0};
      4'd5:  ctrl = {1'b1,1'b0,2'b00,2'b00,2'b00,2'b00,1'b0,1'b0,1'b1,1'b0};
      4'd6:  ctrl = {1'b0,1'b0,2'b10,2'b00,2'b10,2'b00,1'b0,1'b0,1'b0,1'b0};
      4'd7:  ctrl = {1'b0,1'b0,2'b00,2'b00,2'b00,2'b00,1'b0,1'b1,1'b0,1'b0};
      4'd8:  ctrl = {1'b0,1'b0,2'b10,2'b01,2'b10,2'b00,1'b0,1'b0,1'b0,1'b0};
      4'd9:  ctrl = {1'b0,1'b0,2'b01,2'b10,2'b00,2'b00,1'b1,1'b0,1'b0,1'b0};
      4'd10: ctrl = {1'b0,1'b0,2'b10,2'b00,2'b01,2'b00,1'b0,1'b0,1'b0,1'b1};
      default: ctrl = '0;
    endcase
  end
endmodule

module ctl_hardwired (
  input  logic        clk, rst,
  input  logic [6:0]  op,
  output logic [3:0]  state,
  output logic [13:0] ctrl);
  logic [3:0] nxt;
  ctl_hw_core core (.state, .op, .nxt, .ctrl);
  always_ff @(posedge clk) state <= rst ? 4'd0 : nxt;
endmodule

// ---------------- (b) microprogrammed: a micro-PC, a microcode ROM and two dispatch ROMs
// Microinstruction (20 bits) = { control word[13:0], seq[1:0], next[3:0] }
//   seq 00: jump to next   seq 01: dispatch via table 1   seq 10: dispatch via table 2
module urom (input logic [3:0] a, output logic [19:0] d);
  logic [19:0] mem [0:15];
  initial $readmemh("microcode.hex", mem);
  assign d = mem[a];
endmodule

module dispatch1 (input logic [6:0] op, output logic [3:0] addr);
  logic [3:0] mem [0:127];
  initial $readmemh("dispatch1.hex", mem);
  assign addr = mem[op];
endmodule

module dispatch2 (input logic [6:0] op, output logic [3:0] addr);
  logic [3:0] mem [0:127];
  initial $readmemh("dispatch2.hex", mem);
  assign addr = mem[op];
endmodule

module ctl_mc_core (
  input  logic [3:0]  upc,
  input  logic [6:0]  op,
  output logic [3:0]  unext,
  output logic [13:0] ctrl);
  logic [19:0] uinst;
  logic [3:0]  d1, d2;
  urom      rom (.a(upc), .d(uinst));
  dispatch1 dt1 (.op, .addr(d1));
  dispatch2 dt2 (.op, .addr(d2));
  assign ctrl = uinst[19:6];
  mux3 #(4) sel (.d0(uinst[3:0]), .d1(d1), .d2(d2), .s(uinst[5:4]), .y(unext));
endmodule

module ctl_microcoded (
  input  logic        clk, rst,
  input  logic [6:0]  op,
  output logic [3:0]  upc,
  output logic [13:0] ctrl);
  logic [3:0] unext;
  ctl_mc_core core (.upc, .op, .unext, .ctrl);
  always_ff @(posedge clk) upc <= rst ? 4'd0 : unext;
endmodule
