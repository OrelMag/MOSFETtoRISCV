// cpu_fpu.sv — the four processors with a memory-mapped FPU at 0x400–0x41F.
// Address decoding (Appendix C.8): the FPU is selected when a[31:5] == 32, i.e. 0x400 <= a < 0x420;
// every other address goes to the data memory, whose write enable is gated off for the FPU range.

module fpu_bus (
  input  logic        clk, rst, we,
  input  logic [31:0] adr, wd,
  output logic [31:0] rd);
  logic        sel;
  logic [31:0] dm_rd, fpu_rd;
  assign sel = (adr[31:5] == 27'd32);
  dmem     dm  (.clk, .we(we & ~sel), .a(adr), .wd, .rd(dm_rd));
  fpu_mmio fpu (.clk, .rst, .sel, .we, .off(adr[4:0]), .wd, .rd(fpu_rd));
  assign rd = sel ? fpu_rd : dm_rd;
endmodule

module top_fpu #(parameter int CPU = 0) (input logic clk, rst);   // 0 single, 1 pipe, 2 pipe+BP, 3 multi
  logic [31:0] pc, instr, rdata, adr, wd;
  logic        we;
  if (CPU == 0) begin : g_single
    rv_single cpu (.clk, .rst, .pc, .instr, .readdata(rdata), .memwrite(we), .aluresult(adr), .writedata(wd));
  end else if (CPU == 1) begin : g_pipe
    rv_pipe cpu (.clk, .rst, .pcF(pc), .instrF(instr), .memwriteM(we), .aluresultM(adr),
                 .writedataM(wd), .readdataM(rdata));
  end else if (CPU == 2) begin : g_bp
    rv_pipe_bp cpu (.clk, .rst, .pcF(pc), .instrF(instr), .memwriteM(we), .aluresultM(adr),
                    .writedataM(wd), .readdataM(rdata));
  end else begin : g_multi
    logic [3:0] st;
    rv_multi #(1'b1) cpu (.clk, .rst, .iadr(pc), .instr_rd(instr), .dadr(adr), .dwd(wd), .dwe(we),
                          .data_rd(rdata), .state(st));
  end
  imem    im  (.a(pc), .rd(instr));
  fpu_bus bus (.clk, .rst, .we, .adr, .wd, .rd(rdata));
endmodule
