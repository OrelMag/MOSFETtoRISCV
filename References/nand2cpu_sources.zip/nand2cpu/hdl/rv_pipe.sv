// rv_pipe.sv — five-stage pipelined RV32I-subset processor
// Stages: F(etch) D(ecode) E(xecute) M(emory) W(riteback); branches resolve in E.

module hazard (
  input  logic [4:0] rs1D, rs2D, rs1E, rs2E, rdE, rdM, rdW,
  input  logic       pcsrcE, resultsrcE0, regwriteM, regwriteW,
  output logic [1:0] fwdAE, fwdBE,
  output logic       stallF, stallD, flushD, flushE);
  logic lwstall;
  // Forwarding: prefer the most recent writer (M over W); never forward x0.
  always_comb begin
    fwdAE = 2'b00;
    if (rs1E != 5'd0) begin
      if      (rs1E == rdM && regwriteM) fwdAE = 2'b10;
      else if (rs1E == rdW && regwriteW) fwdAE = 2'b01;
    end
    fwdBE = 2'b00;
    if (rs2E != 5'd0) begin
      if      (rs2E == rdM && regwriteM) fwdBE = 2'b10;
      else if (rs2E == rdW && regwriteW) fwdBE = 2'b01;
    end
  end
  // Load-use hazard: data from lw isn't available until the end of M -> stall one cycle.
  assign lwstall = resultsrcE0 & ((rs1D == rdE) | (rs2D == rdE));
  assign stallF  = lwstall;
  assign stallD  = lwstall;
  // Control hazard: branch/jump taken in E -> squash the two younger instructions.
  assign flushD  = pcsrcE;
  assign flushE  = lwstall | pcsrcE;
endmodule

// Control bundles carried down the pipeline
//   ctrl[9]   regwrite     ctrl[8:7] resultsrc   ctrl[6] memwrite
//   ctrl[5]   jump         ctrl[4]   branch      ctrl[3:1] alucontrol   ctrl[0] alusrc
//   M stage keeps {regwrite, resultsrc, memwrite}; W stage keeps {regwrite, resultsrc}.

module stage_F (
  input  logic        clk, rst, stallF, pcsrcE,
  input  logic [31:0] pctargetE,
  output logic [31:0] pcF, pcplus4F);
  logic [31:0] pcnextF;
  mux2    #(32) pcmux  (.d0(pcplus4F), .d1(pctargetE), .s(pcsrcE), .y(pcnextF));
  pipereg #(32) pcreg  (.clk, .rst, .en(~stallF), .clr(1'b0), .d(pcnextF), .q(pcF));
  adder   #(32) pcadd4 (.a(pcF), .b(32'd4), .y(pcplus4F));
endmodule

module reg_FD (
  input  logic        clk, rst, en, clr,
  input  logic [31:0] instrF, pcF, pcplus4F,
  output logic [31:0] instrD, pcD, pcplus4D);
  pipereg #(96) r (.clk, .rst, .en, .clr, .d({instrF, pcF, pcplus4F}),
                   .q({instrD, pcD, pcplus4D}));
endmodule

module stage_D (
  input  logic [31:0] instrD,
  output logic [9:0]  ctrlD,
  output logic [31:0] immextD,
  output logic [4:0]  rs1D, rs2D, rdD);
  logic [1:0] immsrcD;
  controller ctl (.op(instrD[6:0]), .funct3(instrD[14:12]), .funct7b5(instrD[30]),
                  .regwrite(ctrlD[9]), .resultsrc(ctrlD[8:7]), .memwrite(ctrlD[6]),
                  .jump(ctrlD[5]), .branch(ctrlD[4]), .alucontrol(ctrlD[3:1]),
                  .alusrc(ctrlD[0]), .immsrc(immsrcD));
  extend ext (.instr(instrD[31:7]), .immsrc(immsrcD), .immext(immextD));
  assign rs1D = instrD[19:15];
  assign rs2D = instrD[24:20];
  assign rdD  = instrD[11:7];
endmodule

module reg_DE (
  input  logic        clk, rst, clr,
  input  logic [9:0]  ctrlD,
  input  logic [31:0] rd1D, rd2D, pcD, immextD, pcplus4D,
  input  logic [4:0]  rs1D, rs2D, rdD,
  output logic [9:0]  ctrlE,
  output logic [31:0] rd1E, rd2E, pcE, immextE, pcplus4E,
  output logic [4:0]  rs1E, rs2E, rdE);
  pipereg #(185) r (.clk, .rst, .en(1'b1), .clr,
    .d({ctrlD, rd1D, rd2D, pcD, rs1D, rs2D, rdD, immextD, pcplus4D}),
    .q({ctrlE, rd1E, rd2E, pcE, rs1E, rs2E, rdE, immextE, pcplus4E}));
endmodule

module stage_E (
  input  logic [9:0]  ctrlE,
  input  logic [31:0] rd1E, rd2E, pcE, immextE, resultW, aluresultM,
  input  logic [1:0]  fwdAE, fwdBE,
  output logic [31:0] aluresultE, writedataE, pctargetE,
  output logic        pcsrcE);
  logic [31:0] srcAE, srcBE;
  logic        zeroE;
  mux3  #(32) fwda   (.d0(rd1E), .d1(resultW), .d2(aluresultM), .s(fwdAE), .y(srcAE));
  mux3  #(32) fwdb   (.d0(rd2E), .d1(resultW), .d2(aluresultM), .s(fwdBE), .y(writedataE));
  mux2  #(32) srcbmx (.d0(writedataE), .d1(immextE), .s(ctrlE[0]), .y(srcBE));
  alu   #(32) alu0   (.a(srcAE), .b(srcBE), .ctrl(ctrlE[3:1]), .y(aluresultE), .zero(zeroE));
  adder #(32) pctgt  (.a(pcE), .b(immextE), .y(pctargetE));
  assign pcsrcE = (ctrlE[4] & zeroE) | ctrlE[5];
endmodule

module reg_EM (
  input  logic        clk, rst,
  input  logic [3:0]  ctrlE,
  input  logic [31:0] aluresultE, writedataE, pcplus4E,
  input  logic [4:0]  rdE,
  output logic [3:0]  ctrlM,
  output logic [31:0] aluresultM, writedataM, pcplus4M,
  output logic [4:0]  rdM);
  pipereg #(105) r (.clk, .rst, .en(1'b1), .clr(1'b0),
    .d({ctrlE, aluresultE, writedataE, rdE, pcplus4E}),
    .q({ctrlM, aluresultM, writedataM, rdM, pcplus4M}));
endmodule

module reg_MW (
  input  logic        clk, rst,
  input  logic [2:0]  ctrlM,
  input  logic [31:0] aluresultM, readdataM, pcplus4M,
  input  logic [4:0]  rdM,
  output logic [2:0]  ctrlW,
  output logic [31:0] aluresultW, readdataW, pcplus4W,
  output logic [4:0]  rdW);
  pipereg #(104) r (.clk, .rst, .en(1'b1), .clr(1'b0),
    .d({ctrlM, aluresultM, readdataM, rdM, pcplus4M}),
    .q({ctrlW, aluresultW, readdataW, rdW, pcplus4W}));
endmodule

module stage_W (
  input  logic [2:0]  ctrlW,
  input  logic [31:0] aluresultW, readdataW, pcplus4W,
  output logic [31:0] resultW,
  output logic        regwriteW);
  mux3 #(32) resmux (.d0(aluresultW), .d1(readdataW), .d2(pcplus4W), .s(ctrlW[1:0]), .y(resultW));
  assign regwriteW = ctrlW[2];
endmodule

module rv_pipe (
  input  logic        clk, rst,
  output logic [31:0] pcF,
  input  logic [31:0] instrF,
  output logic        memwriteM,
  output logic [31:0] aluresultM, writedataM,
  input  logic [31:0] readdataM);

  logic        stallF, stallD, flushD, flushE, pcsrcE, regwriteW;
  logic [1:0]  fwdAE, fwdBE;
  logic [2:0]  ctrlW;
  logic [3:0]  ctrlM;
  logic [9:0]  ctrlD, ctrlE;
  logic [4:0]  rs1D, rs2D, rdD, rs1E, rs2E, rdE, rdM, rdW;
  logic [31:0] pcplus4F, instrD, pcD, pcplus4D, immextD, rd1D, rd2D,
               rd1E, rd2E, pcE, immextE, pcplus4E, aluresultE, writedataE, pctargetE,
               pcplus4M, aluresultW, readdataW, pcplus4W, resultW;

  stage_F sF  (.clk, .rst, .stallF, .pcsrcE, .pctargetE, .pcF, .pcplus4F);
  reg_FD  rFD (.clk, .rst, .en(~stallD), .clr(flushD), .instrF, .pcF, .pcplus4F,
               .instrD, .pcD, .pcplus4D);
  stage_D sD  (.instrD, .ctrlD, .immextD, .rs1D, .rs2D, .rdD);
  regfile rf  (.clk, .we(regwriteW), .a1(rs1D), .a2(rs2D), .a3(rdW),
               .wd(resultW), .rd1(rd1D), .rd2(rd2D));
  reg_DE  rDE (.clk, .rst, .clr(flushE), .ctrlD, .rd1D, .rd2D, .pcD, .immextD, .pcplus4D,
               .rs1D, .rs2D, .rdD, .ctrlE, .rd1E, .rd2E, .pcE, .immextE, .pcplus4E,
               .rs1E, .rs2E, .rdE);
  stage_E sE  (.ctrlE, .rd1E, .rd2E, .pcE, .immextE, .resultW, .aluresultM, .fwdAE, .fwdBE,
               .aluresultE, .writedataE, .pctargetE, .pcsrcE);
  reg_EM  rEM (.clk, .rst, .ctrlE(ctrlE[9:6]), .aluresultE, .writedataE, .pcplus4E, .rdE,
               .ctrlM, .aluresultM, .writedataM, .pcplus4M, .rdM);
  assign memwriteM = ctrlM[0];
  reg_MW  rMW (.clk, .rst, .ctrlM(ctrlM[3:1]), .aluresultM, .readdataM, .pcplus4M, .rdM,
               .ctrlW, .aluresultW, .readdataW, .pcplus4W, .rdW);
  stage_W sW  (.ctrlW, .aluresultW, .readdataW, .pcplus4W, .resultW, .regwriteW);
  hazard  hu  (.rs1D, .rs2D, .rs1E, .rs2E, .rdE, .rdM, .rdW,
               .pcsrcE, .resultsrcE0(ctrlE[7]), .regwriteM(ctrlM[3]), .regwriteW,
               .fwdAE, .fwdBE, .stallF, .stallD, .flushD, .flushE);
endmodule

module top_pipe (input logic clk, rst);
  logic [31:0] pc, instr, readdata, dataadr, writedata;
  logic        memwrite;
  rv_pipe cpu (.clk, .rst, .pcF(pc), .instrF(instr), .memwriteM(memwrite),
               .aluresultM(dataadr), .writedataM(writedata), .readdataM(readdata));
  imem im (.a(pc), .rd(instr));
  dmem dm (.clk, .we(memwrite), .a(dataadr), .wd(writedata), .rd(readdata));
endmodule
