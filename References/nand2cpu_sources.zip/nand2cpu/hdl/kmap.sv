// kmap.sv — worked examples for canonical forms and Karnaugh-map minimization.

// BCD-to-7-segment, segment e (lit for digits 0, 2, 6, 8; codes 10–15 never occur).
// (1) canonical sum of products: one minterm per digit that lights the segment
module seg_e_canonical (input logic [3:0] d, output logic e);   // d = {A,B,C,D}
  assign e = (~d[3] & ~d[2] & ~d[1] & ~d[0])    // m0
           | (~d[3] & ~d[2] &  d[1] & ~d[0])    // m2
           | (~d[3] &  d[2] &  d[1] & ~d[0])    // m6
           | ( d[3] & ~d[2] & ~d[1] & ~d[0]);   // m8
endmodule

// (2) minimal SoP from the K-map with don't-cares, e = B'D' + CD', as NAND-NAND
module seg_e_sop_nand (input logic [3:0] d, output logic e);
  logic nb, nd, t1, t2;
  nand2 i1 (.a(d[2]), .b(d[2]), .y(nb));        // B'
  nand2 i2 (.a(d[0]), .b(d[0]), .y(nd));        // D'
  nand2 p1 (.a(nb),   .b(nd),   .y(t1));        // NOT(B'D')
  nand2 p2 (.a(d[1]), .b(nd),   .y(t2));        // NOT(CD')
  nand2 s  (.a(t1),   .b(t2),   .y(e));         // OR of the two products
endmodule

// (3) minimal PoS from the K-map (grouping the zeros), e = D'(B' + C)
module seg_e_pos (input logic [3:0] d, output logic e);
  assign e = ~d[0] & (~d[2] | d[1]);
endmodule

// Majority function (the full adder's carry) in minimal SoP and PoS forms
module maj_sop (input logic a, b, c, output logic y);
  assign y = (a & b) | (a & c) | (b & c);
endmodule
module maj_pos (input logic a, b, c, output logic y);
  assign y = (a | b) & (a | c) & (b | c);
endmodule
