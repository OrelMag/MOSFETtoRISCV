// rv_pipe_bp.sv — the five-stage pipeline of rv_pipe.sv plus dynamic branch prediction:
// a 16-entry branch-target buffer (BTB) with a 2-bit saturating counter per entry.
// Prediction happens in Fetch; the branch is still resolved in Execute, and only a
// MISprediction flushes the two younger instructions.

module bpred (
  input  logic        clk, rst,
  input  logic [31:0] pcF,
  output logic        predTakenF,
  output logic [31:0] predTargetF,
  input  logic        updE,            // a branch or jump is in Execute
  input  logic [31:0] pcE, targetE,
  input  logic        takenE, isJumpE);
  logic        valid [16];
  logic [25:0] tag   [16];
  logic [31:0] tgt   [16];
  logic [1:0]  ctr   [16];             // 00/01 predict not taken, 10/11 predict taken
  logic        jmp   [16];
  logic [3:0]  iF, iE;
  logic        hitF, hitE;
  assign iF = pcF[5:2];
  assign iE = pcE[5:2];
  assign hitF = valid[iF] && (tag[iF] == pcF[31:6]);
  assign hitE = valid[iE] && (tag[iE] == pcE[31:6]);
  assign predTakenF  = hitF && (jmp[iF] || ctr[iF][1]);
  assign predTargetF = tgt[iF];
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < 16; k++) valid[k] <= 1'b0;
    end else if (updE) begin
      valid[iE] <= 1'b1;
      tag[iE]   <= pcE[31:6];
      tgt[iE]   <= targetE;
      jmp[iE]   <= isJumpE;
      if (!hitE)       ctr[iE] <= takenE ? 2'b10 : 2'b01;         // new entry: weak
      else if (takenE) ctr[iE] <= (ctr[iE] == 2'b11) ? 2'b11 : ctr[iE] + 2'b01;
      else             ctr[iE] <= (ctr[iE] == 2'b00) ? 2'b00 : ctr[iE] - 2'b01;
    end
  end
endmodule

module rv_pipe_bp (
  input  logic        clk, rst,
  output logic [31:0] pcF,
  input  logic [31:0] instrF,
  output logic        memwriteM,
  output logic [31:0] aluresultM, writedataM,
  input  logic [31:0] readdataM);

  logic        stallF, stallD, flushD, flushE, pcsrcE, regwriteW, mispredictE;
  logic [1:0]  fwdAE, fwdBE;
  logic [2:0]  ctrlW;
  logic [3:0]  ctrlM;
  logic [9:0]  ctrlD, ctrlE;
  logic [4:0]  rs1D, rs2D, rdD, rs1E, rs2E, rdE, rdM, rdW;
  logic [31:0] pcplus4F, pcnextF, instrD, pcD, pcplus4D, immextD, rd1D, rd2D,
               rd1E, rd2E, pcE, immextE, pcplus4E, aluresultE, writedataE, pctargetE,
               pcplus4M, aluresultW, readdataW, pcplus4W, resultW;
  logic        predTakenF, predTakenD, predTakenE;
  logic [31:0] predTargetF, predTargetD, predTargetE, correctPC;

  // ---- Fetch: predicted next PC, overridden by the Execute-stage correction
  bpred bp (.clk, .rst, .pcF, .predTakenF, .predTargetF,
            .updE(ctrlE[4] | ctrlE[5]), .pcE, .targetE(pctargetE),
            .takenE(pcsrcE), .isJumpE(ctrlE[5]));
  assign correctPC = pcsrcE ? pctargetE : pcplus4E;
  assign pcnextF   = mispredictE ? correctPC : (predTakenF ? predTargetF : pcplus4F);
  pipereg #(32) pcreg  (.clk, .rst, .en(~stallF), .clr(1'b0), .d(pcnextF), .q(pcF));
  adder   #(32) pcadd4 (.a(pcF), .b(32'd4), .y(pcplus4F));

  reg_FD  rFD (.clk, .rst, .en(~stallD), .clr(flushD), .instrF, .pcF, .pcplus4F,
               .instrD, .pcD, .pcplus4D);
  pipereg #(33) pFD (.clk, .rst, .en(~stallD), .clr(flushD),
                     .d({predTakenF, predTargetF}), .q({predTakenD, predTargetD}));
  stage_D sD  (.instrD, .ctrlD, .immextD, .rs1D, .rs2D, .rdD);
  regfile rf  (.clk, .we(regwriteW), .a1(rs1D), .a2(rs2D), .a3(rdW),
               .wd(resultW), .rd1(rd1D), .rd2(rd2D));
  reg_DE  rDE (.clk, .rst, .clr(flushE), .ctrlD, .rd1D, .rd2D, .pcD, .immextD, .pcplus4D,
               .rs1D, .rs2D, .rdD, .ctrlE, .rd1E, .rd2E, .pcE, .immextE, .pcplus4E,
               .rs1E, .rs2E, .rdE);
  pipereg #(33) pDE (.clk, .rst, .en(1'b1), .clr(flushE),
                     .d({predTakenD, predTargetD}), .q({predTakenE, predTargetE}));
  stage_E sE  (.ctrlE, .rd1E, .rd2E, .pcE, .immextE, .resultW, .aluresultM, .fwdAE, .fwdBE,
               .aluresultE, .writedataE, .pctargetE, .pcsrcE);
  // Misprediction: wrong direction, or right direction with a wrong target.
  assign mispredictE = (ctrlE[4] | ctrlE[5])
                       ? ((pcsrcE != predTakenE) || (pcsrcE && (predTargetE != pctargetE)))
                       : predTakenE;
  reg_EM  rEM (.clk, .rst, .ctrlE(ctrlE[9:6]), .aluresultE, .writedataE, .pcplus4E, .rdE,
               .ctrlM, .aluresultM, .writedataM, .pcplus4M, .rdM);
  assign memwriteM = ctrlM[0];
  reg_MW  rMW (.clk, .rst, .ctrlM(ctrlM[3:1]), .aluresultM, .readdataM, .pcplus4M, .rdM,
               .ctrlW, .aluresultW, .readdataW, .pcplus4W, .rdW);
  stage_W sW  (.ctrlW, .aluresultW, .readdataW, .pcplus4W, .resultW, .regwriteW);
  // The hazard unit is unchanged; it now flushes on a misprediction instead of every taken branch.
  hazard  hu  (.rs1D, .rs2D, .rs1E, .rs2E, .rdE, .rdM, .rdW,
               .pcsrcE(mispredictE), .resultsrcE0(ctrlE[7]), .regwriteM(ctrlM[3]), .regwriteW,
               .fwdAE, .fwdBE, .stallF, .stallD, .flushD, .flushE);
endmodule

module top_pipe_bp (input logic clk, rst);
  logic [31:0] pc, instr, readdata, dataadr, writedata;
  logic        memwrite;
  rv_pipe_bp cpu (.clk, .rst, .pcF(pc), .instrF(instr), .memwriteM(memwrite),
                  .aluresultM(dataadr), .writedataM(writedata), .readdataM(readdata));
  imem im (.a(pc), .rd(instr));
  dmem dm (.clk, .we(memwrite), .a(dataadr), .wd(writedata), .rd(readdata));
endmodule
