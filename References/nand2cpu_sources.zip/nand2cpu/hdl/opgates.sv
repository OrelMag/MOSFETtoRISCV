// opgates.sv — what the word-level operator symbols (+, −, =, <) mean at gate level.
// (1) op_* : one operator each, synthesized by Yosys and drawn after lowering to gates.
// (2) *_n  : the same functions built only from this primer's NAND-structural cells.

module op_add #(parameter int N = 4) (input logic [N-1:0] a, b, output logic [N-1:0] y);
  assign y = a + b;                               // the "+" circle
endmodule
module op_sub #(parameter int N = 4) (input logic [N-1:0] a, b, output logic [N-1:0] y);
  assign y = a - b;                               // the "−" circle
endmodule
module op_eq #(parameter int N = 4) (input logic [N-1:0] a, b, output logic y);
  assign y = (a == b);                            // the "=" circle
endmodule
module op_lt #(parameter int N = 4) (input logic [N-1:0] a, b, output logic y);
  assign y = (a < b);                             // the "<" circle (unsigned)
endmodule

// Subtractor: a − b = a + ~b + 1. The carry-out is 1 exactly when a >= b (no borrow).
module sub_n #(parameter int N = 4) (input logic [N-1:0] a, b,
                                     output logic [N-1:0] y, output logic nborrow);
  logic [N-1:0] nb;
  for (genvar i = 0; i < N; i++) begin : g_inv
    not_n u (.a(b[i]), .y(nb[i]));
  end
  rca #(N) add (.a(a), .b(nb), .cin(1'b1), .s(y), .cout(nborrow));
endmodule

// Equality: one XOR per bit marks a difference; an OR tree collects them; NOT gives "equal".
// N must be a power of two (the OR tree is a complete binary tree).
module eq_n #(parameter int N = 4) (input logic [N-1:0] a, b, output logic y);
  logic [2*N-2:0] t;                               // heap-ordered tree: leaves N-1 .. 2N-2
  for (genvar i = 0; i < N; i++) begin : g_leaf
    xor_n ux (.a(a[i]), .b(b[i]), .y(t[N-1+i]));
  end
  for (genvar k = N-2; k >= 0; k--) begin : g_node
    or_n uo (.a(t[2*k+1]), .b(t[2*k+2]), .y(t[k]));
  end
  not_n un (.a(t[0]), .y(y));
endmodule

// Unsigned less-than: a < b exactly when a − b borrows (carry-out of a + ~b + 1 is 0).
module ltu_n #(parameter int N = 4) (input logic [N-1:0] a, b, output logic y);
  logic [N-1:0] diff; logic nborrow;
  sub_n #(N) s (.a, .b, .y(diff), .nborrow);
  not_n u (.a(nborrow), .y(y));
endmodule

// Signed less-than: if the signs differ, a < b exactly when a is negative;
// if they agree, the unsigned comparison is correct.
module lts_n #(parameter int N = 4) (input logic [N-1:0] a, b, output logic y);
  logic u, d;
  ltu_n #(N) c (.a, .b, .y(u));
  xor_n  sx (.a(a[N-1]), .b(b[N-1]), .y(d));
  mux2_n m  (.a(u), .b(a[N-1]), .s(d), .y(y));
endmodule

// Word-level cells that the figures draw with ordinary gate or multiplexer symbols.
module op_redor #(parameter int N = 4) (input logic [N-1:0] a, output logic y);
  assign y = |a;                                  // reduction OR: "any bit set" (drawn as OR)
endmodule
module op_lnot #(parameter int N = 4) (input logic [N-1:0] a, output logic y);
  assign y = !a;                                  // logical NOT: "all bits zero" (drawn as NOT)
endmodule
module op_mux #(parameter int N = 4) (input logic [N-1:0] a, b, input logic s,
                                      output logic [N-1:0] y);
  assign y = s ? b : a;                           // word multiplexer (drawn as one trapezoid)
endmodule
module op_pmux #(parameter int N = 4) (input logic [N-1:0] d0, d1, d2, input logic [2:0] s,
                                       output logic [N-1:0] y);
  always_comb begin                               // one-hot "parallel" multiplexer
    y = '0;
    (* parallel_case *)
    case (1'b1)
      s[0]: y = d0;
      s[1]: y = d1;
      s[2]: y = d2;
      default: y = '0;
    endcase
  end
endmodule
