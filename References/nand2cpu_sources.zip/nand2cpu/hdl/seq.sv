// seq.sv — state from feedback
module sr_latch_n (input logic s_n, r_n, output logic q, q_n);
  nand2 g1 (.a(s_n), .b(q_n), .y(q));
  nand2 g2 (.a(r_n), .b(q),   .y(q_n));
endmodule

module d_latch (input logic d, en, output logic q, q_n);
  logic d_n, s_n, r_n;
  nand2 g0 (.a(d),   .b(d),   .y(d_n));
  nand2 g1 (.a(d),   .b(en),  .y(s_n));
  nand2 g2 (.a(d_n), .b(en),  .y(r_n));
  nand2 g3 (.a(s_n), .b(q_n), .y(q));
  nand2 g4 (.a(r_n), .b(q),   .y(q_n));
endmodule

// Positive-edge master–slave flip-flop from two gated latches
module dff_ms (input logic d, clk, output logic q);
  logic clk_n, m, m_n, q_n;
  nand2   gi     (.a(clk), .b(clk), .y(clk_n));
  d_latch master (.d(d), .en(clk_n), .q(m), .q_n(m_n));
  d_latch slave  (.d(m), .en(clk),   .q(q), .q_n(q_n));
endmodule

// Behavioral register: synchronous reset, load enable
module register #(parameter int W = 4) (
  input  logic         clk, rst, en,
  input  logic [W-1:0] d,
  output logic [W-1:0] q);
  always_ff @(posedge clk)
    if (rst)     q <= '0;
    else if (en) q <= d;
endmodule

module counter #(parameter int W = 4) (
  input  logic         clk, rst, en,
  output logic [W-1:0] q);
  always_ff @(posedge clk)
    if (rst)     q <= '0;
    else if (en) q <= q + 1'b1;
endmodule

// 4 × 4-bit register file: 2-bit write decoder, per-row enables, two read muxes.
module regfile4 (
  input  logic       clk, we,
  input  logic [1:0] wa, ra1, ra2,
  input  logic [3:0] wd,
  output logic [3:0] rd1, rd2);
  logic [3:0] r0, r1, r2, r3;
  always_ff @(posedge clk) begin
    if (we && wa == 2'd0) r0 <= wd;
    if (we && wa == 2'd1) r1 <= wd;
    if (we && wa == 2'd2) r2 <= wd;
    if (we && wa == 2'd3) r3 <= wd;
  end
  always_comb begin
    case (ra1) 2'd0: rd1 = r0; 2'd1: rd1 = r1; 2'd2: rd1 = r2; default: rd1 = r3; endcase
    case (ra2) 2'd0: rd2 = r0; 2'd1: rd2 = r1; 2'd2: rd2 = r2; default: rd2 = r3; endcase
  end
endmodule
