// fpu.sv — IEEE 754 binary32 arithmetic: add/subtract, multiply and compare, with
// round-to-nearest-even, signed zeros, subnormals, infinities and the RISC-V canonical NaN.
// Operands are unpacked as significand m (24 bits, explicit leading bit) and biased
// exponent E (subnormals use E = 1), so that value = m × 2^(E − 127 − 23).

// Leading-zero counter in logarithmic depth: at each stage test whether the top 2^k bits are
// all zero and, if so, shift them out. The input must contain at least one 1.
module lzc64 (input logic [63:0] x, output logic [5:0] lz);
  logic [63:0] s1, s2, s3, s4, s5;
  logic z32, z16, z8, z4, z2, z1;
  assign z32 = ~|x[63:32];  assign s1 = z32 ? {x[31:0], 32'd0}  : x;
  assign z16 = ~|s1[63:48]; assign s2 = z16 ? {s1[47:0], 16'd0} : s1;
  assign z8  = ~|s2[63:56]; assign s3 = z8  ? {s2[55:0], 8'd0}  : s2;
  assign z4  = ~|s3[63:60]; assign s4 = z4  ? {s3[59:0], 4'd0}  : s3;
  assign z2  = ~|s4[63:62]; assign s5 = z2  ? {s4[61:0], 2'd0}  : s4;
  assign z1  = ~s5[63];
  assign lz  = {z32, z16, z8, z4, z2, z1};
endmodule

module fp_mul32 (input logic [31:0] a, b, output logic [31:0] y);
  localparam logic [31:0] QNAN = 32'h7FC0_0000;          // RISC-V canonical NaN
  logic        sa, sb, sy;
  logic [7:0]  ea, eb;
  logic [22:0] fa, fb;
  logic        nana, nanb, infa, infb, za, zb;
  logic [23:0] ma, mb;
  logic [9:0]  Ea, Eb;
  logic [47:0] P, Pn, Ps;
  logic [5:0]  lz;
  logic signed [11:0] Er;
  logic [11:0] sh;
  logic        stk, g, st, inc;
  logic [24:0] rnd;
  logic [11:0] Ef;
  logic [31:0] fin;
  assign {sa, ea, fa} = a;
  assign {sb, eb, fb} = b;
  assign sy   = sa ^ sb;
  assign nana = (ea == 8'hFF) && (fa != 0);
  assign nanb = (eb == 8'hFF) && (fb != 0);
  assign infa = (ea == 8'hFF) && (fa == 0);
  assign infb = (eb == 8'hFF) && (fb == 0);
  assign za   = (ea == 8'h00) && (fa == 0);
  assign zb   = (eb == 8'h00) && (fb == 0);
  assign ma   = {ea != 0, fa};
  assign mb   = {eb != 0, fb};
  assign Ea   = (ea == 0) ? 10'd1 : {2'b00, ea};
  assign Eb   = (eb == 0) ? 10'd1 : {2'b00, eb};
  assign P    = ma * mb;                                  // exact 48-bit product
  lzc64 clz (.x({P, 16'hFFFF}), .lz(lz));                // padding bounds the count at 48
  assign Pn = P << lz;                                    // leading one at bit 47
  assign Er = $signed({2'b00, Ea}) + $signed({2'b00, Eb}) - 12'sd126 - $signed({6'b0, lz});
  always_comb begin                                       // gradual underflow
    if (Er < 12'sd1) begin
      sh = 12'(12'sd1 - Er);
      if (sh >= 12'd48) begin Ps = '0; stk = |Pn; end
      else begin Ps = Pn >> sh; stk = |(Pn & ((48'd1 << sh) - 48'd1)); end
    end else begin
      sh = '0; Ps = Pn; stk = 1'b0;
    end
  end
  assign g   = Ps[23];                                    // guard bit
  assign st  = (|Ps[22:0]) | stk;                         // sticky bit
  assign inc = g & (st | Ps[24]);                         // round to nearest, ties to even
  assign rnd = {1'b0, Ps[47:24]} + {24'd0, inc};
  always_comb begin
    if (Er >= 12'sd1) begin                               // normal result
      Ef  = 12'(Er) + {11'd0, rnd[24]};
      fin = (Ef >= 12'd255) ? {sy, 8'hFF, 23'd0}          // overflow -> infinity
                            : {sy, Ef[7:0], rnd[24] ? rnd[23:1] : rnd[22:0]};
    end else begin                                        // subnormal (or rounds up to normal)
      Ef  = {11'd0, rnd[23]};
      fin = {sy, Ef[7:0], rnd[22:0]};
    end
  end
  always_comb
    if (nana || nanb || (infa && zb) || (infb && za)) y = QNAN;
    else if (infa || infb)                          y = {sy, 8'hFF, 23'd0};
    else if (za || zb)                              y = {sy, 31'd0};
    else                                            y = fin;
endmodule

module fp_add32 (input logic [31:0] a, b, input logic sub, output logic [31:0] y);
  localparam logic [31:0] QNAN = 32'h7FC0_0000;
  logic        sa, sb, sB, sS, eff_sub;
  logic [7:0]  ea, eb;
  logic [22:0] fa, fb;
  logic        nana, nanb, infa, infb, za, zb, a_big;
  logic [23:0] ma, mb, mB, mS;
  logic [9:0]  Ea, Eb, EB, ES, d;
  logic [26:0] bg, sm, t;
  logic [27:0] S, Sn;
  logic [4:0]  lz;
  logic [9:0]  shl, E;
  logic        g, st, inc;
  logic [24:0] rnd;
  logic [10:0] Ef;
  logic [31:0] fin;
  assign {sa, ea, fa} = a;
  assign eb   = b[30:23];
  assign fb   = b[22:0];
  assign sb   = b[31] ^ sub;                              // a − b = a + (−b)
  assign nana = (ea == 8'hFF) && (fa != 0);
  assign nanb = (eb == 8'hFF) && (fb != 0);
  assign infa = (ea == 8'hFF) && (fa == 0);
  assign infb = (eb == 8'hFF) && (fb == 0);
  assign za   = (ea == 8'h00) && (fa == 0);
  assign zb   = (eb == 8'h00) && (fb == 0);
  assign ma   = {ea != 0, fa};
  assign mb   = {eb != 0, fb};
  assign Ea   = (ea == 0) ? 10'd1 : {2'b00, ea};
  assign Eb   = (eb == 0) ? 10'd1 : {2'b00, eb};
  // order the operands by magnitude
  assign a_big = {Ea, ma} >= {Eb, mb};
  assign {sB, EB, mB} = a_big ? {sa, Ea, ma} : {sb, Eb, mb};
  assign {sS, ES, mS} = a_big ? {sb, Eb, mb} : {sa, Ea, ma};
  assign d  = EB - ES;
  assign bg = {mB, 3'b000};                               // guard, round, sticky positions
  always_comb begin                                       // align the smaller operand
    t = '0;
    if (d >= 10'd27) sm = {26'd0, |mS};
    else begin
      t  = {mS, 3'b000} >> d;
      sm = t | {26'd0, |({mS, 3'b000} & ((27'd1 << d) - 27'd1))};   // jam lost bits into sticky
    end
  end
  assign eff_sub = sB ^ sS;
  assign S = eff_sub ? ({1'b0, bg} - {1'b0, sm}) : ({1'b0, bg} + {1'b0, sm});
  logic [5:0] lz6;
  lzc64 clz (.x({S[26:0], 37'h1F_FFFF_FFFF}), .lz(lz6));   // leading zeros of S[26:0], at most 27
  assign lz = lz6[4:0];
  always_comb begin                                       // normalize
    if (S[27]) begin
      Sn = {1'b0, S[27:1]} | {27'd0, S[0]};
      E  = EB + 10'd1;
      shl = '0;
    end else begin
      shl = ({5'd0, lz} < (EB - 10'd1)) ? {5'd0, lz} : (EB - 10'd1);  // stop at the subnormal range
      Sn  = S << shl;
      E   = EB - shl;
    end
  end
  assign g   = Sn[2];
  assign st  = Sn[1] | Sn[0];
  assign inc = g & (st | Sn[3]);
  assign rnd = {1'b0, Sn[26:3]} + {24'd0, inc};
  always_comb begin
    if (rnd[24])      Ef = {1'b0, E} + 11'd1;             // rounding overflowed the significand
    else if (rnd[23]) Ef = {1'b0, E};
    else              Ef = 11'd0;                         // subnormal result (E is 1 here)
    if (Ef >= 11'd255) fin = {sB, 8'hFF, 23'd0};
    else               fin = {sB, Ef[7:0], rnd[24] ? rnd[23:1] : rnd[22:0]};
  end
  always_comb
    if (nana || nanb || (infa && infb && (sa != sb))) y = QNAN;
    else if (infa)                  y = {sa, 8'hFF, 23'd0};
    else if (infb)                  y = {sb, 8'hFF, 23'd0};
    else if (za && zb)              y = {sa & sb, 31'd0};  // +0 unless both are −0
    else if (za)                    y = {sb, eb, fb};
    else if (zb)                    y = a;
    else if (S == 28'd0)            y = 32'd0;             // exact cancellation gives +0
    else                            y = fin;
endmodule

// Comparisons (quiet): any NaN makes all three false; +0 equals −0.
module fp_cmp32 (input logic [31:0] a, b, output logic feq, flt, fle);
  logic nan, bothz, mag_lt, mag_gt;
  assign nan    = ((a[30:23] == 8'hFF) && (a[22:0] != 0)) || ((b[30:23] == 8'hFF) && (b[22:0] != 0));
  assign bothz  = (a[30:0] == 0) && (b[30:0] == 0);
  assign mag_lt = a[30:0] < b[30:0];
  assign mag_gt = a[30:0] > b[30:0];
  assign feq = !nan && ((a == b) || bothz);
  assign flt = !nan && !bothz && ((a[31] != b[31]) ? a[31] : (a[31] ? mag_gt : mag_lt));
  assign fle = flt | feq;
endmodule

// op: 0 = add, 1 = subtract, 2 = multiply
module fpu_core (input logic [31:0] a, b, input logic [1:0] op,
                 output logic [31:0] y, output logic [2:0] cmp);
  logic [31:0] ys, ym;
  fp_add32 addsub (.a, .b, .sub(op[0]), .y(ys));
  fp_mul32 mul    (.a, .b, .y(ym));
  fp_cmp32 cmpu   (.a, .b, .feq(cmp[0]), .flt(cmp[1]), .fle(cmp[2]));
  assign y = op[1] ? ym : ys;
endmodule

// Memory-mapped FPU: offsets 0x00 A, 0x04 B, 0x08 OP (writable); 0x0C RESULT, 0x10 CMP (read-only)
module fpu_mmio (
  input  logic        clk, rst, sel, we,
  input  logic [4:0]  off,
  input  logic [31:0] wd,
  output logic [31:0] rd);
  logic [31:0] ra, rb, y;
  logic [1:0]  rop;
  logic [2:0]  cmp;
  fpu_core core (.a(ra), .b(rb), .op(rop), .y, .cmp);
  always_ff @(posedge clk)
    if (rst) begin ra <= '0; rb <= '0; rop <= '0; end
    else if (sel && we)
      case (off)
        5'h00: ra  <= wd;
        5'h04: rb  <= wd;
        5'h08: rop <= wd[1:0];
        default: ;
      endcase
  always_comb
    case (off)
      5'h00:   rd = ra;
      5'h04:   rd = rb;
      5'h08:   rd = {30'd0, rop};
      5'h0C:   rd = y;
      5'h10:   rd = {29'd0, cmp};
      default: rd = '0;
    endcase
endmodule
