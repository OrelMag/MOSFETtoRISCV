// rv_blocks.sv — shared RV32I building blocks (subset: add sub and or slt,
// addi andi ori slti, lw, sw, beq, jal)

module adder #(parameter int W = 32) (input logic [W-1:0] a, b, output logic [W-1:0] y);
  assign y = a + b;
endmodule

module mux2 #(parameter int W = 32) (input logic [W-1:0] d0, d1, input logic s,
                                     output logic [W-1:0] y);
  assign y = s ? d1 : d0;
endmodule

module mux3 #(parameter int W = 32) (input logic [W-1:0] d0, d1, d2, input logic [1:0] s,
                                     output logic [W-1:0] y);
  assign y = s[1] ? d2 : (s[0] ? d1 : d0);
endmodule

module flopr #(parameter int W = 32) (input logic clk, rst, input logic [W-1:0] d,
                                      output logic [W-1:0] q);
  always_ff @(posedge clk) q <= rst ? '0 : d;
endmodule

// Pipeline register: enable (stall) and synchronous clear (flush)
module pipereg #(parameter int W = 32) (input logic clk, rst, en, clr,
                                        input logic [W-1:0] d, output logic [W-1:0] q);
  always_ff @(posedge clk)
    if (rst | clr) q <= '0;
    else if (en)   q <= d;
endmodule

// ALUControl: 000 add, 001 sub, 010 and, 011 or, 101 slt
module alu #(parameter int W = 32) (
  input  logic [W-1:0] a, b,
  input  logic [2:0]   ctrl,
  output logic [W-1:0] y,
  output logic         zero);
  logic [W-1:0] bb, sum;
  logic [W:0]   ext;
  logic         v, lt;
  assign bb  = ctrl[0] ? ~b : b;                 // invert for sub / slt
  // One adder: the extra low bit turns ctrl[0] into the carry-in (+1 completes two's
  // complement). Writing a + bb + ctrl[0] instead synthesizes two chained adders.
  assign ext = {a, 1'b1} + {bb, ctrl[0]};
  assign sum = ext[W:1];
  assign v   = ~(a[W-1] ^ bb[W-1]) & (a[W-1] ^ sum[W-1]);  // signed overflow
  assign lt  = sum[W-1] ^ v;                      // true sign of a-b
  always_comb
    case (ctrl)
      3'b000, 3'b001: y = sum;
      3'b010:         y = a & b;
      3'b011:         y = a | b;
      3'b101:         y = {{(W-1){1'b0}}, lt};
      default:        y = '0;
    endcase
  assign zero = (y == '0);
endmodule

// ImmSrc: 00 I, 01 S, 10 B, 11 J
module extend (input logic [31:7] instr, input logic [1:0] immsrc,
               output logic [31:0] immext);
  logic [31:0] immI, immS, immB, immJ;
  assign immI = {{20{instr[31]}}, instr[31:20]};
  assign immS = {{20{instr[31]}}, instr[31:25], instr[11:7]};
  assign immB = {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0};
  assign immJ = {{12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0};
  assign immext = immsrc[1] ? (immsrc[0] ? immJ : immB)
                            : (immsrc[0] ? immS : immI);
endmodule

// Register file. With FALLING = 1 (the pipeline's choice) it is written on the falling
// clock edge, so a value written in the first half of a cycle can be read in the second
// half (removes one WB->ID hazard). The single-cycle and multicycle cores write on the
// rising edge (FALLING = 0), which gives their write-back paths a full clock cycle.
module regfile #(parameter bit FALLING = 1'b1) (
  input  logic        clk, we,
  input  logic [4:0]  a1, a2, a3,
  input  logic [31:0] wd,
  output logic [31:0] rd1, rd2);
  logic [31:0] rf [31:0];
  initial for (int i = 0; i < 32; i++) rf[i] = 32'd0;   // defined power-up state (simulation)
  if (FALLING) begin : g_fall
    always_ff @(negedge clk) if (we) rf[a3] <= wd;
  end else begin : g_rise
    always_ff @(posedge clk) if (we) rf[a3] <= wd;
  end
  assign rd1 = (a1 != 5'd0) ? rf[a1] : 32'd0;
  assign rd2 = (a2 != 5'd0) ? rf[a2] : 32'd0;
endmodule

// Main decoder + ALU decoder
module controller (
  input  logic [6:0] op,
  input  logic [2:0] funct3,
  input  logic       funct7b5,
  output logic       regwrite, alusrc, memwrite, branch, jump,
  output logic [1:0] resultsrc, immsrc,
  output logic [2:0] alucontrol);
  logic [1:0] aluop;
  logic       rtypesub;
  always_comb begin
    // defaults
    {regwrite, immsrc, alusrc, memwrite, resultsrc, branch, aluop, jump} = '0;
    case (op)
      7'b0110011: begin regwrite = 1; aluop = 2'b10; end                        // R-type
      7'b0010011: begin regwrite = 1; alusrc = 1; aluop = 2'b10; end            // I-type ALU
      7'b0000011: begin regwrite = 1; alusrc = 1; resultsrc = 2'b01; end        // lw
      7'b0100011: begin immsrc = 2'b01; alusrc = 1; memwrite = 1; end           // sw
      7'b1100011: begin immsrc = 2'b10; branch = 1; aluop = 2'b01; end          // beq
      7'b1101111: begin regwrite = 1; immsrc = 2'b11; resultsrc = 2'b10; jump = 1; end // jal
      default: ;
    endcase
  end
  assign rtypesub = funct7b5 & op[5];      // only R-type distinguishes add/sub
  always_comb
    case (aluop)
      2'b00: alucontrol = 3'b000;
      2'b01: alucontrol = 3'b001;
      default:
        case (funct3)
          3'b000:  alucontrol = rtypesub ? 3'b001 : 3'b000;
          3'b010:  alucontrol = 3'b101;
          3'b110:  alucontrol = 3'b011;
          3'b111:  alucontrol = 3'b010;
          default: alucontrol = 3'b000;
        endcase
    endcase
endmodule

module imem (input logic [31:0] a, output logic [31:0] rd);
  logic [31:0] rom [0:63];
  initial $readmemh("prog.hex", rom);
  assign rd = rom[a[31:2]];
endmodule

module dmem (input logic clk, we, input logic [31:0] a, wd, output logic [31:0] rd);
  logic [31:0] ram [0:63];
  initial for (int i = 0; i < 64; i++) ram[i] = 32'd0;  // defined power-up state (simulation)
  always_ff @(posedge clk) if (we) ram[a[31:2]] <= wd;
  assign rd = ram[a[31:2]];
endmodule
