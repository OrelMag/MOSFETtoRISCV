// formal.sv — property wrappers proved with Yosys' built-in SAT solver (sat -prove-asserts).
// Every wrapper's inputs are unconstrained, so a proof covers ALL input values.

// F1: the 32-bit Kogge–Stone adder, the 32-bit ripple adder and the '+' operator agree.
module prop_adders (input logic [31:0] a, b, input logic cin);
  logic [31:0] s1, s2; logic c1, c2;
  ks_adder #(32) ks (.a, .b, .cin, .s(s1), .cout(c1));
  rca      #(32) rc (.a, .b, .cin, .s(s2), .cout(c2));
  always_comb begin
    assert ({c1, s1} == {1'b0, a} + {1'b0, b} + {32'b0, cin});
    assert ({c2, s2} == {c1, s1});
  end
endmodule

// F2: the generated Dadda multipliers and the array multiplier compute a*b.
module prop_mults (input logic [7:0] a, b);
  logic [15:0] p1, p2, p3;
  mul_array8 m1 (.a, .b, .p(p1));
  dadda8_rca m2 (.a, .b, .p(p2));
  dadda8_ks  m3 (.a, .b, .p(p3));
  always_comb begin
    assert (p1 == {8'b0, a} * {8'b0, b});
    assert (p2 == p1);
    assert (p3 == p1);
  end
endmodule

// F3: the 32-bit ALU meets its specification for every control code and operand pair.
module prop_alu (input logic [31:0] a, b, input logic [2:0] ctrl);
  logic [31:0] y; logic zero;
  alu #(32) dut (.a, .b, .ctrl, .y, .zero);
  always_comb begin
    if (ctrl == 3'b000) assert (y == a + b);
    if (ctrl == 3'b001) assert (y == a - b);
    if (ctrl == 3'b010) assert (y == (a & b));
    if (ctrl == 3'b011) assert (y == (a | b));
    if (ctrl == 3'b101) assert (y == {31'b0, $signed(a) < $signed(b)});
    assert (zero == (y == 32'b0));
  end
endmodule

// F4: hazard-unit safety properties.
module prop_hazard (input logic [4:0] rs1D, rs2D, rs1E, rs2E, rdE, rdM, rdW,
                    input logic pcsrcE, resultsrcE0, regwriteM, regwriteW);
  logic [1:0] fA, fB; logic sF, sD, fD, fE;
  hazard hu (.rs1D, .rs2D, .rs1E, .rs2E, .rdE, .rdM, .rdW, .pcsrcE, .resultsrcE0,
             .regwriteM, .regwriteW, .fwdAE(fA), .fwdBE(fB), .stallF(sF), .stallD(sD),
             .flushD(fD), .flushE(fE));
  always_comb begin
    assert (fA != 2'b11 && fB != 2'b11);                           // selects are legal
    if (rs1E == 5'd0) assert (fA == 2'b00);                         // x0 is never forwarded
    if (rs2E == 5'd0) assert (fB == 2'b00);
    if (fA == 2'b10) assert (regwriteM && rdM == rs1E);             // forward only from a real writer
    if (fA == 2'b01) assert (regwriteW && rdW == rs1E);
    if (rs1E != 0 && regwriteM && rdM == rs1E) assert (fA == 2'b10); // newest value wins
    assert (sF == sD);                                              // F and D stall together
    if (sD) assert (fE);                                            // a stall always inserts a bubble
    if (pcsrcE) assert (fD && fE);                                  // a redirect squashes both
  end
endmodule

// F5: the write decoder of Appendix C is one-hot and selects exactly the addressed word.
module prop_decoder (input logic [3:0] a, input logic en);
  logic [15:0] y;
  dec4to16 dec (.a, .en, .y);
  always_comb begin
    assert (y == (en ? (16'b1 << a) : 16'b0));
  end
endmodule

// F6: the hardwired and microprogrammed control cores are identical for ALL 16 state
//     codes (including the 5 unused ones) and all 128 opcodes.
module prop_ctl_comb (input logic [3:0] st, input logic [6:0] op);
  logic [3:0] n1, n2; logic [13:0] c1, c2;
  ctl_hw_core h (.state(st), .op, .nxt(n1), .ctrl(c1));
  ctl_mc_core m (.upc(st),   .op, .unext(n2), .ctrl(c2));
  always_comb assert (n1 == n2 && c1 == c2);
endmodule

// F7: sequential equivalence of the two complete controllers from reset, for every
//     input sequence (proved by induction).
module prop_ctl_seq (input logic clk, rst, input logic [6:0] op);
  logic [3:0] s1, s2; logic [13:0] c1, c2;
  ctl_hardwired  h (.clk, .rst, .op, .state(s1), .ctrl(c1));
  ctl_microcoded m (.clk, .rst, .op, .upc(s2),   .ctrl(c2));
  always_comb assert (s1 == s2 && c1 == c2);
endmodule

// F8: the K-map minimizations of segment e agree with the canonical form on every valid
//     BCD code (codes 10–15 are don't-cares and are deliberately left unconstrained).
module prop_kmap (input logic [3:0] d);
  logic e0, e1, e2;
  seg_e_canonical c0 (.d, .e(e0));
  seg_e_sop_nand  c1 (.d, .e(e1));
  seg_e_pos       c2 (.d, .e(e2));
  always_comb if (d < 4'd10) assert (e1 == e0 && e2 == e0);
endmodule

// F9: the minimal SoP and PoS majority forms and the nine-NAND full adder's carry are the
//     same function.
module prop_majority (input logic a, b, c);
  logic y1, y2, s, co;
  maj_sop m1 (.a, .b, .c, .y(y1));
  maj_pos m2 (.a, .b, .c, .y(y2));
  full_adder fa (.a, .b, .cin(c), .s, .cout(co));
  always_comb assert (y1 == y2 && y2 == co);
endmodule

// F10: the NAND-structural operators equal the word-level operators (16 bits; = also at 32).
module prop_ops (input logic [15:0] a, b, input logic [31:0] c, d);
  logic [15:0] s1, s2; logic nbw, e16, e32, lu, ls;
  rca   #(16) ad (.a, .b, .cin(1'b0), .s(s1), .cout());
  sub_n #(16) sb (.a, .b, .y(s2), .nborrow(nbw));
  eq_n  #(16) q1 (.a, .b, .y(e16));
  eq_n  #(32) q2 (.a(c), .b(d), .y(e32));
  ltu_n #(16) l1 (.a, .b, .y(lu));
  lts_n #(16) l2 (.a, .b, .y(ls));
  always_comb begin
    assert (s1 == a + b);
    assert (s2 == a - b && nbw == (a >= b));
    assert (e16 == (a == b) && e32 == (c == d));
    assert (lu == (a < b));
    assert (ls == ($signed(a) < $signed(b)));
  end
endmodule
