// prefix.sv — N-bit Kogge–Stone parallel-prefix adder, NAND-structural.
// Uses the same nand2 / and_n / xor_n cells as the ripple adder so that
// gate depths are directly comparable.

// Group-generate combine in two NAND levels: G = g_hi | (p_hi & g_lo)
//   = NAND( NOT g_hi , NAND(p_hi, g_lo) )
module gcombine (input logic g_hi, p_hi, g_lo, output logic g);
  logic ng, t;
  nand2 u1 (.a(g_hi), .b(g_hi), .y(ng));
  nand2 u2 (.a(p_hi), .b(g_lo), .y(t));
  nand2 u3 (.a(ng),   .b(t),    .y(g));
endmodule

module ks_adder #(parameter int N = 16) (
  input  logic [N-1:0] a, b,
  input  logic         cin,
  output logic [N-1:0] s,
  output logic         cout);
  localparam int K = N + 1;                 // position 0 carries cin (g = cin, p = 0)
  localparam int L = $clog2(K);             // number of prefix levels
  logic [N-1:0] g0, p0;
  logic [K-1:0] G [L+1];
  logic [K-1:0] P [L+1];
  for (genvar j = 0; j < N; j++) begin : g_bit
    and_n ug (.a(a[j]), .b(b[j]), .y(g0[j]));
    xor_n up (.a(a[j]), .b(b[j]), .y(p0[j]));
  end
  assign G[0] = {g0, cin};
  assign P[0] = {p0, 1'b0};
  for (genvar l = 0; l < L; l++) begin : g_lvl
    for (genvar k = 0; k < K; k++) begin : g_pos
      if (k >= (1 << l)) begin : g_comb
        gcombine uc (.g_hi(G[l][k]), .p_hi(P[l][k]), .g_lo(G[l][k-(1<<l)]), .g(G[l+1][k]));
        and_n    ua (.a(P[l][k]), .b(P[l][k-(1<<l)]), .y(P[l+1][k]));
      end else begin : g_pass
        assign G[l+1][k] = G[l][k];
        assign P[l+1][k] = P[l][k];
      end
    end
  end
  // G[L][k] is the carry into bit k (group generate over positions k..0)
  for (genvar j = 0; j < N; j++) begin : g_sum
    xor_n us (.a(p0[j]), .b(G[L][j]), .y(s[j]));
  end
  assign cout = G[L][N];
endmodule
