// rv_single.sv — single-cycle RV32I-subset processor
module rv_single (
  input  logic        clk, rst,
  output logic [31:0] pc,
  input  logic [31:0] instr,
  input  logic [31:0] readdata,
  output logic        memwrite,
  output logic [31:0] aluresult, writedata);

  logic        regwrite, alusrc, branch, jump, zero, pcsrc, memwrite_d;
  logic [1:0]  resultsrc, immsrc;
  logic [2:0]  alucontrol;
  logic [31:0] pcnext, pcplus4, pctarget, immext, srca, srcb, result;

  controller ctl (.op(instr[6:0]), .funct3(instr[14:12]), .funct7b5(instr[30]),
                  .regwrite, .alusrc, .memwrite(memwrite_d), .branch, .jump,
                  .resultsrc, .immsrc, .alucontrol);
  assign pcsrc = (branch & zero) | jump;
  assign memwrite = memwrite_d & ~rst;           // no architectural writes during reset

  flopr   #(32) pcreg (.clk, .rst, .d(pcnext), .q(pc));
  adder   #(32) pcadd4(.a(pc), .b(32'd4), .y(pcplus4));
  adder   #(32) pcaddb(.a(pc), .b(immext), .y(pctarget));
  mux2    #(32) pcmux (.d0(pcplus4), .d1(pctarget), .s(pcsrc), .y(pcnext));

  regfile #(.FALLING(1'b0)) rf (.clk, .we(regwrite & ~rst), .a1(instr[19:15]), .a2(instr[24:20]),
                       .a3(instr[11:7]), .wd(result), .rd1(srca), .rd2(writedata));
  extend        ext   (.instr(instr[31:7]), .immsrc, .immext);
  mux2    #(32) srcbmx(.d0(writedata), .d1(immext), .s(alusrc), .y(srcb));
  alu     #(32) alu0  (.a(srca), .b(srcb), .ctrl(alucontrol), .y(aluresult), .zero);
  mux3    #(32) resmux(.d0(aluresult), .d1(readdata), .d2(pcplus4), .s(resultsrc), .y(result));
endmodule

module top_single (input logic clk, rst);
  logic [31:0] pc, instr, readdata, dataadr, writedata;
  logic        memwrite;
  rv_single cpu (.clk, .rst, .pc, .instr, .readdata, .memwrite,
                 .aluresult(dataadr), .writedata);
  imem im (.a(pc), .rd(instr));
  dmem dm (.clk, .we(memwrite), .a(dataadr), .wd(writedata), .rd(readdata));
endmodule
