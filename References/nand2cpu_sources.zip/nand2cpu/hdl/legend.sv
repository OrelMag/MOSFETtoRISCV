// legend.sv — one of each cell type that appears in the netlist figures
module legend (
  input  logic       clk, s, x, y,
  input  logic [3:0] a, b,
  output logic [3:0] sum, dif, mx, q,
  output logic       eq, lt, g_and, g_or, g_xor, g_not, g_nand);
  assign sum    = a + b;          // $add : adder (circle with +)
  assign dif    = a - b;          // $sub : subtractor (circle with -)
  assign eq     = (a == b);       // $eq  : equality comparator (circle with =)
  assign lt     = (a < b);        // $lt  : less-than comparator
  assign mx     = s ? b : a;      // $mux : 2:1 multiplexer (input 0 on top)
  assign g_and  = x & y;
  assign g_or   = x | y;
  assign g_xor  = x ^ y;
  assign g_not  = ~x;
  assign g_nand = ~(x & y);
  always_ff @(posedge clk) q <= a;  // $dff : D flip-flop bank
endmodule
