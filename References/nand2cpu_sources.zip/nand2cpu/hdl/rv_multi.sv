// rv_multi.sv — multicycle RV32I-subset processor, following the Harris & Harris
// multicycle datapath, driven by either controller of microcode.sv.
// Memories are kept separate (instruction ROM + data RAM, as in Chapters 6–7), so
// AdrSrc selects which memory the shared address addresses: 0 = instruction, 1 = data.

module aludec (input logic [1:0] aluop, input logic [2:0] funct3,
               input logic funct7b5, opb5, output logic [2:0] alucontrol);
  always_comb
    case (aluop)
      2'b00: alucontrol = 3'b000;
      2'b01: alucontrol = 3'b001;
      default:
        case (funct3)
          3'b000:  alucontrol = (funct7b5 & opb5) ? 3'b001 : 3'b000;
          3'b010:  alucontrol = 3'b101;
          3'b110:  alucontrol = 3'b011;
          3'b111:  alucontrol = 3'b010;
          default: alucontrol = 3'b000;
        endcase
    endcase
endmodule

module immdec (input logic [6:0] op, output logic [1:0] immsrc);
  always_comb
    case (op)
      7'b0100011: immsrc = 2'b01;   // sw
      7'b1100011: immsrc = 2'b10;   // beq
      7'b1101111: immsrc = 2'b11;   // jal
      default:    immsrc = 2'b00;   // I-type, lw
    endcase
endmodule

module rv_multi #(parameter bit MICRO = 1'b1) (
  input  logic        clk, rst,
  output logic [31:0] iadr,            // instruction-memory address
  input  logic [31:0] instr_rd,
  output logic [31:0] dadr, dwd,       // data-memory address / write data
  output logic        dwe,
  input  logic [31:0] data_rd,
  output logic [3:0]  state);

  logic [13:0] c;
  logic        adrsrc, irwrite, pcupdate, regwrite, branch, zero, pcwrite;
  logic [1:0]  alusrca, alusrcb, aluop, resultsrc, immsrc;
  logic [2:0]  alucontrol;
  logic [31:0] pc, oldpc, instr, immext, rd1, rd2, a, wdata, srca, srcb,
               aluresult, aluout, data, result;

  // ---- control unit (microprogrammed or hardwired, identical by Appendix D)
  if (MICRO) begin : g_mc
    ctl_microcoded cu (.clk, .rst, .op(instr[6:0]), .upc(state), .ctrl(c));
  end else begin : g_hw
    ctl_hardwired  cu (.clk, .rst, .op(instr[6:0]), .state(state), .ctrl(c));
  end
  assign {adrsrc, irwrite, alusrca, alusrcb, aluop, resultsrc, pcupdate, regwrite, dwe, branch} = c;
  assign pcwrite = pcupdate | (branch & zero);
  aludec ad (.aluop, .funct3(instr[14:12]), .funct7b5(instr[30]), .opb5(instr[5]), .alucontrol);
  immdec id (.op(instr[6:0]), .immsrc);

  // ---- architectural and non-architectural registers
  always_ff @(posedge clk) begin
    if (rst) begin pc <= 32'd0; instr <= 32'h0000_0013; end  // reset instr = nop (addi x0,x0,0)
    else begin
      if (pcwrite) pc <= result;
      if (irwrite) begin oldpc <= pc; instr <= instr_rd; end
    end
    a      <= rd1;          // register-file outputs, captured every cycle
    wdata  <= rd2;
    aluout <= aluresult;
    data   <= data_rd;
  end

  // ---- datapath
  assign iadr = pc;                        // fetch address (AdrSrc = 0)
  assign dadr = result;                    // data address   (AdrSrc = 1): Result = ALUOut
  assign dwd  = wdata;
  regfile #(.FALLING(1'b0)) rf (.clk, .we(regwrite), .a1(instr[19:15]), .a2(instr[24:20]), .a3(instr[11:7]),
               .wd(result), .rd1(rd1), .rd2(rd2));
  extend  ext (.instr(instr[31:7]), .immsrc, .immext);
  mux3 #(32) msa (.d0(pc),    .d1(oldpc),  .d2(a),       .s(alusrca), .y(srca));
  mux3 #(32) msb (.d0(wdata), .d1(immext), .d2(32'd4),   .s(alusrcb), .y(srcb));
  alu  #(32) alu0 (.a(srca), .b(srcb), .ctrl(alucontrol), .y(aluresult), .zero);
  mux3 #(32) mres (.d0(aluout), .d1(data), .d2(aluresult), .s(resultsrc), .y(result));
endmodule

module top_multi #(parameter bit MICRO = 1'b1) (input logic clk, rst);
  logic [31:0] iadr, instr, dadr, dwd, drd;
  logic        dwe;
  logic [3:0]  state;
  rv_multi #(MICRO) cpu (.clk, .rst, .iadr, .instr_rd(instr), .dadr, .dwd, .dwe,
                         .data_rd(drd), .state);
  imem im (.a(iadr), .rd(instr));
  dmem dm (.clk, .we(dwe), .a(dadr), .wd(dwd), .rd(drd));
endmodule
