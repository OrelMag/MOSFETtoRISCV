// arith.sv — multiplication and division (Appendix)

// 4×4 unsigned array multiplier: 16 AND partial products, three 4-bit ripple rows.
module mul_array4 (input logic [3:0] a, b, output logic [7:0] p);
  logic [3:0] pp0, pp1, pp2, pp3, s1, s2, s3;
  logic       c1, c2, c3;
  assign pp0 = a & {4{b[0]}};
  assign pp1 = a & {4{b[1]}};
  assign pp2 = a & {4{b[2]}};
  assign pp3 = a & {4{b[3]}};
  rca4 row1 (.a({1'b0, pp0[3:1]}), .b(pp1), .cin(1'b0), .s(s1), .cout(c1));
  rca4 row2 (.a({c1,   s1[3:1]}),  .b(pp2), .cin(1'b0), .s(s2), .cout(c2));
  rca4 row3 (.a({c2,   s2[3:1]}),  .b(pp3), .cin(1'b0), .s(s3), .cout(c3));
  assign p = {c3, s3, s2[0], s1[0], pp0[0]};
endmodule

// One iteration of shift-and-add: conditionally add, then shift {hi,lo} right.
module mul_step #(parameter int W = 4) (
  input  logic [W:0]   hi,
  input  logic [W-1:0] lo, m,
  output logic [W:0]   hi_n,
  output logic [W-1:0] lo_n);
  logic [W-1:0] addend;
  logic [W:0]   sum;
  assign addend = lo[0] ? m : '0;                 // multiplier LSB selects the addend
  assign sum    = {1'b0, hi[W-1:0]} + {1'b0, addend};
  assign hi_n   = {1'b0, sum[W:1]};
  assign lo_n   = {sum[0], lo[W-1:1]};
endmodule

// Sequential shift-and-add multiplier (unsigned). W iterations, one adder.
module mul_seq #(parameter int W = 8) (
  input  logic           clk, rst, start,
  input  logic [W-1:0]   a, b,
  output logic [2*W-1:0] p,
  output logic           done);
  logic [W:0]   hi;              // accumulator with carry bit
  logic [W-1:0] lo, m;           // lo starts as multiplier, fills with product
  logic [W:0]   hi_n;
  logic [W-1:0] lo_n;
  logic [$clog2(W+1)-1:0] cnt;
  mul_step #(W) step (.hi, .lo, .m, .hi_n, .lo_n);
  always_ff @(posedge clk)
    if (rst) begin cnt <= '0; done <= 1'b0; end
    else if (start) begin hi <= '0; lo <= b; m <= a; cnt <= W; done <= 1'b0; end
    else if (cnt != 0) begin
      hi <= hi_n; lo <= lo_n;                    // add-then-shift in one step
      cnt  <= cnt - 1'b1;
      done <= (cnt == 1);
    end
  assign p = {hi[W-1:0], lo};
endmodule

// Sequential Booth (radix-2) multiplier, signed.
module mul_booth #(parameter int W = 8) (
  input  logic                  clk, rst, start,
  input  logic signed [W-1:0]   a, b,
  output logic signed [2*W-1:0] p,
  output logic                  done);
  logic signed [W:0] acc, m, nxt;   // one guard bit avoids overflow at M = -2^(W-1)
  logic [W-1:0]      q;
  logic              q_1;
  logic [$clog2(W+1)-1:0] cnt;
  always_comb
    case ({q[0], q_1})
      2'b01:   nxt = acc + m;       // end of a run of 1s
      2'b10:   nxt = acc - m;       // start of a run of 1s
      default: nxt = acc;           // inside a run: no operation
    endcase
  always_ff @(posedge clk)
    if (rst) begin cnt <= '0; done <= 1'b0; end
    else if (start) begin acc <= '0; m <= {a[W-1], a}; q <= b; q_1 <= 1'b0;
                          cnt <= W; done <= 1'b0; end
    else if (cnt != 0) begin
      {acc, q, q_1} <= $signed({nxt, q, q_1}) >>> 1;  // arithmetic shift right
      cnt  <= cnt - 1'b1;
      done <= (cnt == 1);
    end
  assign p = {acc[W-1:0], q};
endmodule

// One restoring-division iteration: shift in a dividend bit, trial-subtract,
// keep the difference only if it is non-negative.
module div_step #(parameter int W = 4) (
  input  logic [W:0]   rem,
  input  logic [W-1:0] q, dv,
  output logic [W:0]   rem_n,
  output logic [W-1:0] q_n);
  logic [W:0]   sh;
  logic [W+1:0] trial;
  logic         neg;
  assign sh    = {rem[W-1:0], q[W-1]};
  assign trial = {1'b0, sh} - {2'b00, dv};
  assign neg   = trial[W+1];
  assign rem_n = neg ? sh : trial[W:0];           // restore on negative
  assign q_n   = {q[W-2:0], ~neg};
endmodule

// Restoring division (unsigned). Divide-by-zero yields q = all ones, r = a,
// which is exactly the RISC-V M-extension convention for DIVU/REMU.
module div_restoring #(parameter int W = 8) (
  input  logic         clk, rst, start,
  input  logic [W-1:0] a, d,
  output logic [W-1:0] q, r,
  output logic         done);
  logic [W:0]   rem, rem_n;
  logic [W-1:0] dv, q_n;
  logic [$clog2(W+1)-1:0] cnt;
  div_step #(W) step (.rem, .q, .dv, .rem_n, .q_n);
  always_ff @(posedge clk)
    if (rst) begin cnt <= '0; done <= 1'b0; end
    else if (start) begin rem <= '0; q <= a; dv <= d; cnt <= W; done <= 1'b0; end
    else if (cnt != 0) begin
      rem <= rem_n;
      q   <= q_n;
      cnt  <= cnt - 1'b1;
      done <= (cnt == 1);
    end
  assign r = rem[W-1:0];
endmodule

// Non-restoring division (unsigned): add or subtract every step, never restore;
// one final correction of the remainder.
module div_nonrestoring #(parameter int W = 8) (
  input  logic         clk, rst, start,
  input  logic [W-1:0] a, d,
  output logic [W-1:0] q, r,
  output logic         done);
  logic signed [W+1:0] rem, sh, nxt, dv;
  logic [W-1:0]        qq;
  logic [$clog2(W+1)-1:0] cnt;
  logic                fix;
  assign sh  = {rem[W:0], qq[W-1]};
  assign nxt = rem[W+1] ? sh + dv : sh - dv;       // sign of previous remainder decides
  always_ff @(posedge clk)
    if (rst) begin cnt <= '0; done <= 1'b0; fix <= 1'b0; end
    else if (start) begin rem <= '0; qq <= a; dv <= {2'b00, d}; cnt <= W;
                          done <= 1'b0; fix <= 1'b0; end
    else if (cnt != 0) begin
      rem <= nxt;
      qq  <= {qq[W-2:0], ~nxt[W+1]};
      cnt <= cnt - 1'b1;
      fix <= (cnt == 1);
    end
    else if (fix) begin
      if (rem[W+1]) rem <= rem + dv;               // final remainder correction
      fix <= 1'b0; done <= 1'b1;
    end
  assign q = qq;
  assign r = rem[W-1:0];
endmodule
