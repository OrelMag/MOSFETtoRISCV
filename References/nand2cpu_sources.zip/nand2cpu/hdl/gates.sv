// gates.sv — everything below is built from a single primitive: the 2-input NAND.
module nand2 (input logic a, b, output logic y);
`ifdef SIM
  assign #1 y = ~(a & b);          // unit gate delay for simulation only
`else
  assign    y = ~(a & b);
`endif
endmodule

module not_n (input logic a, output logic y);
  nand2 g1 (.a(a), .b(a), .y(y));
endmodule

module and_n (input logic a, b, output logic y);
  logic n;
  nand2 g1 (.a(a), .b(b), .y(n));
  nand2 g2 (.a(n), .b(n), .y(y));
endmodule

module or_n (input logic a, b, output logic y);
  logic na, nb;
  nand2 g1 (.a(a),  .b(a),  .y(na));
  nand2 g2 (.a(b),  .b(b),  .y(nb));
  nand2 g3 (.a(na), .b(nb), .y(y));
endmodule

module xor_n (input logic a, b, output logic y);
  logic m, p, q;
  nand2 g1 (.a(a), .b(b), .y(m));
  nand2 g2 (.a(a), .b(m), .y(p));
  nand2 g3 (.a(b), .b(m), .y(q));
  nand2 g4 (.a(p), .b(q), .y(y));
endmodule

// y = s ? b : a
module mux2_n (input logic a, b, s, output logic y);
  logic ns, p, q;
  nand2 g1 (.a(s), .b(s),  .y(ns));
  nand2 g2 (.a(a), .b(ns), .y(p));
  nand2 g3 (.a(b), .b(s),  .y(q));
  nand2 g4 (.a(p), .b(q),  .y(y));
endmodule

module half_adder (input logic a, b, output logic s, c);
  logic m, p, q;
  nand2 g1 (.a(a), .b(b), .y(m));
  nand2 g2 (.a(a), .b(m), .y(p));
  nand2 g3 (.a(b), .b(m), .y(q));
  nand2 g4 (.a(p), .b(q), .y(s));
  nand2 g5 (.a(m), .b(m), .y(c));
endmodule

// Nine-NAND full adder: the carry reuses the first NAND of each XOR cell.
module full_adder (input logic a, b, cin, output logic s, cout);
  logic m1, p1, q1, x1, m2, p2, q2;
  nand2 g1 (.a(a),   .b(b),   .y(m1));   // m1 = ~(a·b)
  nand2 g2 (.a(a),   .b(m1),  .y(p1));
  nand2 g3 (.a(b),   .b(m1),  .y(q1));
  nand2 g4 (.a(p1),  .b(q1),  .y(x1));   // x1 = a ^ b
  nand2 g5 (.a(x1),  .b(cin), .y(m2));   // m2 = ~(x1·cin)
  nand2 g6 (.a(x1),  .b(m2),  .y(p2));
  nand2 g7 (.a(cin), .b(m2),  .y(q2));
  nand2 g8 (.a(p2),  .b(q2),  .y(s));    // s  = x1 ^ cin
  nand2 g9 (.a(m1),  .b(m2),  .y(cout)); // cout = a·b + x1·cin
endmodule

module rca4 (input logic [3:0] a, b, input logic cin,
             output logic [3:0] s, output logic cout);
  logic [4:0] c;
  assign c[0] = cin;
  full_adder fa0 (.a(a[0]), .b(b[0]), .cin(c[0]), .s(s[0]), .cout(c[1]));
  full_adder fa1 (.a(a[1]), .b(b[1]), .cin(c[1]), .s(s[1]), .cout(c[2]));
  full_adder fa2 (.a(a[2]), .b(b[2]), .cin(c[2]), .s(s[2]), .cout(c[3]));
  full_adder fa3 (.a(a[3]), .b(b[3]), .cin(c[3]), .s(s[3]), .cout(c[4]));
  assign cout = c[4];
endmodule

// 4-bit carry-lookahead adder (two-level generate/propagate logic)
module cla4 (input logic [3:0] a, b, input logic cin,
             output logic [3:0] s, output logic cout);
  logic [3:0] g, p;
  logic [4:1] c;
  assign g = a & b;
  assign p = a ^ b;
  assign c[1] = g[0] | (p[0] & cin);
  assign c[2] = g[1] | (p[1] & g[0]) | (p[1] & p[0] & cin);
  assign c[3] = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]) | (p[2] & p[1] & p[0] & cin);
  assign c[4] = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0])
                     | (p[3] & p[2] & p[1] & p[0] & cin);
  assign s    = p ^ {c[3:1], cin};
  assign cout = c[4];
endmodule

// Parameterized ripple-carry adder (used for gate-depth analysis)
module rca #(parameter int N = 8) (input logic [N-1:0] a, b, input logic cin,
                                   output logic [N-1:0] s, output logic cout);
  logic [N:0] c;
  assign c[0] = cin;
  for (genvar i = 0; i < N; i++) begin : bit_
    full_adder fa (.a(a[i]), .b(b[i]), .cin(c[i]), .s(s[i]), .cout(c[i+1]));
  end
  assign cout = c[N];
endmodule
