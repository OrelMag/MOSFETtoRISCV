// mem16.sv — a 16-word × 8-bit register memory with a 4-bit address
// write path: address decoder -> one-hot write enables -> 16 registers
// read path : 16:1 multiplexer tree selected by the read address

// 2-to-4 decoder with enable: exactly one output high when en = 1
module dec2to4 (input logic [1:0] a, input logic en, output logic [3:0] y);
  logic n1, n0;
  assign n1 = ~a[1];
  assign n0 = ~a[0];
  assign y[0] = en & n1   & n0;
  assign y[1] = en & n1   & a[0];
  assign y[2] = en & a[1] & n0;
  assign y[3] = en & a[1] & a[0];
endmodule

// 4-to-16 decoder built from two predecoders: row = a[3:2], column = a[1:0].
// y[4r+c] = row[r] & col[c] — the same "coincident selection" as a 4×4 grid.
module dec4to16 (input logic [3:0] a, input logic en, output logic [15:0] y);
  logic [3:0] row, col;
  dec2to4 prow (.a(a[3:2]), .en(en),   .y(row));
  dec2to4 pcol (.a(a[1:0]), .en(1'b1), .y(col));
  for (genvar r = 0; r < 4; r++) begin : g_r
    for (genvar c = 0; c < 4; c++) begin : g_c
      assign y[4*r+c] = row[r] & col[c];
    end
  end
endmodule

// One 8-bit storage word: loads d on the rising edge when we = 1
module reg8 (input logic clk, we, input logic [7:0] d, output logic [7:0] q);
  always_ff @(posedge clk)
    if (we) q <= d;
endmodule

// 16:1 read multiplexer as a balanced tree of 15 two-way multiplexers
module mux16x8 (
  input  logic [7:0] d0, d1, d2, d3, d4, d5, d6, d7,
                     d8, d9, d10, d11, d12, d13, d14, d15,
  input  logic [3:0] s,
  output logic [7:0] y);
  logic [7:0] l1_0, l1_1, l1_2, l1_3, l1_4, l1_5, l1_6, l1_7, l2_0, l2_1, l2_2, l2_3, l3_0, l3_1;
  // level 1 — select bit s[0]
  mux2 #(8) m00 (.d0(d0),  .d1(d1),  .s(s[0]), .y(l1_0));
  mux2 #(8) m01 (.d0(d2),  .d1(d3),  .s(s[0]), .y(l1_1));
  mux2 #(8) m02 (.d0(d4),  .d1(d5),  .s(s[0]), .y(l1_2));
  mux2 #(8) m03 (.d0(d6),  .d1(d7),  .s(s[0]), .y(l1_3));
  mux2 #(8) m04 (.d0(d8),  .d1(d9),  .s(s[0]), .y(l1_4));
  mux2 #(8) m05 (.d0(d10), .d1(d11), .s(s[0]), .y(l1_5));
  mux2 #(8) m06 (.d0(d12), .d1(d13), .s(s[0]), .y(l1_6));
  mux2 #(8) m07 (.d0(d14), .d1(d15), .s(s[0]), .y(l1_7));
  // level 2 — s[1]
  mux2 #(8) m10 (.d0(l1_0), .d1(l1_1), .s(s[1]), .y(l2_0));
  mux2 #(8) m11 (.d0(l1_2), .d1(l1_3), .s(s[1]), .y(l2_1));
  mux2 #(8) m12 (.d0(l1_4), .d1(l1_5), .s(s[1]), .y(l2_2));
  mux2 #(8) m13 (.d0(l1_6), .d1(l1_7), .s(s[1]), .y(l2_3));
  // level 3 — s[2]
  mux2 #(8) m20 (.d0(l2_0), .d1(l2_1), .s(s[2]), .y(l3_0));
  mux2 #(8) m21 (.d0(l2_2), .d1(l2_3), .s(s[2]), .y(l3_1));
  // level 4 — s[3]
  mux2 #(8) m30 (.d0(l3_0), .d1(l3_1), .s(s[3]), .y(y));
endmodule

// The memory: synchronous write, asynchronous (combinational) read
module mem16x8 (
  input  logic       clk, we,
  input  logic [3:0] wa, ra,
  input  logic [7:0] wd,
  output logic [7:0] rd);
  logic [15:0] wen;
  logic [7:0]  q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15;
  dec4to16 dec (.a(wa), .en(we), .y(wen));
  reg8 r00 (.clk, .we(wen[0]),  .d(wd), .q(q0));
  reg8 r01 (.clk, .we(wen[1]),  .d(wd), .q(q1));
  reg8 r02 (.clk, .we(wen[2]),  .d(wd), .q(q2));
  reg8 r03 (.clk, .we(wen[3]),  .d(wd), .q(q3));
  reg8 r04 (.clk, .we(wen[4]),  .d(wd), .q(q4));
  reg8 r05 (.clk, .we(wen[5]),  .d(wd), .q(q5));
  reg8 r06 (.clk, .we(wen[6]),  .d(wd), .q(q6));
  reg8 r07 (.clk, .we(wen[7]),  .d(wd), .q(q7));
  reg8 r08 (.clk, .we(wen[8]),  .d(wd), .q(q8));
  reg8 r09 (.clk, .we(wen[9]),  .d(wd), .q(q9));
  reg8 r10 (.clk, .we(wen[10]), .d(wd), .q(q10));
  reg8 r11 (.clk, .we(wen[11]), .d(wd), .q(q11));
  reg8 r12 (.clk, .we(wen[12]), .d(wd), .q(q12));
  reg8 r13 (.clk, .we(wen[13]), .d(wd), .q(q13));
  reg8 r14 (.clk, .we(wen[14]), .d(wd), .q(q14));
  reg8 r15 (.clk, .we(wen[15]), .d(wd), .q(q15));
  mux16x8 rmux (.d0(q0), .d1(q1), .d2(q2), .d3(q3), .d4(q4), .d5(q5), .d6(q6), .d7(q7),
                .d8(q8), .d9(q9), .d10(q10), .d11(q11), .d12(q12), .d13(q13), .d14(q14),
                .d15(q15), .s(ra), .y(rd));
endmodule
