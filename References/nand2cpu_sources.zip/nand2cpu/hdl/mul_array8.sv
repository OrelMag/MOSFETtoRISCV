// mul_array8.sv — 8x8 array multiplier: n-1 = 7 ripple rows (generalizes mul_array4)
module mul_array8 (input logic [7:0] a, b, output logic [15:0] p);
  logic [7:0] pp [8];
  logic [7:0] s [8];
  logic [8:0] acc [8];
  for (genvar i = 0; i < 8; i++) begin : g_pp
    assign pp[i] = a & {8{b[i]}};
  end
  assign acc[0] = {2'b00, pp[0][7:1]};
  assign p[0] = pp[0][0];
  for (genvar i = 1; i < 8; i++) begin : g_row
    rca #(8) row (.a(acc[i-1][7:0]), .b(pp[i]), .cin(1'b0), .s(s[i]), .cout(acc[i][8]));
    assign acc[i][7:0] = {acc[i][8], s[i][7:1]};
    assign p[i] = s[i][0];
  end
  assign p[15:8] = acc[7][7:0];
endmodule
