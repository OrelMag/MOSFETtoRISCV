# NAND-level static timing of whole processors.
# Each design is synthesized with Yosys (synth -flatten; dffunmap; abc -g NAND).
# Model: NAND and NOT = 1 level; flip-flops launch at t_pcq and must capture t_setup before the edge.
import json, subprocess, sys, collections
T_PCQ, T_SETUP = 3, 1            # measured on dff_ms (sim/tb_dffchar.sv)
def synth(files, top, extra='', params=None):
    ys=[f'read_verilog -sv ../hdl/{f}' for f in files]
    ys+=[f'chparam -set {k} {v} {top}' for k,v in (params or {}).items()]
    ys+=[f'hierarchy -top {top}', 'synth -flatten -top '+top, 'dffunmap', 'abc -g NAND', 'opt_clean', extra, f'write_json sta_{top}.json']
    open(f'sta_{top}.ys','w').write('\n'.join(ys)+'\n')
    subprocess.run(['yowasp-yosys','-q',f'sta_{top}.ys'],check=True)
    d=json.load(open(f'sta_{top}.json'))
    return [v for v in d['modules'].values() if v['attributes'].get('top')][0]
def graph(m):
    drv={}; ffD=[]; ffQ=set(); kinds=collections.Counter(); nffs=0
    for c in m['cells'].values():
        t=c['type']; cn=c['connections']
        if t=='$scopeinfo': continue
        if t in ('$_NAND_',):
            drv[cn['Y'][0]]=(1,[cn['A'][0],cn['B'][0]]); kinds['NAND']+=1
        elif t=='$_NOT_':
            drv[cn['Y'][0]]=(1,[cn['A'][0]]); kinds['NOT']+=1
        elif t in ('$_DFF_P_','$_DFF_N_'):
            ffD.append((cn['D'][0], t)); ffQ.add(cn['Q'][0]); nffs+=1
        else: raise SystemExit('unexpected cell '+t)
    kinds['DFF']=nffs
    return drv, ffD, ffQ, kinds
def arrival(drv, ffQ, inarr):
    memo={}
    sys.setrecursionlimit(100000)
    def arr(b):
        if isinstance(b,str): return 0                       # constant
        if b in memo: return memo[b]
        if b in drv:
            w,ins=drv[b]; memo[b]=w+max(arr(x) for x in ins)
        elif b in ffQ: memo[b]=T_PCQ
        else: memo[b]=inarr.get(b,0)                         # primary input
        return memo[b]
    return arr
if __name__=='__main__':
    # memory read delay: 64-word x 32-bit asynchronous RAM, address -> data
    m=synth(['rv_blocks.sv'],'dmem')
    drv,ffD,ffQ,k=graph(m)
    arr=arrival(drv,ffQ,{})
    # the address arrives at t=0; memory contents come from its own flip-flops (T_PCQ)
    abits=set(m['ports']['a']['bits'])
    memo2={}
    def arr_addr(b):   # depth from address inputs only
        if isinstance(b,str): return -10**9
        if b in memo2: return memo2[b]
        if b in drv: w,ins=drv[b]; memo2[b]=w+max(arr_addr(x) for x in ins)
        elif b in abits: memo2[b]=0
        else: memo2[b]=-10**9
        return memo2[b]
    dmem=max(arr_addr(b) for b in m['ports']['rd']['bits'])
    print('dmem 64x32 read: address->data depth', dmem, 'levels; cells', dict(k))
    json.dump({'t_pcq':T_PCQ,'t_setup':T_SETUP,'t_mem':dmem},open('sta_mem.json','w'))

NEG=-10**9
def memwrite_depth():
    m=synth(['rv_blocks.sv'],'dmem')
    drv,ffD,ffQ,_=graph(m)
    ins={b for p in ('a','wd','we') for b in m['ports'][p]['bits']}
    memo={}
    def a(b):
        if isinstance(b,str): return NEG
        if b in memo: return memo[b]
        if b in drv: w,x=drv[b]; memo[b]=w+max(a(y) for y in x)
        elif b in ins: memo[b]=0
        else: memo[b]=NEG
        return memo[b]
    return max(a(d) for d,_ in ffD)

def cpu_sta(files, top, mem_reads, mem_writes, params=None, tmem=17, tmemw=0):
    """mem_reads: {data_input_port: address_output_port}; mem_writes: output ports feeding dmem."""
    m=synth(files, top, params=params)
    drv,ffD,ffQ,kinds=graph(m)
    ffQtype={}
    for c in m['cells'].values():
        if c['type'] in ('$_DFF_P_','$_DFF_N_'): ffQtype[c['connections']['Q'][0]]=c['type'][-2]
    P=m['ports']
    res={}
    for cls in ('P','N'):
        memo={}
        rd_src={b:(port,i) for port in mem_reads for i,b in enumerate(P[port]['bits'])}
        def arr(b):
            if isinstance(b,str): return NEG
            if b in memo: return memo[b]
            memo[b]=NEG
            if b in drv:
                w,ins=drv[b]; v=max(arr(x) for x in ins); memo[b]= v+w if v>NEG//2 else NEG
            elif b in ffQtype:
                memo[b]= T_PCQ if ffQtype[b]==cls else NEG
            elif b in rd_src:
                addr=P[mem_reads[rd_src[b][0]]]['bits']
                v=max(arr(x) for x in addr); memo[b]= v+tmem if v>NEG//2 else NEG
            else:
                memo[b]= 0 if cls=='P' else NEG      # other primary inputs (reset): rising-edge domain
            return memo[b]
        endP=max([arr(d) for d,t in ffD if t=='$_DFF_P_']+[arr(b)+tmemw for p in mem_writes for b in P[p]['bits']])
        endN=max([arr(d) for d,t in ffD if t=='$_DFF_N_'] or [NEG])
        res[cls]=(endP,endN)
    # required period, launch->capture: P->P and N->N get a full cycle, P->N and N->P half a cycle
    cands={}
    (pP,pN),(nP,nN)=res['P'],res['N']
    if pP>NEG//2: cands['rise→rise (full cycle)']=pP+T_SETUP
    if nN>NEG//2: cands['fall→fall (full cycle)']=nN+T_SETUP
    if pN>NEG//2: cands['rise→fall (half cycle) ×2']=2*(pN+T_SETUP)
    if nP>NEG//2: cands['fall→rise (half cycle) ×2']=2*(nP+T_SETUP)
    T=max(cands.values())
    return dict(T=T, cands=cands, cells=dict(kinds))

if __name__=='__main__' and len(sys.argv)>1 and sys.argv[1]=='cpus':
    tm=json.load(open('sta_mem.json'))
    tmemw=memwrite_depth(); tm['t_memw']=tmemw
    print('memory write depth (inputs -> storage flop D):', tmemw)
    B=['rv_blocks.sv']
    designs={
     'single-cycle': (B+['rv_single.sv'],'rv_single',{'instr':'pc','readdata':'aluresult'},['aluresult','writedata','memwrite'],None),
     'multicycle':   (B+['microcode.sv','rv_multi.sv'],'rv_multi',{'instr_rd':'iadr','data_rd':'dadr'},['dadr','dwd','dwe'],None),
     'pipeline':     (B+['rv_pipe.sv'],'rv_pipe',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM'],None),
     'pipeline + prediction': (B+['rv_pipe.sv','rv_pipe_bp.sv'],'rv_pipe_bp',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM'],None),
    }
    out={'mem':tm}
    for name,(f,top,rd,wr,prm) in designs.items():
        r=cpu_sta(f,top,rd,wr,prm,tm['t_mem'],tmemw)
        out[name]=r; print(name, r, flush=True)
    json.dump(out,open('sta_cpus.json','w'),ensure_ascii=False,indent=1)
