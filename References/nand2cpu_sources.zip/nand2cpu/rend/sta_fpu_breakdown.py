# Cumulative NAND-level arrival at the named stage boundaries inside fp_add32 and fp_mul32
# (uses the netlists written by sta_fpu.py).
import json, sta_struct as S
STAGES={'fp_add32':[('compare magnitudes','a_big'),('exponent difference','d'),('align + sticky','sm'),('add / subtract','S'),
                    ('leading-zero count','lz'),('normalize','Sn'),('round','rnd'),('pack + specials','y')],
        'fp_mul32':[('significand product','P'),('normalize','Pn'),('result exponent','Er'),('underflow shift','Ps'),('sticky bit','stk'),
                    ('round','rnd'),('pack + specials','y')]}
out={}
for top,st in STAGES.items():
    m=json.load(open(f'ss_{top}.json')); m=[v for v in m['modules'].values() if v['attributes'].get('top')][0]
    r,_=S.analyze(m); arr=r['P'][3]; nn=m['netnames']
    out[top]=[(lab, max(arr(b) for b in nn[net]['bits'] if isinstance(b,int))) for lab,net in st]
    print(top,out[top])
json.dump(out,open('sta_fpu_breakdown.json','w'),indent=1)
