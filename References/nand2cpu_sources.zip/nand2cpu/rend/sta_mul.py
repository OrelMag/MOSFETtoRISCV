import json, subprocess, sys
def sta(files, top):
    open('stam.ys','w').write('\n'.join([f'read_verilog -sv ../hdl/{f}' for f in files]+
        [f'hierarchy -top {top}','blackbox nand2','proc','flatten','opt_clean','splitcells','splitnets -driver','write_json stam.json'])+'\n')
    subprocess.run(['yowasp-yosys','-q','stam.ys'],check=True)
    d=json.load(open('stam.json')); m=[v for v in d['modules'].values() if v['attributes'].get('top')][0]
    drv={}; nn=0; na=0
    for c in m['cells'].values():
        t=c['type']; cn=c['connections']
        if t=='$scopeinfo': continue
        if t=='nand2': drv[cn['y'][0]]=(1,[cn['a'][0],cn['b'][0]]); nn+=1
        elif t=='$and':
            for k,y in enumerate(cn['Y']):
                ins=[cn['A'][k] if k<len(cn['A']) else cn['A'][-1], cn['B'][k] if k<len(cn['B']) else cn['B'][-1]]
                drv[y]=(2,ins); na+=1
        else: raise SystemExit(f'unexpected cell {t}')
    memo={}
    def dep(b):
        if isinstance(b,str) or b not in drv: return 0
        if b in memo: return memo[b]
        w,ins=drv[b]; memo[b]=w+max(dep(x) for x in ins); return memo[b]
    out=max(dep(b) for b in m['ports']['p']['bits'])
    return out, nn, na
for f,t in [(['gates.sv','mul_array8.sv'],'mul_array8'),(['gates.sv','dadda8_rca.sv'],'dadda8_rca')]:
    print(t, 'max NAND-level depth, NAND count, AND2 count:', sta(f,t))
