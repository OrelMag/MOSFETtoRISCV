# Size and depth of the FPU blocks under the structural timing model (Section 8.11).
import json, sys, os, sta_struct as S
COST={'$_AND_':2,'$_OR_':3,'$_XOR_':4,'$_NOT_':1,'$_MUX_':4}
top=sys.argv[1]
m=S.synth(['fpu.sv'],top,'bk',tag='')
r,k=S.analyze(m)
res=json.load(open('sta_fpu.json')) if os.path.exists('sta_fpu.json') else {}
res[top]=dict(depth=r['P'][2], gates=sum(v for kk,v in k.items() if kk!='DFF'), nand_eq=sum(COST[kk]*v for kk,v in k.items() if kk!='DFF'))
ss=json.load(open('sta_struct.json'))
res['alu32']=dict(depth=ss['alu32_bk']['depth'], gates=ss['alu32_bk']['gates'])
json.dump(res,open('sta_fpu.json','w'),indent=1); print(top,res[top])
