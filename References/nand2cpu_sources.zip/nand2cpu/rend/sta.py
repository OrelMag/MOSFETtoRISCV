import json, subprocess, collections
res={}
for N in (4,8,16,32,64):
    open('sta.ys','w').write(f"""read_verilog -sv ../hdl/gates.sv
chparam -set N {N} rca
hierarchy -top rca
blackbox nand2
proc; flatten; opt_clean
stat
write_json sta.json
""")
    subprocess.run(['yowasp-yosys','-q','sta.ys'],check=True)
    d=json.load(open('sta.json'))
    m=[v for v in d['modules'].values() if v['attributes'].get('top')][0]
    drv={}; fanin=collections.defaultdict(list); n=0
    for c in m['cells'].values():
        if c['type']=='$scopeinfo': continue
        assert c['type']=='nand2'; n+=1
        y=c['connections']['y'][0]; drv[y]=[c['connections']['a'][0],c['connections']['b'][0]]
    memo={}
    def depth(bit):
        if bit not in drv: return 0
        if bit in memo: return memo[bit]
        memo[bit]=1+max(depth(x) for x in drv[bit]); return memo[bit]
    p=m['ports']
    cout=depth(p['cout']['bits'][0]); smax=max(depth(b) for b in p['s']['bits'])
    res[N]=(n,cout,smax); print(N,'nands',n,'depth cout',cout,'depth max sum',smax)
json.dump(res,open('sta_res.json','w'))
