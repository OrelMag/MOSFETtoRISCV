# Gate-level cost of the operator symbols: Yosys' own lowering (techmap, no ABC; gates costed
# at their NAND depth) versus the NAND-structural constructions of hdl/opgates.sv.
import json, subprocess, sys
import sta_struct as S
from sta_ks import sta_nand
res={}
for N in (4,8,16,32):
    for op in ('add','sub','eq','lt'):
        m=S.synth(['opgates.sv'],f'op_{op}',params={'N':N},tag=f'_{N}')
        r,k=S.analyze(m)
        res[f'yosys|{op}|{N}']=dict(depth=r['P'][2], gates=sum(v for kk,v in k.items() if kk!='DFF'),
                                   mix={kk:v for kk,v in k.items() if kk!='DFF'})
    for op,top,outs,files in (('add','rca',['s','cout'],['gates.sv']),('sub','sub_n',['y','nborrow'],['gates.sv','opgates.sv']),
                              ('eq','eq_n',['y'],['gates.sv','opgates.sv']),('lt','ltu_n',['y'],['gates.sv','opgates.sv']),
                              ('lts','lts_n',['y'],['gates.sv','opgates.sv'])):
        n,d=sta_nand(files,top,{'N':N},outs)
        res[f'nand|{op}|{N}']=dict(depth=d, gates=n)
    print(N,{k.split('|',1)[1]:(v['gates'],v['depth']) for k,v in res.items() if k.endswith(f'|{N}')},flush=True)
json.dump(res,open('sta_ops.json','w'),indent=1)
