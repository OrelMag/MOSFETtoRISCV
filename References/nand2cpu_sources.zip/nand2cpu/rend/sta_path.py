# Trace the worst rise->rise path of a synthesized CPU and list the named nets it crosses.
import json, sys
from sta_cpu import graph, T_PCQ, T_SETUP, NEG
def worst_path(top, mem_reads, mem_writes, tmem=17, tmemw=11):
    d=json.load(open(f'sta_{top}.json'))
    m=[v for v in d['modules'].values() if v['attributes'].get('top')][0]
    drv,ffD,ffQ,_=graph(m)
    qtype={c['connections']['Q'][0]:c['type'][-2] for c in m['cells'].values() if c['type'] in ('$_DFF_P_','$_DFF_N_')}
    P=m['ports']; names={}
    for nm,nn in m['netnames'].items():
        if nn.get('hide_name'): continue
        for i,b in enumerate(nn['bits']):
            if isinstance(b,int): names.setdefault(b,f'{nm}[{i}]' if len(nn['bits'])>1 else nm)
    rd_src={b:port for port in mem_reads for b in P[port]['bits']}
    memo={}; pred={}
    sys.setrecursionlimit(100000)
    def arr(b):
        if isinstance(b,str): return NEG
        if b in memo: return memo[b]
        memo[b]=NEG
        if b in drv:
            w,ins=drv[b]; best=max(ins,key=arr); v=arr(best)
            if v>NEG//2: memo[b]=v+w; pred[b]=best
        elif b in qtype: memo[b]=T_PCQ if qtype[b]=='P' else NEG
        elif b in rd_src:
            addr=P[mem_reads[rd_src[b]]]['bits']; best=max(addr,key=arr)
            if arr(best)>NEG//2: memo[b]=arr(best)+tmem; pred[b]=best
        else: memo[b]=0
        return memo[b]
    ends=[(arr(dd),dd,'flop D') for dd,t in ffD if t=='$_DFF_P_']+[(arr(b)+tmemw,b,'memory write') for p in mem_writes for b in P[p]['bits']]
    v,b,kind=max(ends,key=lambda e:e[0])
    path=[]
    while b is not None:
        path.append((arr(b), names.get(b,'')))
        b=pred.get(b)
    path.reverse()
    seen=[]; 
    for t,nm in path:
        if nm and (not seen or seen[-1][1].split('[')[0]!=nm.split('[')[0]): seen.append((t,nm))
    print(f'{top}: worst endpoint arrival {v} ({kind}) -> period {v+T_SETUP}')
    for t,nm in seen: print(f'   {t:4d}  {nm}')
if __name__=='__main__':
    worst_path('rv_pipe',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM'])
    worst_path('rv_single',{'instr':'pc','readdata':'aluresult'},['aluresult','writedata','memwrite'])
    worst_path('rv_multi',{'instr_rd':'iadr','data_rd':'dadr'},['dadr','dwd','dwe'])
