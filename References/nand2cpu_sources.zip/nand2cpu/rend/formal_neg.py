import subprocess, shutil, os, json, re
MUT = {
 'F1 with a Kogge–Stone combine cell wired to the wrong position':
   ('prefix.sv', ".g_lo(G[l][k-(1<<l)])", ".g_lo(G[l][k-(1<<l)+((k==N)?1:0)])", 'prop_adders',
    ['gates.sv','prefix.sv','kmap.sv','mul_array8.sv','dadda8_rca.sv','dadda8_ks.sv','rv_blocks.sv','rv_pipe.sv','mem16.sv','microcode.sv','opgates.sv','formal.sv']),
 'F3 with the SLT overflow correction removed':
   ('rv_blocks.sv', "assign lt  = sum[W-1] ^ v;", "assign lt  = sum[W-1];", 'prop_alu', ['gates.sv','prefix.sv','kmap.sv','mul_array8.sv','dadda8_rca.sv','dadda8_ks.sv','rv_blocks.sv','rv_pipe.sv','mem16.sv','microcode.sv','opgates.sv','formal.sv']),
 'F4 with forwarding priority reversed':
   ('rv_pipe.sv', "      if      (rs1E == rdM && regwriteM) fwdAE = 2'b10;\n      else if (rs1E == rdW && regwriteW) fwdAE = 2'b01;",
    "      if      (rs1E == rdW && regwriteW) fwdAE = 2'b01;\n      else if (rs1E == rdM && regwriteM) fwdAE = 2'b10;", 'prop_hazard',
    ['gates.sv','prefix.sv','kmap.sv','mul_array8.sv','dadda8_rca.sv','dadda8_ks.sv','rv_blocks.sv','rv_pipe.sv','mem16.sv','microcode.sv','opgates.sv','formal.sv']),
 'F6 with one flipped microcode bit (JAL PCUpdate)':
   ('microcode.hex', None, None, 'prop_ctl_comb', ['gates.sv','prefix.sv','kmap.sv','mul_array8.sv','dadda8_rca.sv','dadda8_ks.sv','rv_blocks.sv','rv_pipe.sv','mem16.sv','microcode.sv','opgates.sv','formal.sv']),
}
res={}
for name,(fn,old,new,top,files) in MUT.items():
    shutil.rmtree('fneg',ignore_errors=True); shutil.copytree('../hdl','fneg/hdl'); os.makedirs('fneg/w')
    for h in ('microcode.hex','dispatch1.hex','dispatch2.hex'): shutil.copy(h,'fneg/w/')
    if fn=='microcode.hex':
        l=open('fneg/w/microcode.hex').read().split(); l[9]='%05x'%(int(l[9],16)^(1<<9))
        open('fneg/w/microcode.hex','w').write('\n'.join(l)+'\n')
    else:
        p=f'fneg/hdl/{fn}'; s=open(p).read(); assert old in s, name; open(p,'w').write(s.replace(old,new))
    rd=' '.join('../hdl/'+f for f in files)
    open('fneg/w/j.ys','w').write(f'read_verilog -sv -formal {rd}\nhierarchy -top {top}\nproc\nflatten\nmemory_map\nopt -fast\nasync2sync\ndffunmap\nsat -prove-asserts -verify -show-inputs\n')
    r=subprocess.run('cd fneg/w && yowasp-yosys -q j.ys',shell=True,capture_output=True,text=True)
    out=(r.stdout+r.stderr); cex = r.returncode!=0 and 'proof did fail' in out.lower()
    if not cex: print(out[-400:])
    res[name]=cex
    print(f'{name:62s} {"COUNTEREXAMPLE FOUND" if cex else "NOT DETECTED"}')
json.dump(res,open('formal_neg.json','w'),ensure_ascii=False,indent=1)
