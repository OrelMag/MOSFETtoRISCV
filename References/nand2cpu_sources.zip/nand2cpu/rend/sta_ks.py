import json, subprocess
def sta_nand(files, top, params, outs):
    ys=[f'read_verilog -sv ../hdl/{f}' for f in files]+[f'chparam -set {k} {v} {top}' for k,v in params.items()]+\
       [f'hierarchy -top {top}','blackbox nand2','proc','flatten','opt_clean','write_json stk.json']
    open('stk.ys','w').write('\n'.join(ys)+'\n'); subprocess.run(['yowasp-yosys','-q','stk.ys'],check=True)
    d=json.load(open('stk.json')); m=[v for v in d['modules'].values() if v['attributes'].get('top')][0]
    drv={}; n=0
    for c in m['cells'].values():
        if c['type']=='$scopeinfo': continue
        assert c['type']=='nand2', c['type']; n+=1
        cn=c['connections']; drv[cn['y'][0]]=[cn['a'][0],cn['b'][0]]
    memo={}
    def dep(b):
        if isinstance(b,str) or b not in drv: return 0
        if b not in memo: memo[b]=1+max(dep(x) for x in drv[b])
        return memo[b]
    return n, max(dep(b) for o in outs for b in m['ports'][o]['bits'])
if __name__=='__main__':
  res={}
  for N in (4,8,16,32,64):
      rn,rd=sta_nand(['gates.sv'],'rca',{'N':N},['s','cout'])
      kn,kd=sta_nand(['gates.sv','prefix.sv'],'ks_adder',{'N':N},['s','cout'])
      res[N]=dict(rca_n=rn,rca_d=rd,ks_n=kn,ks_d=kd)
      print(N,res[N])
  json.dump(res,open('sta_ks.json','w'))
