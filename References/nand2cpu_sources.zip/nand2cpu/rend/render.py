import json, subprocess, sys, re, os
NS='netlistsvg'
SKIN='skin.svg'
H='../hdl'
JOBS = {
 # name: (files, top, blackboxes, chparams, extra yosys cmds)
 'nand_not':   (['gates.sv'], 'not_n',     ['nand2'], {}, ''),
 'nand_and':   (['gates.sv'], 'and_n',     ['nand2'], {}, ''),
 'nand_or':    (['gates.sv'], 'or_n',      ['nand2'], {}, ''),
 'nand_xor':   (['gates.sv'], 'xor_n',     ['nand2'], {}, ''),
 'nand_mux':   (['gates.sv'], 'mux2_n',    ['nand2'], {}, ''),
 'half_adder': (['gates.sv'], 'half_adder',['nand2'], {}, ''),
 'full_adder': (['gates.sv'], 'full_adder',['nand2'], {}, ''),
 'rca4':       (['gates.sv'], 'rca4',      ['full_adder','nand2'], {}, ''),
 'cla4':       (['gates.sv'], 'cla4',      ['nand2','full_adder'], {}, 'flatten; opt -full; splitnets'),
 'sr_latch':   (['gates.sv','seq.sv'], 'sr_latch_n', ['nand2'], {}, ''),
 'd_latch':    (['gates.sv','seq.sv'], 'd_latch',    ['nand2'], {}, ''),
 'dff_ms':     (['gates.sv','seq.sv'], 'dff_ms',     ['nand2','d_latch'], {}, ''),
 'register':   (['seq.sv'], 'register', [], {'W':4}, 'dffunmap; opt_clean'),
 'counter':    (['seq.sv'], 'counter',  [], {'W':4}, 'dffunmap; opt_clean'),
 'regfile4':   (['seq.sv'], 'regfile4', [], {}, 'opt -full; dffunmap; opt_clean'),
 'alu4':       (['rv_blocks.sv'], 'alu', [], {'W':4}, 'opt -full; opt_clean'),
 'hazard':     (['rv_pipe.sv','rv_blocks.sv'], 'hazard', [], {}, 'opt -full; opt_clean'),
 'rv_single':  (['rv_blocks.sv','rv_single.sv'], 'rv_single',
                ['adder','mux2','mux3','flopr','alu','extend','regfile','controller'], {}, ''),
 'rv_pipe':    (['rv_blocks.sv','rv_pipe.sv'], 'rv_pipe',
                ['stage_F','reg_FD','stage_D','regfile','reg_DE','stage_E','reg_EM','reg_MW','stage_W','hazard'], {}, ''),
 'stage_E':    (['rv_blocks.sv','rv_pipe.sv'], 'stage_E', ['adder','mux2','mux3','alu'], {}, ''),
 'stage_F':    (['rv_blocks.sv','rv_pipe.sv'], 'stage_F', ['adder','mux2','pipereg'], {}, ''),
 'controller': (['rv_blocks.sv'], 'controller', [], {}, 'opt -full; opt_clean'),
 'mul_array4': (['gates.sv','arith.sv'], 'mul_array4', ['rca4','full_adder','nand2'], {}, ''),
 'dec2to4':    (['mem16.sv'], 'dec2to4', [], {}, 'opt -full; opt_clean'),
 'dec4to16':   (['mem16.sv'], 'dec4to16', [], {}, 'flatten; opt -full; opt_clean'),
 'reg8':       (['mem16.sv'], 'reg8', [], {}, 'opt -full; dffunmap; opt_clean'),
 'mux16x8':    (['rv_blocks.sv','mem16.sv'], 'mux16x8', ['mux2'], {}, ''),
 'mem16x8':    (['rv_blocks.sv','mem16.sv'], 'mem16x8', ['dec4to16','reg8','mux16x8'], {}, ''),
 'ctl_microcoded': (['rv_blocks.sv','microcode.sv'], 'ctl_microcoded', ['urom','dispatch1','dispatch2','mux3'], {}, 'flatten; opt_clean'),
 'legend':     (['legend.sv'], 'legend', [], {}, 'opt_clean'),
 'seg_e_sop':  (['gates.sv','kmap.sv'], 'seg_e_sop_nand', ['nand2'], {}, ''),
 'seg_e_pos':  (['kmap.sv'], 'seg_e_pos', [], {}, 'opt -full; splitnets; opt_clean'),
 'seg_e_can':  (['kmap.sv'], 'seg_e_canonical', [], {}, 'opt_clean; splitnets; opt_clean'),
 'maj_sop':    (['kmap.sv'], 'maj_sop', [], {}, 'opt_clean'),
 'maj_pos':    (['kmap.sv'], 'maj_pos', [], {}, 'opt_clean'),
 'ks4':        (['gates.sv','prefix.sv'], 'ks_adder', ['and_n','xor_n','gcombine','nand2'], {'N':4}, ''),
 'gcombine':   (['gates.sv','prefix.sv'], 'gcombine', ['nand2'], {}, ''),
 'rv_multi':   (['rv_blocks.sv','microcode.sv','rv_multi.sv'], 'rv_multi', ['ctl_microcoded','regfile','extend','mux3','alu','aludec','immdec'], {}, 'opt_clean'),
 'dm_cache':   (['rv_blocks.sv','mem16.sv','cache.sv'], 'dm_cache', ['mem16x8'], {}, 'memory -nomap; opt -full; opt_clean'),
 'op_add':     (['opgates.sv'], 'op_add', [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_sub':     (['opgates.sv'], 'op_sub', [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_eq':      (['opgates.sv'], 'op_eq',  [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_lt':      (['opgates.sv'], 'op_lt',  [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_redor':   (['opgates.sv'], 'op_redor', [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_lnot':    (['opgates.sv'], 'op_lnot',  [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_mux':     (['opgates.sv'], 'op_mux',   [], {'N':4}, 'techmap; opt -fast; opt_clean'),
 'op_pmux':    (['opgates.sv'], 'op_pmux',  [], {'N':2}, 'techmap; opt -fast; opt_clean'),
 'eq_n':       (['gates.sv','opgates.sv'], 'eq_n', ['xor_n','or_n','not_n','nand2'], {'N':4}, ''),
 'lts_n':      (['gates.sv','opgates.sv'], 'lts_n', ['ltu_n','xor_n','mux2_n','nand2'], {'N':4}, ''),
 'ltu_n':      (['gates.sv','opgates.sv'], 'ltu_n', ['sub_n','not_n','nand2'], {'N':4}, ''),
 'sub_n':      (['gates.sv','opgates.sv'], 'sub_n', ['rca','not_n','nand2'], {'N':4}, ''),
 'fpu_mmio':   (['fpu.sv'], 'fpu_mmio', ['fpu_core'], {}, 'opt -full; dffunmap; opt_clean'),
 'fpu_core':   (['fpu.sv'], 'fpu_core', ['fp_add32','fp_mul32','fp_cmp32'], {}, ''),
 'lzc64':      (['fpu.sv'], 'lzc64', [], {}, 'opt -full; opt_clean'),
 'fpu_bus':    (['rv_blocks.sv','fpu.sv','cpu_fpu.sv'], 'fpu_bus', ['dmem','fpu_mmio'], {}, 'opt -full; opt_clean'),
 'mul_step':   (['arith.sv'], 'mul_step', [], {'W':4}, 'opt -full; opt_clean'),
 'div_step':   (['arith.sv'], 'div_step', [], {'W':4}, 'opt -full; opt_clean'),
}
SHOWINST=True
RENAME=[(r'g_leaf\[(\d+)\]\.ux', r'x\1'), (r'g_node\[(\d+)\]\.uo', r'or\1'), (r'g_inv\[(\d+)\]\.u', r'inv\1'),(r'g_lvl\[(\d+)\]\.g_pos\[(\d+)\]\.g_comb\.uc', r'G L\1 k\2'),
        (r'g_lvl\[(\d+)\]\.g_pos\[(\d+)\]\.g_comb\.ua', r'P L\1 k\2'),
        (r'g_bit\[(\d+)\]\.ug', r'g\1'), (r'g_bit\[(\d+)\]\.up', r'p\1'),
        (r'g_sum\[(\d+)\]\.us', r's\1'), (r'^g_mc\.', '')]
COMPACT={'rv_single'}
NARROW={'fpu_core','fpu_bus','eq_n','lts_n','ltu_n','sub_n','ks4','rv_multi','dm_cache','rca4','dff_ms','mul_array4','stage_F','mux16x8','mem16x8','ctl_microcoded'}
def run(name):
    files, top, bbs, params, extra = JOBS[name]
    ys = [f'read_verilog -sv {H}/{f}' for f in files]
    ys += [f'chparam -set {k} {v} {top}' for k,v in params.items()]
    ys += [f'hierarchy -top {top}']
    ys += [f'blackbox {b}' for b in bbs if True]
    ys += ['proc', 'opt_clean']
    if extra: ys += [extra]
    ys += ['opt_clean', f'write_json {name}.json']
    open(f'{name}.ys','w').write('\n'.join(ys)+'\n')
    r = subprocess.run(['yowasp-yosys','-q',f'{name}.ys'],capture_output=True,text=True)
    if r.returncode: print(name, r.stdout[-800:], r.stderr[-800:]); return
    d = json.load(open(f'{name}.json'))
    # keep only the top module (+ blackbox stubs are irrelevant to the drawing)
    tops = {k:v for k,v in d['modules'].items() if v['attributes'].get('top')}
    for m in tops.values():
        m['cells'] = {k:v for k,v in m['cells'].items() if v['type'] != '$scopeinfo'}
    for m in tops.values():
        for c in m['cells'].values():
            if c['type'] == 'nand2':
                c['type'] = '$_NAND_'
                c['port_directions'] = {k.upper():v for k,v in c['port_directions'].items()}
                c['connections'] = {k.upper():v for k,v in c['connections'].items()}
            c['type'] = re.sub(r'^\$paramod\\(\w+)\\.*', r'\1', c['type'])
    for m in tops.values():
        for cn, c in m['cells'].items():
            if not c['type'].startswith('$'):
                nm = cn
                for pat, rep in RENAME:
                    nm = re.sub(pat, rep, nm)
                c['type'] = f"{nm} : {c['type']}" if SHOWINST else c['type']
    d['modules'] = tops
    json.dump(d, open(f'{name}.json','w'))
    skin = 'skin_compact.svg' if name in COMPACT else ('skin_narrow.svg' if name in NARROW else SKIN)
    r = subprocess.run([NS, f'{name}.json', '-o', f'{name}.raw.svg', '--skin', skin],capture_output=True,text=True)
    if r.returncode: print(name, r.stderr[-800:]); return
    print('ok', name)
if __name__ == '__main__':
    for n in (sys.argv[1:] or JOBS): run(n)
