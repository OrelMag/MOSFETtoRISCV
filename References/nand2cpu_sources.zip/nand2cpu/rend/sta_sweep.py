# Run time vs memory access delay, using the synthesized netlists from sta_struct.py.
import json, sta_struct as S
R=json.load(open('sta_struct.json'))
CYC={'single-cycle':60,'multicycle':230,'pipeline':87,'pipeline + prediction':71}
D={'single-cycle':('rv_single',{'instr':'pc','readdata':'aluresult'},['aluresult','writedata','memwrite']),
   'multicycle':('rv_multi',{'instr_rd':'iadr','data_rd':'dadr'},['dadr','dwd','dwe']),
   'pipeline':('rv_pipe',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM']),
   'pipeline + prediction':('rv_pipe_bp',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM'])}
tmems=[13,25,50,75,100,150,200]
out={}
for name,(top,rd,wr) in D.items():
    m=json.load(open(f'ss_{top}ks.json')); m=[v for v in m['modules'].values() if v['attributes'].get('top')][0]
    out[name]={}
    for t in tmems:
        res,_=S.analyze(m,rd,wr,t,R['memory']['t_memw'])
        T,_c=S.period(res); out[name][t]=(T, T*CYC[name])
    print(name, {t:v for t,v in out[name].items()})
json.dump(out,open('sta_sweep.json','w'),indent=1)
