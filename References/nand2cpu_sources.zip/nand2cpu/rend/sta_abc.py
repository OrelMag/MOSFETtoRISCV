# Depth of a 32-bit adder and ALU after ABC technology mapping (abc -g NAND), versus the
# structural (no-ABC) mapping used for the processor timing in Section 7.11.
import subprocess, json, sys
from sta_cpu import graph, NEG
sys.setrecursionlimit(100000)
LCU={'Brent–Kung':'','Kogge–Stone':'techmap -map +/techmap.v -map +/choices/kogge-stone.v'}
def depth(top, pre):
    ys=['read_verilog -sv ../hdl/rv_blocks.sv', f'chparam -set W 32 {top}', f'hierarchy -top {top}',
        f'synth -flatten -top {top} -run :fine', pre, f'synth -flatten -top {top} -run fine:',
        'abc -g NAND', 'opt_clean', 'write_json da.json']
    open('da.ys','w').write('\n'.join(ys)+'\n'); subprocess.run(['yowasp-yosys','-q','da.ys'],check=True)
    d=json.load(open('da.json')); m=[v for v in d['modules'].values() if v['attributes'].get('top')][0]
    drv,_,_,k=graph(m); memo={}
    def a(b):
        if isinstance(b,str): return NEG
        if b not in memo: memo[b]= w+max(a(y) for y in x) if (b in drv and ((w:=drv[b][0]) or True) and (x:=drv[b][1])) else 0
        return memo[b]
    outs=[b for p,v in m['ports'].items() if v['direction']=='output' for b in v['bits']]
    return max(a(b) for b in outs), k['NAND']+k['NOT']
if __name__=='__main__':
    res={f'{t}|{n}':depth(t,p) for t in ('adder','alu') for n,p in LCU.items()}
    for k,v in res.items(): print(k,'depth',v[0],'gates',v[1])
    json.dump(res,open('sta_abc.json','w'),ensure_ascii=False,indent=1)
