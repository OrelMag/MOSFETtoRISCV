# Structural whole-processor timing: Yosys maps to simple gates WITHOUT ABC re-optimization,
# so the adder architecture chosen at techmap time is preserved. Each gate is costed by its
# depth in the NAND realizations of Table 2.1; the flip-flop numbers come from sim/tb_dffchar.sv.
import json, subprocess, sys, collections
sys.setrecursionlimit(200000)
T_PCQ, T_SETUP = 3, 1
COST = {  # (type): {input pin: NAND levels to Y}
 '$_NOT_': {'A':1}, '$_NAND_': {'A':1,'B':1}, '$_AND_': {'A':2,'B':2}, '$_OR_': {'A':2,'B':2},
 '$_NOR_': {'A':3,'B':3}, '$_XOR_': {'A':3,'B':3}, '$_XNOR_': {'A':4,'B':4},
 '$_ANDNOT_': {'A':2,'B':2}, '$_ORNOT_': {'A':2,'B':2}, '$_MUX_': {'A':2,'B':2,'S':3},
}
NEG=-10**9
LCU={'bk':'', 'ks':'techmap -map +/techmap.v -map +/choices/kogge-stone.v'}
def synth(files, top, lcu='bk', params=None, tag=''):
    ys=[f'read_verilog -sv ../hdl/{f}' for f in files]+[f'chparam -set {k} {v} {top}' for k,v in (params or {}).items()]
    ys+=[f'hierarchy -top {top}', f'synth -flatten -noabc -top {top} -run :fine', LCU[lcu],
         f'synth -flatten -noabc -top {top} -run fine:', 'dffunmap', 'opt_clean', f'write_json ss_{top}{tag}.json']
    open('ss.ys','w').write('\n'.join(ys)+'\n'); subprocess.run(['yowasp-yosys','-q','ss.ys'],check=True)
    d=json.load(open(f'ss_{top}{tag}.json')); return [v for v in d['modules'].values() if v['attributes'].get('top')][0]
def build(m):
    drv={}; ff=[]; kinds=collections.Counter()
    for c in m['cells'].values():
        t=c['type']; cn=c['connections']
        if t=='$scopeinfo': continue
        if t in COST:
            drv[cn['Y'][0]]=[(COST[t][p],cn[p][0]) for p in COST[t]]; kinds[t]+=1
        elif t in ('$_DFF_P_','$_DFF_N_'):
            ff.append((cn['D'][0],cn['Q'][0],t[-2])); kinds['DFF']+=1
        else: raise SystemExit('unexpected '+t)
    return drv, ff, kinds
def analyze(m, mem_reads={}, mem_writes=[], tmem=0, tmemw=0, inputs_zero=True):
    drv,ff,kinds=build(m); P=m['ports']
    qt={q:t for d,q,t in ff}
    rd={b:a for dp,a in mem_reads.items() for b in P[dp]['bits']}
    out={}
    def make(cls):
        memo={}
        def arr(b):
            if isinstance(b,str): return NEG
            if b in memo: return memo[b]
            memo[b]=NEG
            if b in drv:
                v=max((arr(x)+w for w,x in drv[b]), default=NEG); memo[b]=v if v>NEG//2 else NEG
            elif b in qt: memo[b]=T_PCQ if qt[b]==cls else NEG
            elif b in rd:
                v=max(arr(x) for x in P[rd[b]]['bits']); memo[b]=v+tmem if v>NEG//2 else NEG
            else: memo[b]=0 if cls=='P' else NEG
            return memo[b]
        return arr
    for cls in 'PN':
        arr=make(cls)
        eP=max([arr(d) for d,q,t in ff if t=='P']+[arr(b)+tmemw for p in mem_writes for b in P[p]['bits']]+[NEG])
        eN=max([arr(d) for d,q,t in ff if t=='N']+[NEG])
        outs=max([arr(b) for p,v in P.items() if v['direction']=='output' for b in v['bits']]+[NEG])
        out[cls]=(eP,eN,outs,arr)
    return out, kinds
def period(res):
    (pP,pN,_,_),(nP,nN,_,_)=res['P'],res['N']
    c={}
    if pP>NEG//2: c['rise→rise']=pP+T_SETUP
    if nN>NEG//2: c['fall→fall']=nN+T_SETUP
    if pN>NEG//2: c['rise→fall (half) ×2']=2*(pN+T_SETUP)
    if nP>NEG//2: c['fall→rise (half) ×2']=2*(nP+T_SETUP)
    return max(c.values()), c
if __name__=='__main__':
    R={}
    # memory: read depth (address -> data) and write depth (inputs -> storage D)
    m=synth(['rv_blocks.sv'],'dmem'); drv,ff,k=build(m); P=m['ports']
    def depth_from(srcs, sinks):
        memo={}
        def a(b):
            if isinstance(b,str): return NEG
            if b in memo: return memo[b]
            memo[b]=NEG
            if b in drv: v=max(a(x)+w for w,x in drv[b]); memo[b]=v if v>NEG//2 else NEG
            elif b in srcs: memo[b]=0
            return memo[b]
        return max(a(s) for s in sinks)
    tmem=depth_from(set(P['a']['bits']), P['rd']['bits'])
    tmemw=depth_from({b for p in ('a','wd','we') for b in P[p]['bits']}, [d for d,q,t in ff])
    R['memory']=dict(t_mem=tmem, t_memw=tmemw, t_pcq=T_PCQ, t_setup=T_SETUP)
    print('memory read', tmem, 'write', tmemw)
    # building blocks
    for lcu in ('bk','ks'):
        for top,prm in (('adder',{'W':32}),('alu',{'W':32})):
            m=synth(['rv_blocks.sv'],top,lcu,prm,tag=lcu); res,k=analyze(m)
            R[f'{top}32_{lcu}']=dict(depth=res['P'][2], gates=sum(v for kk,v in k.items() if kk!='DFF'))
            print(top,lcu,R[f'{top}32_{lcu}'])
    B=['rv_blocks.sv']
    designs={
     'single-cycle': (B+['rv_single.sv'],'rv_single',{'instr':'pc','readdata':'aluresult'},['aluresult','writedata','memwrite']),
     'multicycle':   (B+['microcode.sv','rv_multi.sv'],'rv_multi',{'instr_rd':'iadr','data_rd':'dadr'},['dadr','dwd','dwe']),
     'pipeline':     (B+['rv_pipe.sv'],'rv_pipe',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM']),
     'pipeline + prediction': (B+['rv_pipe.sv','rv_pipe_bp.sv'],'rv_pipe_bp',{'instrF':'pcF','readdataM':'aluresultM'},['aluresultM','writedataM','memwriteM']),
    }
    for name,(f,top,rdm,wr) in designs.items():
        for lcu in ('bk','ks'):
            m=synth(f,top,lcu,tag=lcu); res,k=analyze(m,rdm,wr,tmem,tmemw)
            T,c=period(res)
            # endpoint ranking for explanation
            qn={}
            for nm,nn in m['netnames'].items():
                if not nn.get('hide_name'):
                    for b in nn['bits']:
                        if isinstance(b,int): qn.setdefault(b,nm)
            drv,ff,_=build(m); arrP=res['P'][3]
            g=collections.defaultdict(lambda:NEG)
            for d,q,t in ff:
                if t=='P': g[qn.get(q,'?')]=max(g[qn.get(q,'?')],arrP(d)+T_SETUP)
            for p in wr: g['memory write ('+p+')']=max(arrP(b)+tmemw+T_SETUP for b in m['ports'][p]['bits'])
            top5=sorted(g.items(),key=lambda kv:-kv[1])[:5]
            R[f'{name}|{lcu}']=dict(T=T, cands=c, gates=sum(v for kk,v in k.items() if kk!='DFF'), dffs=k['DFF'], top=top5)
            print(name,lcu,T,c,top5,flush=True)
    json.dump(R,open('sta_struct.json','w'),ensure_ascii=False,indent=1)
