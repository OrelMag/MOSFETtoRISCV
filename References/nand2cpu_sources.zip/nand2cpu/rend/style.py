import re, glob, os
CSS = """
svg { stroke:#475569; fill:none; stroke-width:1.15; stroke-linecap:round; stroke-linejoin:round; }
text { fill:#0f172a; stroke:none; font-size:9.5px; font-family:'JetBrains Mono','Noto Sans Math',monospace; font-weight:500; }
.nodelabel { text-anchor:middle; font-weight:600; fill:#1e293b; font-family:'Inter','Noto Sans Math',sans-serif; font-size:9.5px; }
.inputPortLabel, .outLabel { text-anchor:end; font-size:8.5px; fill:#334155; }
.inLabel { text-anchor:start; font-size:8.5px; fill:#334155; }
.splitjoinBody { fill:#334155; stroke:#334155; }
.muxLabel { font-size:6.5px; fill:#a3245c; font-weight:600; }
.bus { stroke:#1e293b; stroke-width:2.1; }
g[data-k=nand] path, g[data-k=nand] circle, g[data-k=and] path, g[data-k=or] path,
g[data-k=reduce_nor] path, g[data-k=reduce_nor] circle, g[data-k=reduce_xor] path,
g[data-k=reduce_nxor] path, g[data-k=reduce_nxor] circle, g[data-k=not] path, g[data-k=not] circle
  { fill:#e7ecff; stroke:#3b4cc0; stroke-width:1.3; }
g[data-k=mux] path { fill:#fde8f1; stroke:#a3245c; stroke-width:1.3; }
g[data-k=dff] rect, g[data-k=dff] path, g[data-k=dffn] rect { fill:#dcf5e6; stroke:#157347; stroke-width:1.3; }
g[data-k=add] circle, g[data-k=sub] circle, g[data-k=eq] circle, g[data-k=lt] circle,
g[data-k=gt] circle, g[data-k=le] circle, g[data-k=ge] circle { fill:#e0f2fe; stroke:#0b6aa2; stroke-width:1.3; }
g[data-k=add] line, g[data-k=sub] line, g[data-k=eq] line, g[data-k=lt] line { stroke:#0b6aa2; stroke-width:1.4; }
g[data-k=generic] rect { fill:#fff5dc; stroke:#b7791f; stroke-width:1.3; rx:3px; }
g[data-k=inputExt] path { fill:#eef2f6; stroke:#64748b; }
g[data-k=outputExt] path { fill:#eef2f6; stroke:#64748b; }
g[data-k=constant] text { fill:#7c3aed; }
"""
def style(src, dst, pad=6):
    s = open(src).read()
    def scope(css):
        out=[]
        for rule in css.split('}'):
            if '{' not in rule: continue
            sel,body=rule.split('{',1)
            sels=','.join(('svg.nl' if x.strip()=='svg' else 'svg.nl '+x.strip()) for x in sel.split(','))
            out.append(sels+'{'+body+'}')
        return '\n'.join(out)
    s = re.sub(r'<style>.*?</style>', '<style>'+scope(CSS)+'</style>', s, flags=re.S)
    s = re.sub(r'<g s:type="(\w+)"', r'<g data-k="\1" s:type="\1"', s)
    s = re.sub(r'class="(net_[^"]*,[^"]*)"', lambda m: 'class="bus"', s)
    s = re.sub(r'<s:alias[^>]*/>', '', s)
    m = re.search(r'<svg ([^>]*)width="([\d.]+)" height="([\d.]+)">', s)
    w, h = float(m.group(2)), float(m.group(3))
    s = s.replace(m.group(0), f'<svg class="nl" {m.group(1)}viewBox="{-pad} {-pad} {w+2*pad} {h+2*pad}" width="{w+2*pad}" height="{h+2*pad}">', 1)
    # strip source-location noise from auto-generated cell ids
    s = re.sub(r'\$\.\./hdl/[\w.]+:\d+\$\d+', '', s)
    open(dst, 'w').write(s)
if __name__ == '__main__':
    os.makedirs('out', exist_ok=True)
    for f in glob.glob('*.raw.svg'):
        style(f, 'out/' + f.replace('.raw', ''))
