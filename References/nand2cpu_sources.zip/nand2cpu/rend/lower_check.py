# Verify Yosys' gate-level lowering: write each lowered operator back as Verilog and compare it
# exhaustively (by simulation) with the word-level operator it came from.
import subprocess, os
OPS=[('op_add',4,'y = a + b'),('op_add',8,'y = a + b'),('op_sub',4,'y = a - b'),('op_sub',8,'y = a - b'),
     ('op_eq',4,'y = (a == b)'),('op_eq',8,'y = (a == b)'),('op_lt',4,'y = (a < b)'),('op_lt',8,'y = (a < b)'),
     ('op_redor',8,'y = |a'),('op_lnot',8,'y = !a'),('op_mux',4,'y = s ? b : a'),('op_pmux',4,None)]
os.makedirs('low',exist_ok=True)
total=0
for top,N,expr in OPS:
    tag=f'{top}_{N}'
    open(f'low/{tag}.ys','w').write(f'read_verilog -sv ../hdl/opgates.sv\nchparam -set N {N} {top}\nhierarchy -top {top}\nproc\nflatten\ntechmap\nopt -fast\nopt_clean\nrename {top} low_{tag}\nwrite_verilog -noattr low/{tag}.v\n')
    subprocess.run(['yowasp-yosys','-q',f'low/{tag}.ys'],check=True)
    if top=='op_pmux':
        ports='d0, d1, d2, s'; decl=f'logic [{N-1}:0] d0, d1, d2; logic [2:0] s;'; width=3*N+3
        stim='{d0, d1, d2, s} = i;'
        ref=f'y_ref = s[0] ? d0 : s[1] ? d1 : s[2] ? d2 : {N}\'d0;'
        conn='.d0, .d1, .d2, .s'; valid='(s == 3\'b000 || s == 3\'b001 || s == 3\'b010 || s == 3\'b100)'
        ow=N
    else:
        if top in ('op_redor','op_lnot'):
            decl=f'logic [{N-1}:0] a;'; stim='a = i;'; conn='.a'; width=N
        elif top=='op_mux':
            decl=f'logic [{N-1}:0] a, b; logic s;'; stim='{a, b, s} = i;'; conn='.a, .b, .s'; width=2*N+1
        else:
            decl=f'logic [{N-1}:0] a, b;'; stim='{a, b} = i;'; conn='.a, .b'; width=2*N
        ref=expr.replace('y =','y_ref =')+';'; valid='1'
        ow=N if top in ('op_add','op_sub','op_mux') else 1
    tb=f'''module tb; {decl} logic [{ow-1}:0] y, y_ref; integer i, n = 0, bad = 0;
low_{tag} dut ({conn}, .y(y));
initial begin
  for (i = 0; i < {2**width}; i++) begin
    {stim} #1; {ref}
    if ({valid}) begin n++; if (y !== y_ref) bad++; end
  end
  $display("{tag} %0d %0d", n, bad);
end
endmodule
'''
    open(f'low/tb_{tag}.sv','w').write(tb)
    subprocess.run(f'iverilog -g2012 -o low/{tag}.vvp low/tb_{tag}.sv low/{tag}.v',shell=True,check=True)
    out=subprocess.run(f'vvp -n low/{tag}.vvp',shell=True,capture_output=True,text=True).stdout.split()
    n,bad=int(out[1]),int(out[2]); total+=n
    print(f'{tag:12s} vectors {n:6d} failures {bad}')
print('total vectors',total)
