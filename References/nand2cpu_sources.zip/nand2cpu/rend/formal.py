import subprocess, time, json, re
H='../hdl/'
JOBS = {
 'F1 adders (32-bit KS = RCA = +)':   (['gates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_blocks.sv', 'rv_pipe.sv', 'mem16.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_adders', 'comb'),
 'F2 multipliers (8×8 array = Dadda = *)': (['gates.sv', 'prefix.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'kmap.sv', 'rv_blocks.sv', 'rv_pipe.sv', 'mem16.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_mults', 'comb'),
 'F3 ALU (32-bit) meets specification': (['rv_blocks.sv', 'gates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_pipe.sv', 'mem16.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_alu', 'comb'),
 'F4 hazard-unit safety properties':  (['rv_blocks.sv', 'rv_pipe.sv', 'gates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'mem16.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_hazard', 'comb'),
 'F5 write decoder one-hot':          (['rv_blocks.sv', 'mem16.sv', 'gates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_pipe.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_decoder', 'comb'),
 'F6 control cores equal (16 states × 128 ops)': (['rv_blocks.sv', 'microcode.sv', 'gates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_pipe.sv', 'mem16.sv', 'opgates.sv', 'formal.sv'], 'prop_ctl_comb', 'comb'),
 'F8 K-map forms of segment e (valid BCD)': (['gates.sv', 'kmap.sv', 'prefix.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_blocks.sv', 'rv_pipe.sv', 'mem16.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_kmap', 'comb'),
 'F9 majority SoP = PoS = full-adder carry':  (['gates.sv', 'kmap.sv', 'prefix.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_blocks.sv', 'rv_pipe.sv', 'mem16.sv', 'microcode.sv', 'opgates.sv', 'formal.sv'], 'prop_majority', 'comb'),
 'F10 NAND-level operators equal +, −, ==, < (signed and unsigned)': (['gates.sv', 'opgates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_blocks.sv', 'rv_pipe.sv', 'mem16.sv', 'microcode.sv', 'formal.sv'], 'prop_ops', 'comb'),
 'F7 controllers sequentially equivalent': (['rv_blocks.sv', 'microcode.sv', 'gates.sv', 'prefix.sv', 'kmap.sv', 'mul_array8.sv', 'dadda8_rca.sv', 'dadda8_ks.sv', 'rv_pipe.sv', 'mem16.sv', 'opgates.sv', 'formal.sv'], 'prop_ctl_seq', 'seq'),
}
res={}
for name,(files,top,kind) in JOBS.items():
    rd=' '.join(H+f for f in files)
    sat = ('sat -prove-asserts -verify -show-inputs' if kind=='comb'
           else 'sat -tempinduct -prove-asserts -verify -set-init-zero')
    ys=f'read_verilog -sv -formal {rd}\nhierarchy -top {top}\nproc\nflatten\nmemory_map\nopt -fast\nasync2sync\ndffunmap\n{sat}\n'
    open('formal_job.ys','w').write(ys)
    t=time.time()
    r=subprocess.run(['yowasp-yosys','-q','formal_job.ys'],capture_output=True,text=True,timeout=1800)
    dt=time.time()-t
    ok = r.returncode==0
    res[name]=dict(ok=ok, seconds=round(dt,1))
    print(f'{name:48s} {"PROVED" if ok else "FAILED"}  {dt:6.1f}s', flush=True)
    if not ok: print(r.stdout[-1500:], r.stderr[-1500:])
json.dump(res,open('formal_results.json','w'),ensure_ascii=False,indent=1)
