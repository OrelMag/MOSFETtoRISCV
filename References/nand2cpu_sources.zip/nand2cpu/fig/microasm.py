# Micro-assembler: symbolic microprogram -> microcode.hex, dispatch1.hex, dispatch2.hex
FIELDS=[('AdrSrc',1),('IRWrite',1),('ALUSrcA',2),('ALUSrcB',2),('ALUOp',2),('ResultSrc',2),
        ('PCUpdate',1),('RegWrite',1),('MemWrite',1),('Branch',1)]
# label: (field settings, sequencing, next label)
PROG = [
 ('Fetch',    dict(IRWrite=1, ALUSrcB=0b10, ResultSrc=0b10, PCUpdate=1), 'jump',  'Decode'),
 ('Decode',   dict(ALUSrcA=0b01, ALUSrcB=0b01),                          'disp1', None),
 ('MemAdr',   dict(ALUSrcA=0b10, ALUSrcB=0b01),                          'disp2', None),
 ('MemRead',  dict(AdrSrc=1),                                            'jump',  'MemWB'),
 ('MemWB',    dict(ResultSrc=0b01, RegWrite=1),                          'jump',  'Fetch'),
 ('MemWrite', dict(AdrSrc=1, MemWrite=1),                                'jump',  'Fetch'),
 ('ExecuteR', dict(ALUSrcA=0b10, ALUOp=0b10),                            'jump',  'ALUWB'),
 ('ALUWB',    dict(RegWrite=1),                                          'jump',  'Fetch'),
 ('ExecuteI', dict(ALUSrcA=0b10, ALUSrcB=0b01, ALUOp=0b10),              'jump',  'ALUWB'),
 ('JAL',      dict(ALUSrcA=0b01, ALUSrcB=0b10, PCUpdate=1),              'jump',  'ALUWB'),
 ('BEQ',      dict(ALUSrcA=0b10, ALUOp=0b01, Branch=1),                  'jump',  'Fetch'),
]
DISP1 = {0b0000011:'MemAdr', 0b0100011:'MemAdr', 0b0110011:'ExecuteR',
         0b0010011:'ExecuteI', 0b1101111:'JAL', 0b1100011:'BEQ'}
DISP2 = {0b0000011:'MemRead', 0b0100011:'MemWrite'}
SEQ = {'jump':0, 'disp1':1, 'disp2':2}
def assemble():
    addr = {lab:i for i,(lab,*_) in enumerate(PROG)}
    words = []
    for lab, f, seq, nxt in PROG:
        cw = 0
        for name, w in FIELDS: cw = (cw << w) | f.get(name, 0)
        words.append((cw << 6) | (SEQ[seq] << 4) | (addr[nxt] if nxt else 0))
    return addr, words
if __name__ == '__main__':
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    addr, words = assemble()
    with open(f'{out}/microcode.hex','w') as fh:
        for w in words + [0]*(16-len(words)): fh.write(f'{w:05x}\n')
    for name, tab in (('dispatch1', DISP1), ('dispatch2', DISP2)):
        with open(f'{out}/{name}.hex','w') as fh:
            for op in range(128): fh.write(f'{addr.get(tab.get(op), 0):x}\n')
    for (lab, f, seq, nxt), w in zip(PROG, words):
        print(f'{addr[lab]:2d} {lab:9s} {w:05x} {seq:5s} {nxt or ""}')
