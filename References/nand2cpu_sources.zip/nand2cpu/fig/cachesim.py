# Reference model of the direct-mapped cache (same policy as hdl/cache.sv), plus trace
# generation and trace analysis. Each trace op is ('r', addr) or ('w', addr, data).
import random, json, sys
class DMCache:
    def __init__(s, lines=4, abits=4):
        s.lines=lines; s.ib=lines.bit_length()-1; s.abits=abits
        s.valid=[0]*lines; s.tag=[0]*lines; s.hits=s.misses=0
    def split(s,a): return a>>s.ib, a&(s.lines-1)
    def read(s,a):
        t,i=s.split(a)
        if s.valid[i] and s.tag[i]==t: s.hits+=1; return True
        s.misses+=1; s.valid[i]=1; s.tag[i]=t; return False
    def write(s,a):
        t,i=s.split(a); s.valid[i]=1; s.tag[i]=t
def run(trace, lines=4):
    c=DMCache(lines)
    for op in trace:
        if op[0]=='r': c.read(op[1])
        else: c.write(op[1])
    return c.hits, c.misses
def traces(seed=7):
    rnd=random.Random(seed); T={}
    T['sequential sweep ×4']=[('r',a) for _ in range(4) for a in range(16)]
    T['loop over 3 words']=[('r',a) for _ in range(20) for a in (4,5,6)]
    T['ping-pong 1 ↔ 5 (same index)']=[('r',a) for _ in range(20) for a in (1,5)]
    T['ping-pong 1 ↔ 6 (different index)']=[('r',a) for _ in range(20) for a in (1,6)]
    tr=[]
    for _ in range(400):
        if rnd.random()<0.25: tr.append(('w',rnd.randrange(16),rnd.randrange(256)))
        else: tr.append(('r',rnd.randrange(16)))
    T['uniform random (25% writes)']=tr
    return T
if __name__=='__main__':
    T=traces()
    with open(sys.argv[1] if len(sys.argv)>1 else 'cache_traces.txt','w') as f:
        # numeric format for the testbench: <op> <addr> <data>; op 2 = start of trace, 3 = end
        for k,(name,tr) in enumerate(T.items()):
            f.write(f'2 {k:x} 00\n')
            for op in tr: f.write(('0 %x 00\n'%op[1]) if op[0]=='r' else ('1 %x %02x\n'%(op[1],op[2])))
        f.write('3 0 00\n')
    res={n:run(t) for n,t in T.items()}
    json.dump(res,open('cache_model.json','w'),ensure_ascii=False,indent=0)
    for n,(h,m) in res.items(): print(f'{n:34s} hits {h:4d} misses {m:4d}')
