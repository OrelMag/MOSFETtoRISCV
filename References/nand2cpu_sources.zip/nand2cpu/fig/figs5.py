import sys, json, math
sys.path.insert(0,'.')
from figs import svg, T, R, L, ARROW, INK, MUTE, GATE, GS, REG, RS, BOX, BS, MUX, MS, ACC, RED
out={}
# ---------------- 4-bit two's-complement number wheel
b=''; cx,cy,r=230,210,150
for u in range(16):
    ang=math.radians(90-u*22.5)
    x=cx+r*math.cos(ang); y=cy-r*math.sin(ang)
    s=u-16 if u>=8 else u
    neg=u>=8
    b+=f'<circle cx="{x:.1f}" cy="{y:.1f}" r="24" fill="{MUX if neg else GATE}" stroke="{MS if neg else GS}" stroke-width="1.3"/>'
    b+=T(x,y-3,f'{u:04b}',10,'middle',INK,650,True)+T(x,y+11,f'{s:+d}' if s else '0',10,'middle',MS if neg else GS,700)
    xo=cx+(r+40)*math.cos(ang); yo=cy-(r+40)*math.sin(ang)
    b+=T(xo,yo+4,str(u),9,'middle',MUTE,500)
b+=f'<circle cx="{cx}" cy="{cy}" r="{r-45}" fill="none" stroke="#cbd5e1" stroke-dasharray="4 4"/>'
b+=T(cx,cy-18,'4-bit two\'s complement',11,'middle',INK,700)
b+=T(cx,cy-2,'inner label: signed value',9,'middle',MUTE)+T(cx,cy+12,'outer grey: unsigned value',9,'middle',MUTE)
# overflow boundaries
a1=math.radians(90-7.5*22.5); a2=math.radians(90-15.5*22.5)
for a,lab,col in ((a1,'signed overflow: +7 → −8',RED),(a2,'unsigned wrap: 15 → 0',ACC)):
    x1=cx+(r-40)*math.cos(a); y1=cy-(r-40)*math.sin(a); x2=cx+(r+26)*math.cos(a); y2=cy-(r+26)*math.sin(a)
    b+=L([(x1,y1),(x2,y2)],col,2)
b+=T(cx+10,cy+r+62,'signed overflow: +7 → −8 (red line)',10,'middle',RED,600)
b+=T(cx-8,cy-r-50,'unsigned wrap: 15 → 0 (blue line)',10,'middle',ACC,600)
out['numwheel']=svg(460,440,b)

# ---------------- IEEE 754 binary32 layout + examples
b=''; ox=30; u=19
fields=[('s',1,MUX,MS),('exponent e (8 bits, bias 127)',8,REG,RS),('fraction f (23 bits)',23,BOX,BS)]
x=ox
for i in (31,30,23,22,0):
    pass
for name,w,f,st in fields:
    b+=R(x,34,w*u,30,f,st,3,1.3)+T(x+w*u/2,54,name,10,'middle',INK,650)
    x+=w*u
for bit,xx in ((31,ox+u/2),(30,ox+u*1.5),(23,ox+u*8.5),(22,ox+u*9.5),(0,ox+u*31.5)):
    b+=T(xx,26,str(bit),9,'middle',MUTE,500,True)
rows=[('value (normal)','(−1)^s × 1.f × 2^(e−127)'),('value (subnormal, e = 0)','(−1)^s × 0.f × 2^(−126)'),
      ('e = 0, f = 0','±0'),('e = 255, f = 0','±∞'),('e = 255, f ≠ 0','NaN (RISC-V canonical: 0x7FC00000)')]
for i,(k,v) in enumerate(rows):
    b+=T(ox,92+i*17,k,10,'start',INK,650)+T(ox+210,92+i*17,v,10,'start',INK,500,True)
out['ieee754']=svg(ox*2+32*u,92+5*17,b)

# ---------------- toy 6-bit float number line (1 sign, 3 exponent bias 3, 2 fraction)
vals=[]
for e in range(7):
    for f in range(4):
        v=(f/4)*2**(1-3) if e==0 else (1+f/4)*2**(e-3)
        vals.append((v,'sub' if e==0 and f>0 else ('zero' if e==0 else 'norm'),e,f))
W=720; x0,x1=30,690; b=''
def px(v): return x0+v/14*(x1-x0)
b+=L([(x0,60),(x1+14,60)],INK,1.2,'marker-end="url(#ar)"')+ARROW
for v,k,e,f in vals:
    col={'sub':'#c2410c','zero':INK,'norm':GS}[k]
    b+=f'<line x1="{px(v):.1f}" y1="48" x2="{px(v):.1f}" y2="72" stroke="{col}" stroke-width="1.6"/>'
for t in range(0,15,2): b+=T(px(t),90,str(t),9,'middle',MUTE)
b+=T(px(14),40,'max 14',9,'middle',GS,650)+T(x1+18,64,'∞',13,'start',INK,700)
# zoomed inset 0..1
zx0,zx1=30,690
def pz(v): return zx0+v*(zx1-zx0)
b+=L([(zx0,150),(zx1,150)],INK,1.2)
for v,k,e,f in vals:
    if v<=1.0:
        col={'sub':'#c2410c','zero':INK,'norm':GS}[k]
        b+=f'<line x1="{pz(v):.1f}" y1="138" x2="{pz(v):.1f}" y2="162" stroke="{col}" stroke-width="1.6"/>'
        b+=T(pz(v),178,f'{v:g}',8.5,'middle',col,600,True)
b+=T(zx0,125,'zoom on 0 … 1',10,'start',INK,650)
b+=T(zx0,205,'orange: subnormals (evenly spaced, fill the gap to 0) · blue: normal numbers (spacing doubles with each exponent)',9.5,'start',MUTE)
b+=T(zx0,20,'All non-negative values of a 6-bit toy format: 1 sign bit, 3 exponent bits (bias 3), 2 fraction bits',10,'start',INK,650)
out['toyfloat']=svg(W,215,b)

# ---------------- FP adder stages with measured cumulative depth
SHORT={'compare magnitudes':'compare','exponent difference':'exp. diff','align + sticky':'align + sticky','add / subtract':'add/sub',
       'leading-zero count':'LZC','normalize':'normalize','round':'round','pack + specials':'pack','significand product':'24×24 product',
       'result exponent':'exp.','underflow shift':'underflow shift','sticky bit':'sticky'}
bd=json.load(open('../rend/sta_fpu_breakdown.json'))
W=720; b=ARROW
def stages(y,title,rows,colr,colf):
    s=T(10,y-10,title,11,'start',INK,700)
    prev=0; x=10; tot=rows[-1][1]; scale=(W-110)/320
    for lab,t in rows:
        lab=SHORT.get(lab,lab); w=(t-prev)*scale
        s+=R(x,y,w,34,colf,colr,3,1.1)
        if w>36: s+=T(x+w/2,y+14,lab,8,'middle',INK,600)+T(x+w/2,y+27,f'+{t-prev}',8,'middle',MUTE,500,True)
        else: s+=T(x+w/2,y+52,lab,7.5,'middle',INK,600)+T(x+w/2,y+62,f'+{t-prev}',7.5,'middle',MUTE,500,True)
        x+=w; prev=t
    s+=T(x+4,y+22,f'{tot} levels',9.5,'start',colr,700)
    return s
b+=stages(30,'fp_add32 — cumulative NAND levels along the critical path',bd['fp_add32'],BS,BOX)
b+=stages(130,'fp_mul32',bd['fp_mul32'],MS,MUX)
alu=json.load(open('../rend/sta_struct.json'))['alu32_bk']['depth']
b+=T(10,236,'integer ALU for comparison',11,'start',INK,700)+R(10,244,alu*(W-110)/320,22,GATE,GS,3,1.1)+T(14+alu*(W-110)/320,259,f'{alu} levels',9.5,'start',GS,700)
out['fpstages']=svg(W,280,b)

# ---------------- integration: memory-mapped FPU and RISC-V F extension
b=ARROW
b+=T(10,20,'(a) FPU as a memory-mapped coprocessor (built and verified here)',11,'start',INK,700)
b+=R(20,40,120,70,MUX,MS,6)+T(80,70,'RV32I core',11,'middle',INK,700)+T(80,86,'any of the four',9,'middle',MUTE)
b+=R(190,40,110,70,GATE,GS,6)+T(245,68,'address',10,'middle',INK,650)+T(245,82,'decoder',10,'middle',INK,650)+T(245,98,'a[31:5] = 32 ?',8.5,'middle',MUTE,500,True)
b+=L([(140,75),(188,75)],'#475569',1.4,'marker-end="url(#ar)"')+T(164,68,'adr, wd, we',8,'middle',MUTE)
b+=R(350,28,150,40,REG,RS,5)+T(425,46,'data memory',10,'middle',INK,650)+T(425,60,'0x000 – 0x0FF',8.5,'middle',MUTE,500,True)
b+=R(350,82,150,46,BOX,BS,5)+T(425,98,'FPU registers',10,'middle',INK,650)+T(425,112,'0x400 A · 0x404 B · 0x408 OP',7.5,'middle',MUTE,500,True)+T(425,123,'0x40C RESULT · 0x410 CMP',7.5,'middle',MUTE,500,True)
b+=L([(300,60),(348,48)],'#475569',1.3,'marker-end="url(#ar)"')+L([(300,90),(348,104)],'#475569',1.3,'marker-end="url(#ar)"')
b+=R(540,82,140,46,BOX,BS,5)+T(610,100,'fpu_core',10,'middle',INK,650)+T(610,114,'add · sub · mul · compare',8,'middle',MUTE)
b+=L([(500,105),(538,105)],'#475569',1.3,'marker-end="url(#ar)"')
b+=T(10,160,'(b) FPU inside the processor: RISC-V F extension (described, not built here)',11,'start',INK,700)
xs=[20,150,280,410,540]; labs=[('Fetch',''),('Decode','+ F opcodes, FP regfile read'),('Execute','ALU  ∥  FPU (multi-cycle → stall)'),('Memory','FLW / FSW'),('Writeback','x or f register, fflags')]
for x,(n,s) in zip(xs,labs):
    b+=R(x,180,120,50,MUX if n in('Decode','Execute','Writeback') else '#ffffff',MS if n in('Decode','Execute','Writeback') else '#94a3b8',5)
    b+=T(x+60,200,n,10.5,'middle',INK,700)+T(x+60,216,s,7.5,'middle',MUTE)
for i in range(4): b+=L([(xs[i]+120,205),(xs[i+1]-2,205)],'#475569',1.3,'marker-end="url(#ar)"')
b+=R(150,250,250,34,REG,RS,5)+T(275,266,'f0 – f31 (32 × 32-bit) + fcsr',9.5,'middle',INK,650)+T(275,279,'fcsr = frm (rounding mode) · fflags NV DZ OF UF NX',7.5,'middle',MUTE)
out['fpuint']=svg(700,295,b)
for k,v in out.items(): open(f'{k}.svg','w').write(v)
print(list(out))
