import sys, json, math, re
sys.path.insert(0,'.')
from figs import svg, T, R, L, ARROW, INK, MUTE, GATE, GS, REG, RS, BOX, BS, MUX, MS, ACC, RED
out={}
GRAY=['00','01','11','10']
# ---------------- K-maps with verified groupings
def cube_cells(cube, nv):
    # cube: string over '01-' in variable order (MSB first); returns minterm indices
    idx=[0]
    for ch in cube:
        idx=[2*i+b for i in idx for b in ((0,1) if ch=='-' else (int(ch),))]
    return set(idx)
def check(nv, on, dc, groups, pos):
    target = set(range(2**nv))-set(on)-set(dc) if pos else set(on)
    allowed = target|set(dc)
    cov=set()
    for g,_ in groups:
        c=cube_cells(g,nv); assert c<=allowed, (g,c-allowed); cov|=c
    assert target<=cov, target-cov
def kmap(ox, oy, title, rowvars, colvars, nv, on, dc, groups, pos, expr):
    check(nv,on,dc,groups,pos)
    nr=2**len(rowvars); nc=4; cw=38; ch=30
    rows=GRAY[:nr] if nr==4 else ['0','1']
    s=T(ox+40+nc*cw/2, oy-30, title, 11, 'middle', INK, 700)
    s+=T(ox+34, oy-6, f'{"".join(rowvars)}\\{"".join(colvars)}', 9, 'end', MUTE, 600, True)
    for j,cc in enumerate(GRAY): s+=T(ox+40+j*cw+cw/2, oy-6, cc, 9, 'middle', MUTE, 600, True)
    cellpos={}
    for i,rr in enumerate(rows):
        s+=T(ox+34, oy+i*ch+ch/2+4, rr, 9, 'end', MUTE, 600, True)
        for j,cc in enumerate(GRAY):
            m=int(rr+cc,2); cellpos[m]=(i,j)
            v='1' if m in on else ('×' if m in dc else '0')
            fill='#ffffff'
            s+=R(ox+40+j*cw, oy+i*ch, cw, ch, fill, '#94a3b8', 0, 0.8)
            col=INK if v=='1' else (MUTE if v=='×' else '#94a3b8')
            s+=T(ox+40+j*cw+cw/2, oy+i*ch+ch/2+4, v, 12, 'middle', col, 700 if v=='1' else 500)
            s+=T(ox+40+j*cw+cw-3, oy+i*ch+9, str(m), 6.5, 'end', '#cbd5e1')
    palette=['#3b4cc0','#c2410c','#15803d','#a3245c']
    for gi,(g,lab) in enumerate(groups):
        cells=cube_cells(g,nv); col=palette[gi%4]
        ii=sorted({cellpos[m][0] for m in cells}); jj=sorted({cellpos[m][1] for m in cells})
        def spans(v,n):   # contiguous spans with wrap-around
            if len(v)==n: return [(0,n-1)]
            if v==[0,n-1]: return [(0,0),(n-1,n-1)]
            return [(v[0],v[-1])]
        ins=2+gi*3
        for (i0,i1) in spans(ii,nr):
            for (j0,j1) in spans(jj,nc):
                x=ox+40+j0*cw+ins; y=oy+i0*ch+ins
                w=(j1-j0+1)*cw-2*ins; h=(i1-i0+1)*ch-2*ins
                s+=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="9" fill="{col}" fill-opacity="0.07" stroke="{col}" stroke-width="1.8"/>'
        s+=T(ox+40, oy+nr*ch+16+gi*13, '■', 10, 'start', col)+T(ox+52, oy+nr*ch+16+gi*13, lab, 9.5, 'start', INK, 500, True)
    s+=T(ox+40, oy+nr*ch+16+len(groups)*13+4, expr, 10, 'start', col if False else INK, 700, True)
    return s
b=''
b+=kmap(10, 50, 'majority — SoP (group 1s)', ['a'], ['b','c'], 3, [3,5,6,7], [],
        [('11-','ab'),('1-1','ac'),('-11','bc')], False, 'y = ab + ac + bc')
b+=kmap(215, 50, 'majority — PoS (group 0s)', ['a'], ['b','c'], 3, [3,5,6,7], [],
        [('00-','(a + b)'),('0-0','(a + c)'),('-00','(b + c)')], True, 'y = (a+b)(a+c)(b+c)')
b+=kmap(10, 245, 'segment e — SoP', ['A','B'], ['C','D'], 4, [0,2,6,8], list(range(10,16)),
        [('-0-0',"B'D'"),('--10',"CD'")], False, "e = B'D' + CD'")
b+=kmap(215, 245, 'segment e — PoS', ['A','B'], ['C','D'], 4, [0,2,6,8], list(range(10,16)),
        [('---1',"(D')"),('-10-',"(B' + C)")], True, "e = D'(B' + C)")
out['kmaps']=svg(420, 400, b)

# ---------------- Kogge–Stone prefix graph, N = 8 (+ carry-in position)
N=8; K=N+1; Lv=math.ceil(math.log2(K))
W=560; dx=56; dy=58; ox=40; oy=40
b=ARROW
for k in range(K):
    x=ox+(K-1-k)*dx
    b+=T(x, oy-16, 'cin' if k==0 else f'bit {k-1}', 9, 'middle', MUTE, 600, True)
for l in range(Lv+1):
    b+=T(8, oy+l*dy+4, f'L{l}', 9, 'start', MUTE, 600, True)
for l in range(Lv):
    for k in range(K):
        x=ox+(K-1-k)*dx; y0=oy+l*dy; y1=y0+dy
        if k >= (1<<l):
            xs=ox+(K-1-(k-(1<<l)))*dx
            b+=L([(x,y0),(x,y1-8)],'#94a3b8',1.2)+L([(xs,y0),(x,y1-8)],ACC,1.2)
            b+=f'<circle cx="{x}" cy="{y1}" r="7" fill="{BOX}" stroke="{BS}" stroke-width="1.4"/>'
        else:
            b+=L([(x,y0),(x,y1)],'#cbd5e1',1.2,'stroke-dasharray="3 3"')
for k in range(K):
    x=ox+(K-1-k)*dx
    b+=f'<rect x="{x-7}" y="{oy-7}" width="14" height="14" rx="2" fill="{GATE}" stroke="{GS}" stroke-width="1.2"/>'
    b+=T(x, oy+Lv*dy+24, 'c'+str(k) if k<K-1 else 'cout', 9, 'middle', INK, 600, True)
b+=T(W/2-10, oy+Lv*dy+44, 'blue squares: (g, p) of each position · amber circles: combine cells (gcombine + AND) · blue edge: span 2^l back', 8.5, 'middle', MUTE)
out['prefix']=svg(W, oy+Lv*dy+52, b)

# ---------------- direct-mapped cache organization
b=ARROW
b+=T(20,24,'address (4 bits)',10,'start',INK,650)
b+=R(20,32,70,26,BOX,BS,3)+T(55,49,'tag a[3:2]',9,'middle',INK,600,True)
b+=R(90,32,70,26,MUX,MS,3)+T(125,49,'index a[1:0]',9,'middle',INK,600,True)
tx=230
for i,h in enumerate(['valid','tag','data (8 bits)']):
    b+=T([tx+18,tx+60,tx+140][i],24,h,9,'middle',MUTE,600)
for r in range(4):
    y=32+r*28; hot=(r==1)
    f='#fef3c7' if hot else '#ffffff'
    b+=R(tx,y,36,26,f,'#94a3b8',2,1)+T(tx+18,y+17,'1' if r!=3 else '0',10,'middle',INK,600,True)
    b+=R(tx+36,y,48,26,f,'#94a3b8',2,1)+T(tx+60,y+17,['10','01','11','00'][r],10,'middle',INK,600,True)
    b+=R(tx+84,y,112,26,f,'#94a3b8',2,1)+T(tx+140,y+17,['0x3C','0x96','0x07','—'][r],10,'middle',INK,600,True)
    b+=T(tx-8,y+17,f'line {r}',9,'end',MUTE,600)
b+=L([(160,45),(200,45),(200,73),(228,73)],MS,1.4,'marker-end="url(#ar)"')+T(196,90,'selects line',8.5,'end',MS)
# comparator & hit
b+=f'<circle cx="{tx+60}" cy="170" r="14" fill="#e0f2fe" stroke="#0b6aa2" stroke-width="1.4"/>'+T(tx+60,174,'=',13,'middle','#0b6aa2',700)
b+=L([(tx+60,86),(tx+60,154)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(55,58),(55,170),(tx+44,170)],BS,1.3,'marker-end="url(#ar)"')
b+=R(tx+100,156,34,28,GATE,GS,4)+T(tx+117,174,'AND',8,'middle',GS,700)
b+=L([(tx+74,170),(tx+98,170)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(tx+18,86),(tx+18,200),(tx+117,200),(tx+117,186)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(tx+134,170),(tx+230,170)],RED,1.5,'marker-end="url(#arr)"')+T(tx+234,174,'hit',11,'start',RED,700)
b+=L([(tx+196,73),(tx+230,73)],'#475569',1.3,'marker-end="url(#ar)"')+T(tx+234,77,'cached word',10,'start',INK,600)
b+=T(20,226,'Address 0x5 = tag 01, index 01: line 1 is valid and holds tag 01, so the read is a hit.',9.5,'start',MUTE)+T(20,240,'Address 0x1 (tag 00, same index) would miss and replace line 1.',9.5,'start',MUTE)
out['cache']=svg(560,250,b)

# ---------------- CPU comparison chart (cycles to run the test program)
data=[('single-cycle',60,'#64748b'),('multicycle',230,'#b7791f'),('5-stage pipeline',87,'#3b4cc0'),('pipeline + prediction',71,'#15803d')]
W=560; b=''; x0=150; sc=(W-x0-60)/240
for i,(n,v,c) in enumerate(data):
    y=18+i*34
    b+=T(x0-10,y+17,n,10.5,'end',INK,600)
    b+=R(x0,y+4,v*sc,20,c,c,3,1)+T(x0+v*sc+6,y+19,f'{v} cycles',10,'start',INK,700,True)
b+=T(20,18+4*34+10,'Measured clock cycles for the 60-instruction test program; run time = cycles × clock period.',9,'start',MUTE)
out['cpu_cmp']=svg(W,18+4*34+20,b)
for k,v in out.items(): open(f'{k}.svg','w').write(v)
print(list(out))
