import sys; sys.path.insert(0,'.')
from figs import svg, T, R, L, ARROW, INK, MUTE, GATE, GS, REG, RS, BOX, BS, MUX, MS, ACC, RED
out={}
# ---------------- 1. dependency tree NAND -> pipelined CPU
nodes = {
 # id: (label, sub, level, x, style)
 'cpu':   ('rv_pipe', 'pipelined CPU · ch. 8', 0, 360, 'mux'),
 'sF':    ('stage_F', 'fetch', 1, 70, 'box'),
 'sD':    ('stage_D', 'decode', 1, 180, 'box'),
 'sE':    ('stage_E', 'execute', 1, 290, 'box'),
 'sW':    ('stage_W', 'write-back', 1, 400, 'box'),
 'preg':  ('reg_FD…MW', 'pipeline regs', 1, 510, 'reg'),
 'haz':   ('hazard', 'fwd · stall · flush', 1, 620, 'box'),
 'ctl':   ('controller', 'decoders · ch. 7', 2, 70, 'box'),
 'ext':   ('extend', 'immediates · ch. 6', 2, 175, 'box'),
 'alu':   ('alu', 'ALU · ch. 4', 2, 280, 'box'),
 'mux':   ('mux2 / mux3', 'selectors', 2, 385, 'mux'),
 'rf':    ('regfile', 'register file · ch. 5', 2, 490, 'reg'),
 'eq':    ('comparators', '= · ≠ 0', 2, 610, 'box'),
 'add':   ('adder / cla4', 'carry logic · ch. 4', 3, 150, 'box'),
 'reg':   ('register', 'W flip-flops · ch. 5', 3, 380, 'reg'),
 'dec':   ('decoder', 'address select · App. C', 3, 560, 'box'),
 'fa':    ('full_adder', '9 NAND', 4, 90, 'gate'),
 'muxn':  ('mux2_n', '4 NAND', 4, 230, 'gate'),
 'dff':   ('dff_ms', 'master–slave', 4, 380, 'reg'),
 'andor': ('and_n · or_n', '2 · 3 NAND', 4, 540, 'gate'),
 'xor':   ('xor_n / half_adder', '4 · 5 NAND', 5, 110, 'gate'),
 'lat':   ('d_latch', '5 NAND · ch. 5', 5, 380, 'reg'),
 'not':   ('not_n', '1 NAND', 5, 560, 'gate'),
 'sr':    ('sr_latch_n', 'feedback', 6, 380, 'reg'),
 'nand':  ('nand2', 'the only primitive · ch. 2', 7, 360, 'nand'),
}
edges = [('cpu',x) for x in ('sF','sD','sE','sW','preg','haz')] + [
 ('sF','mux'),('sF','add'),('sF','reg'),('sD','ctl'),('sD','ext'),('sD','rf'),('sE','mux'),('sE','alu'),('sE','add'),
 ('sW','mux'),('preg','reg'),('haz','eq'),('haz','mux'),('rf','reg'),('rf','dec'),('rf','mux'),
 ('ctl','andor'),('ext','mux'),('alu','add'),('alu','mux'),('alu','andor'),('eq','xor'),
 ('mux','muxn'),('add','fa'),('reg','dff'),('reg','muxn'),('dec','andor'),('dec','not'),
 ('fa','xor'),('muxn','nand'),('dff','lat'),('andor','nand'),('xor','nand'),('lat','sr'),('not','nand'),('sr','nand')]
sty = {'mux':(MUX,MS),'box':(BOX,BS),'reg':(REG,RS),'gate':(GATE,GS),'nand':('#3b4cc0','#1e2a8a')}
W=720; top=30; dy=92; nw=100; nh=40
pos={k:(v[3], top+v[2]*dy) for k,v in nodes.items()}
b=''
for i,(lab) in enumerate(['system','stages','datapath blocks','arithmetic & storage','gate-level cells','primitive cells','feedback core','primitive']):
    b+=T(8, top+i*dy+nh/2+4, '', 8,'start',MUTE)
for a,c in edges:
    (x1,y1),(x2,y2)=pos[a],pos[c]
    ym=(y1+nh+y2)/2
    b+=f'<path d="M{x1},{y1+nh} C{x1},{ym} {x2},{ym} {x2},{y2}" fill="none" stroke="#94a3b8" stroke-width="1.1"/>'
for k,(lab,sub,lv,x,st) in nodes.items():
    f,s=sty[st]; y=pos[k][1]; w=nw+(30 if k in('xor','andor','cpu','nand') else 0)
    b+=R(x-w/2,y,w,nh,f,s,7,1.4)
    fc='white' if st=='nand' else INK
    b+=T(x,y+17,lab,10.5,'middle',fc,650,True)+T(x,y+31,sub,8.5,'middle','#e0e7ff' if st=='nand' else MUTE)
out['tree']=svg(W, top+7*dy+nh+10, b)

# ---------------- 2. 4x4 coincident-selection grid
b=ARROW; ox,oy=150,60; cw,chh=92,62
b+=T(ox+2*cw,22,'column predecoder  a[1:0]',11,'middle',GS,650)
b+=T(28,oy+2*chh,'row predecoder  a[3:2]',11,'middle',GS,650,False,f'transform="rotate(-90 28 {oy+2*chh})"')
for c in range(4):
    x=ox+c*cw+cw/2
    b+=R(x-22,30,44,18,GATE,GS,3,1)+T(x,43,f'col {c}',9,'middle',GS,600)
    b+=L([(x,48),(x,oy+4*chh)],GS,1.1)
for r in range(4):
    y=oy+r*chh+chh/2
    b+=R(46,y-9,52,18,GATE,GS,3,1)+T(72,y+4,f'row {r}',9,'middle',GS,600)
    b+=L([(98,y),(ox+4*cw,y)],RS,1.1)
    for c in range(4):
        x=ox+c*cw; a=4*r+c
        hot=(a==9)
        b+=R(x+14,oy+r*chh+10,cw-28,chh-20,'#fde68a' if hot else REG,BS if hot else RS,4,1.6 if hot else 1)
        b+=T(x+cw/2,oy+r*chh+chh/2+1,f'word {a}',9.5,'middle',INK,650)
        b+=T(x+cw/2,oy+r*chh+chh/2+13,f'0x{a:X} = {a:04b}',8,'middle',MUTE,500,True)
        b+=f'<circle cx="{x+cw/2}" cy="{oy+r*chh+chh/2}" r="0" />'
b+=T(ox+2*cw-40,oy+4*chh+22,'address 0x9 = binary 10 01  →  row 2 · column 1 · we  →  only word 9 is written',10,'middle',BS,600)
out['memgrid']=svg(ox+4*cw+20, oy+4*chh+34, b)

# ---------------- 3. waveform from simulation log
rows=[l.split() for l in open('../sim/mem_wave.log')]
t0=int(rows[0][0]); samples=[(int(r[0])-t0, r[1:]) for r in rows]
tmax=samples[-1][0]
names=['clk','we','wa','wd','ra','rd']
W=720; x0=60; sx=(W-x0-10)/tmax; rh=30; b=''
for i,nm in enumerate(names):
    y=16+i*rh
    b+=T(x0-10,y+14,nm,11,'end',INK,650,True)
    vals=[s[1][i] for s in samples]; ts=[s[0] for s in samples]
    if nm in('clk','we'):
        pts=[]; prev=None
        for t,v in zip(ts,vals):
            yy=y+4 if v=='1' else y+20
            if prev is not None and yy!=prev: pts.append((x0+t*sx,prev))
            pts.append((x0+t*sx,yy)); prev=yy
        b+=L(pts,ACC if nm=='clk' else RED,1.5)
    else:
        seg=[]; start=0
        for k in range(1,len(vals)+1):
            if k==len(vals) or vals[k]!=vals[start]:
                seg.append((ts[start], ts[k-1]+1 if k==len(vals) else ts[k], vals[start])); start=k
        for (a,c,v) in seg:
            xa,xc=x0+a*sx,x0+min(c,tmax)*sx
            col='#fef3c7' if nm=='rd' else '#f8fafc'
            b+=f'<path d="M{xa+2},{y+4} L{xc-2},{y+4} L{xc},{y+12} L{xc-2},{y+20} L{xa+2},{y+20} L{xa},{y+12} Z" fill="{col}" stroke="#475569" stroke-width="1"/>'
            if xc-xa>18: b+=T((xa+xc)/2,y+16,v.upper(),9,'middle',INK,500,True)
# annotate write events (rising edges where we = 1) and the suppressed write
ev=[]
for k in range(1,len(samples)):
    t,v=samples[k]; tp,vp=samples[k-1]
    if vp[0]=='0' and v[0]=='1':
        if v[1]=='1': ev.append((t,f'write {v[3].upper()} → word {int(v[2],16)}',RED))
        elif v[3]=='69': ev.append((t,'we = 0: nothing written',MUTE))
yb=16+len(names)*rh+4
seen=set()
for t,lab,col in ev:
    if lab in seen: continue
    seen.add(lab)
    x=x0+t*sx
    b+=L([(x,10),(x,yb)],col,0.9,'stroke-dasharray="3 3"')+T(x+4,yb+12,lab,9,'start',col,600)
out['memwave']=svg(W,yb+20,b)

# ---------------- 4. hardwired vs microprogrammed block diagrams
b=ARROW
def panel(ox,title,boxes,notes):
    s=T(ox+160,18,title,12,'middle',INK,700)
    for (x,y,w,h,lab,sub,st) in boxes:
        f,st2={'box':(BOX,BS),'reg':(REG,RS),'gate':(GATE,GS),'mux':(MUX,MS)}[st]
        s+=R(ox+x,y,w,h,f,st2,5,1.3)+T(ox+x+w/2,y+h/2+(0 if sub else 4),lab,10.5,'middle',INK,650)
        if sub: s+=T(ox+x+w/2,y+h/2+13,sub,8.5,'middle',MUTE)
    for n,(tx,ty) in enumerate(notes): s+=T(ox+tx,ty,notes[n][0] if False else '',9,'start',MUTE)
    return s
b+=panel(0,'Hardwired control',[
  (100,40,120,32,'state register','4 bits','reg'),
  (40,110,240,70,'next-state + output logic','gates derived from the state diagram','gate'),
],[])
b+=L([(160,72),(160,108)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(40,145),(15,145),(15,56),(98,56)],'#475569',1.3,'marker-end="url(#ar)"')
b+=T(10,200,'op →',10,'start',INK,600)+L([(40,196),(80,196),(80,182)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(280,145),(320,145)],'#475569',1.3,'marker-end="url(#ar)"')+T(324,149,'control',10,'start',INK,600)
b+=T(160,232,'fast, compact; changing behaviour means changing logic',9,'middle',MUTE)
X=390
b+=panel(X,'Microprogrammed control',[
  (100,40,120,32,'μPC','micro-program counter','reg'),
  (70,100,180,46,'microcode ROM','16 × 20-bit words','box'),
  (20,170,100,32,'dispatch 1 / 2','ROMs indexed by op','box'),
  (170,170,80,32,'next-addr mux','seq field','mux'),
],[])
b+=L([(X+160,72),(X+160,98)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(X+160,146),(X+210,168)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(X+120,186),(X+168,186)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(X+250,186),(X+290,186),(X+290,26),(X+80,26),(X+80,56),(X+98,56)],'#475569',1.3,'marker-end="url(#ar)"')
b+=L([(X+250,118),(X+300,118)],'#475569',1.3,'marker-end="url(#ar)"')+T(X+303,122,'control',10,'start',INK,600)
b+=T(X+2,226,'op →',10,'start',INK,600)+L([(X+30,222),(X+70,222),(X+70,204)],'#475569',1.3,'marker-end="url(#ar)"')
b+=T(X+160,246,'regular; changing behaviour means rewriting ROM contents',9,'middle',MUTE)
out['hw_vs_mc']=svg(X+370,256,b)

# ---------------- 5. multicycle state diagram
S={0:('S0','Fetch',80,60),1:('S1','Decode',80,170),2:('S2','MemAdr',230,280),3:('S3','MemRead',160,390),
   4:('S4','MemWB',160,490),5:('S5','MemWrite',300,390),6:('S6','ExecuteR',420,280),7:('S7','ALUWB',520,390),
   8:('S8','ExecuteI',540,280),9:('S9','JAL',650,280),10:('S10','BEQ',760,280)}
b=ARROW; rr=34
def arrow(a,c,lab='',bend=0,col='#475569'):
    x1,y1=S[a][2],S[a][3]; x2,y2=S[c][2],S[c][3]
    import math
    dx,dy=x2-x1,y2-y1; d=math.hypot(dx,dy); ux,uy=dx/d,dy/d
    sx_,sy_=x1+ux*rr,y1+uy*rr; ex,ey=x2-ux*(rr+2),y2-uy*(rr+2)
    mx,my=(sx_+ex)/2-uy*bend,(sy_+ey)/2+ux*bend
    s=f'<path d="M{sx_:.1f},{sy_:.1f} Q{mx:.1f},{my:.1f} {ex:.1f},{ey:.1f}" fill="none" stroke="{col}" stroke-width="1.3" marker-end="url(#ar)"/>'
    if lab: s+=T(mx,my-4,lab,8.5,'middle',ACC,600,True)
    return s
b+=arrow(0,1)
for c,lab in [(2,'lw/sw'),(6,'R'),(8,'I'),(9,'jal'),(10,'beq')]: b+=arrow(1,c,lab)
b+=arrow(2,3,'lw'); b+=arrow(2,5,'sw'); b+=arrow(3,4); b+=arrow(6,7); b+=arrow(8,7); b+=arrow(9,7,'',-30)
# returns to fetch (drawn as short stubs)
for k in (4,5,7,10):
    x,y=S[k][2],S[k][3]
    b+=L([(x+rr*0.7,y+rr*0.7),(x+rr*0.7+14,y+rr*0.7+14)],RED,1.3,'marker-end="url(#arr)"')
    b+=T(x+rr*0.7+16,y+rr*0.7+26,'→ S0',8.5,'start',RED,600)
for k,(sid,nm,x,y) in S.items():
    b+=f'<circle cx="{x}" cy="{y}" r="{rr}" fill="{GATE if k in(0,1) else BOX}" stroke="{GS if k in(0,1) else BS}" stroke-width="1.4"/>'
    b+=T(x,y-2,sid,11,'middle',INK,700)+T(x,y+11,nm,8.5,'middle',MUTE)
b+=T(430,60,'Fetch and Decode are shared by every instruction;',10,'start',INK)
b+=T(430,76,'Decode dispatches on the opcode (dispatch table 1),',10,'start',INK)
b+=T(430,92,'MemAdr dispatches again (table 2). Red stubs return to S0.',10,'start',INK)
out['fsm']=svg(820,550,b)
for k,v in out.items(): open(f'{k}.svg','w').write(v)
print(list(out))
