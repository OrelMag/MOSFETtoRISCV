# Exact Dadda reduction for an n x n unsigned multiplier
def dadda(n=8):
    h=[min(c+1, 2*n-1-c) for c in range(2*n-1)]+[0]   # partial-product column heights (weight 2^c)
    d=[2]
    while d[-1] < max(h): d.append(int(d[-1]*1.5))
    targets=[x for x in reversed(d[:-1])]              # largest d_j below max height, down to 2
    stages=[h[:]]; fa=ha=0
    for t in targets:
        new=[0]*len(h); carry=0
        for c in range(len(h)):
            cur=h[c]+carry; carry=0
            while cur>t:
                if cur-t>=2: cur-=2; fa+=1          # 3:2 counter: 3 bits -> sum here + carry up
                else:        cur-=1; ha+=1          # 2:2 counter: 2 bits -> sum here + carry up
                carry+=1
            new[c]=cur
        h=new; stages.append(h[:])
    return targets, stages, fa, ha
if __name__=='__main__':
    t,s,fa,ha=dadda(8)
    print('targets',t,'FA',fa,'HA',ha)
    for x in s: print(x, 'max',max(x))
