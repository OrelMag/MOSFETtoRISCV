import sys, json
sys.path.insert(0,'.')
from figs import svg, T, R, L, INK, MUTE, GS, ACC, RED
cur=json.load(open('../rend/sta_curve.json'))
W=740; H=300; X0,Y0,X1,Y1=70,20,560,240
tmax=240; rmax=80000
def px(t): return X0+t/tmax*(X1-X0)
def py(r): return Y1-r/rmax*(Y1-Y0)
b=L([(X0,Y0),(X0,Y1),(X1,Y1)],INK,1.2)
for r in range(0,rmax+1,10000):
    b+=L([(X0-4,py(r)),(X1,py(r))],'#e2e8f0',0.8)+T(X0-8,py(r)+3,f'{r//1000}k',9,'end',MUTE)
for t in range(0,tmax+1,40): b+=T(px(t),Y1+14,str(t),9,'middle',MUTE)
b+=T((X0+X1)/2,Y1+32,'memory read delay t_mem (NAND levels)',10,'middle',INK)
b+=T(16,(Y0+Y1)/2,'run time (cycles × period)',10,'middle',INK,500,False,f'transform="rotate(-90 16 {(Y0+Y1)/2})"')
names={'s':('single-cycle','#64748b'),'m':('multicycle','#b7791f'),'p':('pipeline','#3b4cc0'),'b':('pipeline + prediction','#15803d')}
for i,(k,(n,c)) in enumerate(names.items()):
    pts=[(px(t),py(r)) for t,T_,r in cur[k]]
    b+=L(pts,c,2)
    b+=L([(X1+14,Y0+30+i*18),(X1+34,Y0+30+i*18)],c,2.5)+T(X1+40,Y0+34+i*18,n,9.5,'start',INK,600)
b+=L([(px(13),Y0),(px(13),Y1)],'#94a3b8',1,'stroke-dasharray="4 3"')+T(px(13)+4,Y1-6,'synthesized 64-word RAM (13)',8.5,'start',MUTE)
b+=L([(px(32),Y0+95),(px(32),Y1)],RED,1,'stroke-dasharray="3 3"')+T(px(32)+4,Y0+95,'pipeline overtakes single-cycle (32)',8.5,'start',RED)
open('runtime.svg','w').write(svg(W,H,b)); print('ok')
