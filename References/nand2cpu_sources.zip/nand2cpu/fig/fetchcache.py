# Instruction-fetch trace of the test program (from the reference ISS) through
# direct-mapped caches of 1..64 lines. Word addresses = PC/4.
import sys, json
sys.path.insert(0,'../sim')
import asm
from cachesim import DMCache
prog=[w for w,_ in asm.assemble(asm.PROG)]+[0x13]*64
def fetch_trace(words, steps=60):
    x=[0]*32; mem={}; pc=0; tr=[]
    for _ in range(steps):
        tr.append(pc//4); w=words[pc//4]
        op=w&0x7f; rd=(w>>7)&31; f3=(w>>12)&7; rs1=(w>>15)&31; rs2=(w>>20)&31
        a=x[rs1]; b=x[rs2]; npc=pc+4; M=0xffffffff
        if op==0x33:
            x[rd]={0:(a-b if w>>25 else a+b),7:a&b,6:a|b,2:int(asm.sx(a,32)<asm.sx(b,32))}[f3]&M
        elif op==0x13:
            i=asm.sx(w>>20,12)&M; x[rd]={0:a+i,7:a&i,6:a|i,2:int(asm.sx(a,32)<asm.sx(i,32))}[f3]&M
        elif op==0x03: x[rd]=mem.get((a+asm.sx(w>>20,12))&M,0)
        elif op==0x23: mem[(a+asm.sx(((w>>25)<<5)|rd,12))&M]=b
        elif op==0x63 and a==b:
            npc=pc+asm.sx(((w>>31)<<12)|(((w>>7)&1)<<11)|(((w>>25)&0x3f)<<5)|(((w>>8)&0xf)<<1),13)
        elif op==0x6f:
            x[rd]=npc; npc=pc+asm.sx(((w>>31)<<20)|(((w>>12)&0xff)<<12)|(((w>>20)&1)<<11)|(((w>>21)&0x3ff)<<1),21)
        x[0]=0; pc=npc
    return tr
tr=fetch_trace(prog)
res={}
for lines in (1,2,4,8,16,32,64):
    c=DMCache(lines, abits=8)
    for a in tr: c.read(a)
    res[lines]=(c.hits,c.misses)
distinct=len(set(tr))
print('fetches',len(tr),'distinct words',distinct, res)
json.dump({'fetches':len(tr),'distinct':distinct,'res':res},open('fetchcache.json','w'))
