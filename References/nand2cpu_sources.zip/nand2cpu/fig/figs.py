import json, re
INK='#0f172a'; MUTE='#64748b'; GATE='#e7ecff'; GS='#3b4cc0'; REG='#dcf5e6'; RS='#157347'
BOX='#fff5dc'; BS='#b7791f'; MUX='#fde8f1'; MS='#a3245c'; ACC='#0b6aa2'; RED='#c2410c'
FONT="font-family:Inter,'Noto Sans Math',sans-serif"
MONO="font-family:'JetBrains Mono','Noto Sans Math',monospace"
def svg(w,h,body): return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" style="{FONT}">'+body+'</svg>'
def T(x,y,s,size=11,anchor='middle',fill=INK,weight=500,mono=False,extra=''):
    f=MONO if mono else FONT
    return f'<text x="{x}" y="{y}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{weight}" style="{f}" {extra}>{s}</text>'
def R(x,y,w,h,fill,stroke,rx=4,sw=1.3,extra=''):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>'
def L(pts,stroke=MUTE,sw=1.3,extra=''):
    d='M'+' L'.join(f'{x},{y}' for x,y in pts)
    return f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round" {extra}/>'
ARROW='<defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#475569"/></marker><marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#c2410c"/></marker></defs>'
out={}

# ---------- 1. abstraction ladder
levels=[('NAND','1 primitive','nand2',GATE,GS),('Gates','NOT · AND · OR · XOR · MUX','ch. 2',GATE,GS),
        ('Arithmetic','half/full adder · RCA · CLA · ALU','ch. 4',BOX,BS),
        ('State','latch · flip-flop · register · regfile','ch. 5',REG,RS),
        ('Datapath','single-cycle RV32I core','ch. 6–7',MUX,MS),
        ('Pipeline','5 stages · forwarding · stall · flush','ch. 8',MUX,MS)]
b=ARROW; W=640; y=10
for i,(n,d,c,f,s) in enumerate(levels):
    x=20+i*18; w=W-40-2*i*18
    yy=10+(len(levels)-1-i)*46
    b+=R(x,yy,w,36,f,s,6)
    b+=T(x+14,yy+23,n,13,'start',INK,650)+T(x+w/2+30,yy+23,d,11,'middle',MUTE)+T(x+w-12,yy+23,c,10,'end',s,600)
out['ladder']=svg(W,10+6*46,b)

# ---------- 2. CMOS NAND
b=ARROW
b+=L([(60,20),(260,20)],INK,1.6)+T(270,24,'V<tspan font-size="8">DD</tspan>',11,'start')
def pmos(x,y,lab):
    s=L([(x,y),(x,y+15)],INK,1.6)+L([(x,y+15),(x-6,y+15),(x-6,y+45),(x,y+45)],INK,1.6)+L([(x,y+45),(x,y+60)],INK,1.6)
    s+=L([(x-12,y+15),(x-12,y+45)],INK,1.6)+f'<circle cx="{x-17}" cy="{y+30}" r="4" fill="white" stroke="{INK}" stroke-width="1.4"/>'
    s+=L([(x-21,y+30),(x-40,y+30)],INK,1.4)+T(x-44,y+34,lab,11,'end',GS,650)
    return s
def nmos(x,y,lab):
    s=L([(x,y),(x,y+15)],INK,1.6)+L([(x,y+15),(x-6,y+15),(x-6,y+45),(x,y+45)],INK,1.6)+L([(x,y+45),(x,y+60)],INK,1.6)
    s+=L([(x-12,y+15),(x-12,y+45)],INK,1.6)+L([(x-12,y+30),(x-40,y+30)],INK,1.4)+T(x-44,y+34,lab,11,'end',GS,650)
    return s
b+=pmos(110,20,'A')+pmos(230,20,'B')
b+=L([(110,80),(110,95),(230,95),(230,80)],INK,1.6)+f'<circle cx="170" cy="95" r="3" fill="{INK}"/>'
b+=L([(170,95),(170,110)],INK,1.6)+L([(170,95),(300,95)],INK,1.6)+T(308,99,'Y = ¬(A·B)',12,'start',INK,650)
b+=nmos(170,110,'A')+nmos(170,170,'B')
b+=L([(170,230),(170,245)],INK,1.6)+L([(150,245),(190,245)],INK,1.6)+L([(157,250),(183,250)],INK,1.4)+L([(164,255),(176,255)],INK,1.2)
b+=T(200,262,'GND',10,'start',MUTE)
b+=T(360,150,'pull-up: two PMOS in parallel',10,'start',MUTE)+T(360,166,'pull-down: two NMOS in series',10,'start',MUTE)+T(360,182,'4 transistors, inverting, restoring',10,'start',MUTE)
out['cmos_nand']=svg(560,270,b)

# ---------- 3. timing diagram
b=ARROW
def wave(y,pts,lab,col=INK):
    return T(12,y+12,lab,11,'start',INK,650)+L(pts,col,1.6)
W=640
clk=[(70,40)]; x=70
for k in range(3):
    clk+= [(x,40),(x+60,40),(x+60,15),(x+130,15),(x+130,40)]; x+=130
b+=wave(15,clk+[(W-20,40)],'clk')
# D with setup/hold window around edge at 130 and 260
e=260
b+=f'<rect x="{e-46}" y="58" width="{46+14}" height="34" fill="#fef3c7" stroke="none"/>'
b+=T(e-23,106,'t<tspan font-size="8">setup</tspan>',10,'middle',RED)+T(e+12,106,'t<tspan font-size="8">hold</tspan>',10,'start',RED)
b+=L([(e,20),(e,190)],'#94a3b8',1,'stroke-dasharray="3 3"')
b+=T(12,78,'D',11,'start',INK,650)
b+=L([(70,62),(180,62),(190,88),(330,88),(340,62),(W-20,62)],INK,1.6)+L([(70,88),(180,88),(190,62),(330,62),(340,88),(W-20,88)],INK,1.6)
b+=T(260,78,'stable',9,'middle',MUTE)
b+=T(12,140,'Q',11,'start',INK,650)
b+=L([(70,125),(e+30,125),(e+40,152),(W-20,152)],INK,1.6)+L([(70,152),(e+30,152),(e+40,125),(W-20,125)],INK,1.6)
b+=L([(e,172),(e+35,172)],RED,1.2,'marker-end="url(#arr)"')+T(e+40,176,'t<tspan font-size="8">pcq</tspan> (clock-to-Q)',10,'start',RED)
b+=T(W/2,210,'D must be stable from the setup time before the clock edge until the hold time after it.',10,'middle',MUTE)
out['timing']=svg(W,220,b)

# ---------- 4. pipeline block diagram
b=ARROW
stages=[('F','Fetch','PC · +4 · instruction memory'),('D','Decode','controller · extend · regfile read'),
        ('E','Execute','fwd muxes · ALU · branch target'),('M','Memory','data memory read/write'),('W','Writeback','result mux · regfile write')]
W=760; H=300; sx=18; sw=112; gap=40
for i,(k,n,d) in enumerate(stages):
    x=sx+i*(sw+gap)
    b+=R(x,60,sw,110,BOX,BS,6)
    b+=T(x+sw/2,84,k,20,'middle',BS,700)+T(x+sw/2,104,n,12,'middle',INK,650)
    for j,line in enumerate(d.split(' · ')):
        b+=T(x+sw/2,124+j*13,line,9,'middle',MUTE)
    if i<4:
        rx=x+sw+gap/2-7
        b+=R(rx,50,14,130,REG,RS,2)
        b+=T(rx+7,44,['F/D','D/E','E/M','M/W'][i],9,'middle',RS,650)
        b+=L([(x+sw,115),(rx,115)],'#475569',1.4,'marker-end="url(#ar)"')
        b+=L([(rx+14,115),(rx+gap/2+7,115)],'#475569',1.4,'marker-end="url(#ar)"')
# feedback paths
xE=sx+2*(sw+gap); xM=sx+3*(sw+gap); xW=sx+4*(sw+gap); xF=sx; xD=sx+(sw+gap)
b+=L([(xM+sw/2,170),(xM+sw/2,205),(xE+sw*0.7,205),(xE+sw*0.7,172)],RED,1.4,'marker-end="url(#arr)"')
b+=T((xM+xE)/2+sw*0.6,219,'forward ALUResultM',9,'middle',RED)
b+=L([(xW+sw/2,170),(xW+sw/2,240),(xE+sw*0.3,240),(xE+sw*0.3,172)],RED,1.4,'marker-end="url(#arr)"')
b+=T((xW+xE)/2+sw*0.4,254,'forward ResultW',9,'middle',RED)
b+=L([(xW+sw*0.8,170),(xW+sw*0.8,275),(xD+sw*0.5,275),(xD+sw*0.5,172)],'#475569',1.2,'stroke-dasharray="4 3" marker-end="url(#ar)"')
b+=T((xW+xD)/2+sw*0.6,290,'regfile write (falling edge)',9,'middle',MUTE)
b+=L([(xE+sw/2,60),(xE+sw/2,22),(xF+sw/2,22),(xF+sw/2,58)],ACC,1.4,'marker-end="url(#ar)"')
b+=T((xE+xF)/2+sw/2,16,'PCTargetE, PCSrcE  (branch / jal resolved in E)',9,'middle',ACC)
out['pipeline_block']=svg(W,H,b)

# ---------- 5. RV32I formats
fmts=[('R',[('funct7',7),('rs2',5),('rs1',5),('funct3',3),('rd',5),('op',7)]),
      ('I',[('imm[11:0]',12),('rs1',5),('funct3',3),('rd',5),('op',7)]),
      ('S',[('imm[11:5]',7),('rs2',5),('rs1',5),('funct3',3),('imm[4:0]',5),('op',7)]),
      ('B',[('imm[12|10:5]',7),('rs2',5),('rs1',5),('funct3',3),('imm[4:1|11]',5),('op',7)]),
      ('J',[('imm[20|10:1|11|19:12]',20),('rd',5),('op',7)])]
W=680; u=(W-60)/32; b=''
for bit in (31,25,24,20,19,15,14,12,11,7,6,0):
    x=40+(31-bit)*u+(u/2); b+=T(x,14,str(bit),8,'middle',MUTE,500,True)
for r,(n,fs) in enumerate(fmts):
    y=22+r*30; x=40
    b+=T(22,y+17,n,13,'middle',GS,700)
    for name,wd in fs:
        fill={'op':GATE,'rd':REG,'rs1':REG,'rs2':REG,'funct3':MUX,'funct7':MUX}.get(name,BOX)
        st={'op':GS,'rd':RS,'rs1':RS,'rs2':RS,'funct3':MS,'funct7':MS}.get(name,BS)
        b+=R(x,y,wd*u,24,fill,st,2,1.1)+T(x+wd*u/2,y+15.5,name,9,'middle',INK,500,True)
        x+=wd*u
out['formats']=svg(W,22+5*30,b)

# ---------- 6. RCA depth chart (from STA)
sta=json.load(open('../rend/sta_res.json'))
W=560;H=240; b=''
X0,Y0,X1,Y1=60,20,520,190
b+=L([(X0,Y0),(X0,Y1),(X1,Y1)],INK,1.2)
Ns=[4,8,16,32,64]
import math
def px(n): return X0+(math.log2(n)-2)/4*(X1-X0)
def py(v): return Y1-(v/140)*(Y1-Y0)
for v in (0,35,70,105,140):
    b+=L([(X0-4,py(v)),(X1,py(v))],'#e2e8f0',0.8)+T(X0-8,py(v)+3,str(v),9,'end',MUTE)
for n in Ns: b+=T(px(n),Y1+14,str(n),9,'middle',MUTE)
b+=T((X0+X1)/2,Y1+32,'adder width N (bits, log scale)',10,'middle',INK)
b+=T(16,(Y0+Y1)/2,'NAND levels',10,'middle',INK,500,False,f'transform="rotate(-90 16 {(Y0+Y1)/2})"')
pts=[(px(int(n)),py(v[1])) for n,v in sta.items()]
b+=L(pts,GS,2)
for (x,y),(n,v) in zip(pts,sta.items()): b+=f'<circle cx="{x}" cy="{y}" r="3.5" fill="{GS}"/>'+T(x-6,y-8,str(v[1]),9,'end',GS,650)
ks=json.load(open('../rend/sta_ks.json'))
kpts=[(px(int(n)),py(v['ks_d'])) for n,v in ks.items()]
b+=L(kpts,'#15803d',2)
for (x,y),(n,v) in zip(kpts,ks.items()): b+=f'<circle cx="{x}" cy="{y}" r="3.5" fill="#15803d"/>'+T(x+6,y-7,str(v['ks_d']),9,'start','#15803d',650)
b+=T(px(32)+10,py(18)+16,'Kogge–Stone (measured)',9,'middle','#15803d',650)
out['rca_depth']=svg(W,H,b)

# ---------- 7. exact Dadda dot diagram (8x8), from dadda.py
from dadda import dadda
tg,stg,nfa,nha=dadda(8)
W=700; b=''
titles=['partial products']+[f'after stage {k+1} (≤ {t})' for k,t in enumerate(tg)]
sp=6.6; r=2.3
for k,(hs,tt) in enumerate(zip(stg,titles)):
    ox=10+k*138; oy=40
    cols=len(hs)
    b+=T(ox+(cols-1)*sp/2,oy-18,tt,9.5,'middle',INK,650)
    b+=T(ox+(cols-1)*sp/2,oy-7,f'max height {max(hs)}',8,'middle',MUTE)
    for c,hh in enumerate(hs):
        x=ox+(cols-1-c)*sp
        for q in range(hh): b+=f'<circle cx="{x:.1f}" cy="{oy+q*sp:.1f}" r="{r}" fill="{GS if k==0 else '#0f766e'}"/>'
    if k<len(stg)-1: b+=T(ox+cols*sp+6,oy+22,'→',12,'middle',MUTE)
b+=T(W/2,118,f'Exact Dadda schedule for 8 × 8: {nfa} full adders + {nha} half adders, leaving two rows for a 14-bit carry-propagate adder',9.5,'middle',MUTE)
b+=T(W/2,133,'columns are bit weights 2<tspan dy="-3" font-size="6.5">0</tspan><tspan dy="3"> (right) to 2</tspan><tspan dy="-3" font-size="6.5">15</tspan><tspan dy="3"> (left); computed by fig/dadda.py and realized in hdl/dadda8.sv</tspan>',9,'middle',MUTE)
out['dadda']=svg(W,142,b)

for k,v in out.items(): open(f'{k}.svg','w').write(v)
print(list(out))
