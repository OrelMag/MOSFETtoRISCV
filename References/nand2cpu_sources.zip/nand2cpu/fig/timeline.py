import sys
sys.path.insert(0,'.')
from figs import *
lst={}
for ln in open('../sim/listing.txt'):
    pc,w,*rest=ln.split(None,2); lst[int(pc,16)]=rest[0].strip()
def short(s):
    s=re.sub(r'\s+',' ',s); return s.replace('addi ','addi ').replace(', ',',')
LOG=[l.split() for l in open('../sim/pipe.log') if l.startswith('T')]
rows={int(t[1]):t for t in LOG}
def chart(c0,c1,title):
    cw=66; rh=24; ox=46; oy=34
    W=ox+(c1-c0+1)*cw+10; H=oy+5*rh+40
    b=''
    b+=T(8,14,title,11,'start',INK,650)
    for j,c in enumerate(range(c0,c1+1)):
        b+=T(ox+j*cw+cw/2,oy-6,str(c),9,'middle',MUTE,500,True)
        t=rows[c]
        fields={'F':int(t[3],16),'D':int(t[5],16)-4,'E':int(t[7],16)-4,'M':int(t[9],16)-4,'W':int(t[11],16)-4}
        stall=t[13]=='1'; fD=t[15]=='1'; fE=t[17]=='1'
        fa=t[19]; fb=t[21]
        for i,st in enumerate('FDEMW'):
            x=ox+j*cw; y=oy+i*rh
            pc=fields[st]
            bubble = (st!='F' and int(t[{'D':5,'E':7,'M':9,'W':11}[st]],16)==0)
            squashed = (st=='F' and fD) or (st=='D' and fD)
            held = stall and st in 'FD'
            fill = '#f1f5f9' if bubble else ('#fee2e2' if squashed else ('#fef3c7' if held else '#ffffff'))
            stroke = '#cbd5e1'
            b+=R(x+1,y+1,cw-2,rh-2,fill,stroke,3,0.8)
            if bubble: b+=T(x+cw/2,y+15,'bubble',8,'middle','#94a3b8')
            else:
                lab=short(lst.get(pc,'?'))
                col = RED if squashed else INK
                deco = 'text-decoration="line-through"' if squashed else ''
                b+=T(x+cw/2,y+15,lab,7.1,'middle',col,500,True,deco)
            if st=='E' and (fa!='00' or fb!='00'):
                srcs=[]
                # only mark genuine uses: ignore rs2 for I-type/jal
                pass
    for i,st in enumerate('FDEMW'):
        b+=T(ox-10,oy+i*rh+16,st,12,'end',BS,700)
    ly=oy+5*rh+18
    for k,(f,lab) in enumerate([('#fee2e2','squashed by flush'),('#fef3c7','held by stall'),('#f1f5f9','bubble (cleared register)')]):
        b+=R(ox+k*190,ly-9,14,12,f,'#cbd5e1',2,0.8)+T(ox+k*190+20,ly+1,lab,9,'start',MUTE)
    return svg(W,H,b)
def T_(*a): return ''
open('timeline_a.svg','w').write(chart(0,9,'Cycles 0–9: pipeline fill, then the back-edge jal is taken in E (cycle 8)'))
open('timeline_b.svg','w').write(chart(60,69,'Cycles 60–69: loop exit (beq taken, cycle 61) and the load-use stall (cycle 65)'))
print('ok')
