# NAND-level arrival times: 8x8 array multiplier vs Dadda tree (both using the 9-NAND FA / 5-NAND HA)
from dadda import dadda
AND=2
def fa(a,b,c):   # arrival of (s, cout) given input arrivals, from the gate structure in gates.sv
    x1=max(a,b)+3; m1=max(a,b)+1
    s=max(x1+3, c+3, x1+2); m2=max(x1,c)+1
    co=max(m1,m2)+1
    return s,co
def ha(a,b): return max(a,b)+3, max(a,b)+2
n=8
# ---- array: rows of ripple adders like mul_array4
pp=[[AND]*n for _ in range(n)]
prod=[0]*(2*n)
prod[0]=AND
acc=[AND]*(n-1)+[0]   # pp0[n-1:1] with 0 on top (constant arrives at 0)
for i in range(1,n):
    c=0; s=[0]*n
    for j in range(n):
        s[j],c=fa(acc[j],pp[i][j],c) if j>0 or True else None
    prod[i]=s[0]
    acc=s[1:]+[c]
for j in range(n): prod[n+j-1+1 if False else n+j]=0
arr_depth=max(max(acc),max(prod[:n]))
# ---- dadda tree + final ripple CPA over 2n bits
targets,_,_,_=dadda(n)
cols=[[AND]*len([1 for i in range(n) for j in range(n) if i+j==c]) for c in range(2*n)]
for t in targets:
    new=[[] for _ in range(2*n)]; carries=[]
    for c in range(2*n):
        bits=cols[c]+carries; carries=[]
        while len(bits)>t:
            if len(bits)-t>=2:
                a,b,ci=bits.pop(0),bits.pop(0),bits.pop(0); s,co=fa(a,b,ci)
            else:
                a,b=bits.pop(0),bits.pop(0); s,co=ha(a,b)
            bits.append(s); carries.append(co)
        new[c]=bits
    cols=new
tree=max(max(c) for c in cols if c)
c=0; out=0
for col in cols:
    a=col[0] if len(col)>0 else 0; b=col[1] if len(col)>1 else 0
    s,c=fa(a,b,c); out=max(out,s)
print('array depth',arr_depth,'| dadda tree depth',tree,'| dadda + ripple CPA',max(out,c))
