# From NAND to a Pipelined CPU — companion sources

Everything needed to reproduce the verification results and figures in the primer
(see Appendix E for the exact commands).

hdl/   SystemVerilog
       gates.sv        NAND primitive, derived gates, adders (RCA, CLA, parameterized RCA)
       seq.sv          latches, master-slave flip-flop, register, counter, 4x4 register file
       rv_blocks.sv    ALU, extend, register file, controller, memories, muxes
       rv_single.sv    single-cycle RV32I-subset CPU
       rv_pipe.sv      five-stage pipelined CPU (stages, pipeline registers, hazard unit)
       arith.sv        array / shift-add / Booth multipliers; restoring / non-restoring dividers
       dadda8.sv       generated 8x8 Dadda multiplier; dadda8_rca.sv, mul_array8.sv (timing variants)
       mem16.sv        16-word x 8-bit addressable memory (Appendix C)
       microcode.sv    hardwired vs microprogrammed multicycle controller (Appendix D)
       legend.sv       one of each netlist cell type (Figure 1.3)
       kmap.sv         SoP / PoS / K-map worked examples (Sections 2.6–2.8)
       prefix.sv       Kogge–Stone parallel-prefix adder (Section 3.6); dadda8_ks.sv uses it
       rv_pipe_bp.sv   pipeline with 16-entry BTB + 2-bit counters (Section 7.10)
       rv_multi.sv     multicycle CPU driven by either controller (Appendix D.6)
       cache.sv        4-line direct-mapped cache (Appendix C.9)
       fpu.sv          IEEE 754 binary32 FPU: add/sub, multiply, compare, lzc64 (Chapter 9)
       cpu_fpu.sv      the four processors with the FPU as a memory-mapped coprocessor
       opgates.sv      word-level operators (+ − = <, reductions, muxes) and NAND-level equivalents (Appendix E)
       formal.sv       ten property wrappers proved with Yosys SAT (Section 8.3)
sim/   testbenches, assembler + reference ISS (asm.py), result checker, traces,
       cosim.py (random-program co-simulation, 5 CPU configurations), mutate.py (mutation testing),
       numdemo.py (number-system program), fpvec.py (NumPy FPU vectors), fpudemo.py (FPU program),
       tb_fpu.sv, tb_cpu_fpu.sv; fmut/ (FPU mutants). NumPy is needed only for the FPU vectors.
fig/   figure generators (figs.py, figs2.py, figs3.py, figs4.py, timeline.py), Dadda scheduler/generator,
       micro-assembler (microasm.py), cache model (cachesim.py), fetch-trace study (fetchcache.py)
rend/  Yosys -> netlistsvg rendering (render.py, style.py, three skins), static timing
       (sta.py, sta_mul.py, sta_ks.py; whole-CPU clock periods: sta_struct.py,
       sta_sweep.py, sta_abc.py, sta_cpu.py; operator costs sta_ops.py;
       lower_check.py verifies Yosys' gate-level lowering), formal proofs (formal.py, formal_neg.py),
       whole-CPU and FPU timing (sta_struct.py, sta_fpu.py, sta_fpu_breakdown.py), rendered netlists in svg/

Tools: Icarus Verilog 12, Yosys 0.69 (pip install yowasp-yosys), netlistsvg 1.0.2
(npm i netlistsvg; must be on PATH), Python 3 (standard library only).
Run microasm.py (from sim/: python3 ../fig/microasm.py .) before simulating or rendering
the microcoded controller; copy the .hex files into rend/ before rendering it or running formal.py.
Formal proofs need no external solver (Yosys' built-in SAT). Run scripts from their own folder.
